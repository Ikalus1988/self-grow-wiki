# WSL Agent 便携包索引

> 生成时间：2026-06-26
> 来源：WSL Ubuntu `/home/hp/` 环境
> 用途：迁移到新服务器后快速导入 Agent 记忆和技能

---

## 包内容统计

| 类型 | 数量 | 说明 |
|------|------|------|
| Skills | 21 | Hermes 高价值技能（泛化后） |
| Lessons | 140 | MisakaNet 经验教训 |
| References | 6 | 架构分析和方案对比 |
| Cron Reports | 10 | 最近10份每日巡检报告 |

---

## Skills 索引

### 核心开发方法论

| Skill | 路径 | 用途 |
|-------|------|------|
| agentic-context-engineering | `skills/agentic-context-engineering/` | Agent 上下文工程5层架构、SKILL.md规范 |
| systematic-debugging | `skills/software-development/systematic-debugging/` | 4阶段根因调试：理解→分析→修复→验证 |
| subagent-driven-development | `skills/software-development/subagent-driven-development/` | 子Agent分派+两阶段review |
| writing-plans | `skills/software-development/writing-plans/` | 实现计划编写：bite-sized tasks |
| code-review | `skills/software-development/code-review/` | 多维度代码审查清单 |

### 工程实践

| Skill | 路径 | 用途 |
|-------|------|------|
| open-source-pr-contribution | `skills/software-development/open-source-pr-contribution/` | 开源PR贡献8步流程 |
| github-repo-architecture-review | `skills/software-development/github-repo-architecture-review/` | 仓库架构评审+P0-P3分级 |
| claim-verification-audit | `skills/software-development/claim-verification-audit/` | 声明验证审计（设计文档vs代码） |
| technical-evaluation-writing | `skills/software-development/technical-evaluation-writing/` | 晋级/评审文档写作方法论 |
| github | `skills/github/` | GitHub工作流：认证/PR/Issue/CI |

### 领域技能

| Skill | 路径 | 用途 |
|-------|------|------|
| mify-model-gateway | `skills/mify-model-gateway/` | 小米Mify大模型网关使用规范 |
| edoc-rag | `skills/edoc-rag/` | FANUC RAG知识库检索规范 |
| edoc-pipeline-retrospective | `skills/edoc-pipeline-retrospective/` | 万级PDF导入教训 |
| wxauto-bot-feature-add | `skills/wxauto-bot-feature-add/` | 微信机器人功能扩展标准流程 |
| wxauto-bot-development | `skills/software-development/wxauto-bot-development/` | 微信机器人开发规范+三种架构对比 |
| gradio-feedback-panel | `skills/software-development/gradio-feedback-panel/` | Gradio反馈面板设计 |
| patent-disclosure-writing | `skills/patent-disclosure-writing/` | 专利交底书写作 |

### 研究工具

| Skill | 路径 | 用途 |
|-------|------|------|
| arxiv | `skills/research/arxiv/` | arXiv论文搜索 |
| llm-wiki | `skills/research/llm-wiki/` | Karpathy LLM Wiki模式 |

### 安全研究

| Skill | 路径 | 用途 |
|-------|------|------|
| godmode | `skills/red-teaming/godmode/` | LLM越狱测试（红队） |

---

## Lessons 索引

### RAG 相关（高价值）

| Lesson | 关键词 |
|--------|--------|
| rag-alarm-code-mandatory-recall.md | 报警代码关键词强制召回 |
| rag-brand-filter-three-pitfalls.md | 品牌过滤三坑：条件触发/文件正则/缓存 |
| rag-cross-encoder-cpu-bottleneck.md | Cross-Encoder CPU瓶颈→关闭reranker |
| rag-chinese-encoding-pymupdf.md | pymupdf中文乱码修复 |
| rag-build-strategy-batch.md | 不可一次加载全部数据 |
| bge-embedding-fallback-crash.md | BGE模型降级fallback |

### WSL/DevOps

| Lesson | 关键词 |
|--------|--------|
| wsl-permission-ntfs-fix.md | WSL NTFS权限修复 |
| wsl-terminal-underscore-corruption.md | WSL终端下划线损坏 |
| pip-install-failure-fix.md | pip安装失败修复 |
| tmux-session-management.md | tmux会话管理 |

### 飞书

| Lesson | 关键词 |
|--------|--------|
| feishu-block-type-values-limits.md | 飞书Block Type正确值 |
| feishu-webhook-url-env-config.md | 飞书Webhook配置 |
| feishu-wiki-batch-download.md | 飞书Wiki批量下载 |

### Agent协作

| Lesson | 关键词 |
|--------|--------|
| codewhale-git-push-yolo-task.md | Codewhale git推送 |
| openclaw-prefer-cli-and-policy-over-direct-edit.md | OpenClaw优先CLI |
| phase-0-output-gate.md | Phase 0输出门禁 |

### 其他

| Lesson | 关键词 |
|--------|--------|
| gpt-sovits-ref-free-bug.md | GPT-SoVITS无参考bug |
| gpt-sovits-hubert-16khz.md | GPT-SoVITS HuBERT 16kHz |
| cloudflare-email-worker-registration-trap.md | Cloudflare Email Worker注册 |

---

## References 索引

| Reference | 说明 |
|-----------|------|
| swarm-memory-three-schemes.md | 虫群记忆系统三方案对比 |
| swarm-memory-architecture-comparison.md | 虫群记忆架构对比 |
| agent-medici-architecture-analysis-methodology.md | 架构分析方法论（避免文档依赖陷阱） |
| wechat-bot-iteration-trajectory.md | 微信机器人方案迭代轨迹 |
| mem0-qdrant-execution-plan.md | Mem0+Qdrant执行计划 |
| mem0-qdrant-implementation.md | Mem0+Qdrant实现细节 |

---

## 导入方法

### 方式A：复制到新服务器

```bash
# 1. 传输便携包
scp -r wsl-agent-portable/ user@newserver:~/

# 2. 导入到Hermes skills目录
mkdir -p ~/.hermes/skills
cp -r ~/wsl-agent-portable/skills/* ~/.hermes/skills/

# 3. 导入到MisakaNet lessons（如果部署了MisakaNet）
mkdir -p ~/MisakaNet/lessons/contrib ~/MisakaNet/lessons/core ~/MisakaNet/reference
cp ~/wsl-agent-portable/lessons/*.md ~/MisakaNet/lessons/contrib/
cp ~/wsl-agent-portable/references/*.md ~/MisakaNet/reference/
```

### 方式B：打包传输

```bash
# 在原服务器打包
cd /home/hp
tar czf wsl-agent-portable.tar.gz wsl-agent-portable/

# 传输
scp wsl-agent-portable.tar.gz user@newserver:~/

# 在新服务器解压
tar xzf wsl-agent-portable.tar.gz
```

### 方式C：导入到Claude Code memory

便携包中的关键内容已整理到 Windows Claude Code memory：
- `C:\Users\hp\.claude\projects\C--Users-hp\memory\` 下的16个记忆文件

---

## 注意事项

1. **凭据不包含在内** — API Key、App Secret等需要在新服务器重新配置
2. **向量库不包含在内** — ChromaDB需要从PDF重建或单独迁移
3. **Python venv不包含在内** — 需要在新服务器 `pip install -r requirements.txt`
4. **Skills可能需要适配** — 部分skill引用了特定路径，导入后需检查
5. **Lessons为通用格式** — frontmatter包含metadata，可被任何Agent系统消费

---

*索引版本：v1.0 · 2026-06-26*
