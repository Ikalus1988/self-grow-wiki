# Edoc 建库调试教训记录

## 2026-04-16/17 全盘扫描 + 批量导入（10528 PDFs）

### 全盘扫描策略（经验教训）

**1. 扫描方式：find > os.walk（针对大目录/万级文件）**
- `os.walk` + Python 循环：300秒超时，对 F: 盘 19k PDFs 无法完成
- `find /mnt/f -name "*.pdf" -size +0`：后台运行，~1000条/秒，完整结果存文本文件
- 大目录优先用 find，Python 只需读结果文件

**2. 去重策略：文件名+大小 > MD5（针对万级文件）**
- MD5 计算 19k 文件前 1MB：超时（>300s）
- 文件名(小写) + 文件大小 指纹：<10秒完成
- 精确 MD5 只在最终合并候选时对少量文件使用

**3. 噪音过滤模式（快速排除非知识类 PDF）**
```python
noise_patterns = [
    'baldur','bg3','BG3','character sheet',  # 游戏
    'rabbit','荷兰鼠','tiger',               # 调查问卷
    'matplotlib','mpl-data','site-packages',  # Python库
    '生物医药','rarecare',                   # 无关行业
    'ragflow','test/benchmark',               # 测试数据
    'steamapps','common/',                   # 游戏目录
    '$recycle','system volume',              # 系统目录
    '企业微信','WXWork/Cache',               # 微信缓存
    'MsgAttach',                             # 邮件附件（合同/保单）
]
```

**4. 扫描结果必须持久化**
- 临时存 `/tmp/` 会在会话间丢失
- 正确做法：扫描结果存 `~/.hermes/scripts/edoc_scan_<drive>.json`
- 下次直接读文件跳过扫描

**5. 典型扫描结果分布（用户筛选偏好）**
| 目录 | 内容 | 判定 |
|------|------|------|
| project/ | 机器人/汽车工程文档 | ✅ |
| 调试资料/ | 西门子PLC/KUKA/OpenCV | ✅ |
| 软件/ | KUKA WorkVisual/ABB手册 | ✅ |
| 标准培训相关/ | 主机厂标准/培训手册 | ✅ |
| 观致办公/WXWork | 会议纪要/微信缓存 | ❌ |
| ikalus07/MsgAttach | 保单/合同/扫描件 | ❌ |

**6. 标准化导入流程**
```
1. find 扫描目标盘 → /tmp/pdfs.txt
2. Python 读文件 + 文件名/大小去重 + 噪音过滤
3. 展示目录分布 → 用户确认要哪些
4. 筛选后写入 edoc_ingest.py NEW_PDFS 列表（patch）
5. HF_HUB_OFFLINE=1 python3 edoc_ingest.py（后台）
6. 监控日志 + GPU显存，等完成通知
```

### 预估导入时间
- 小 PDF（<10页）：<5秒
- 中 PDF（100-400页）：5-30秒
- 大 PDF（500+页）：100-500秒（pymupdf 解析是瓶颈）
- 公式：总耗时 ≈ Σ(页数) × 0.85秒/页 + Σ(批次数) × 0.5秒

---

## 2026-04-16 第二次增量导入（6 PDFs，38,037 chunks）

### 实际导入结果
| PDF | 页数 | chunks | 耗时 |
|-----|------|--------|------|
| KAREL Reference 6.31 | 941 | 2303 | 803s |
| 系统变量表 | 503 | 1512 | 484s |
| FANUC License Server | 53 | 92 | 3s |
| Bosch Servo Gun | 6 | 11 | 5s |
| R-30iA FSSB Line Setting | 7 | 12 | 1s |
| 3rd Party Vision Sensor | 6 | 7 | 1s |

**总计：+3937 chunks in 1304s（约22分钟）。最终 38,037 chunks，148 个 source。**

### 启动命令
```bash
export HF_HUB_OFFLINE=1 && cd ~/.hermes && venv/bin/python3 scripts/edoc_ingest.py
```
`HF_HUB_OFFLINE=1` 防止 BGE 加载时 httpx 报 network unreachable。

### 多旧实例通知问题
watchdog 可能同时启动多个 edoc_ingest 实例，旧实例（20:07/20:13/20:17/20:21）被 SIGTERM 终止后仍会推送后台通知（ERROR, exit 143）。**判断标准**：只看 exit 0 且 collection count 跳升的那条。所有旧实例通知（exit 143, torch is not defined, network unreachable）一律可忽略。

### 旧实例常见错误速查
| 错误 | 原因 | 处理 |
|------|------|------|
| `torch.ConnectError: Network is unreachable` | 没设 `HF_HUB_OFFLINE=1` | 用正确命令重跑 |
| `NameError: name 'torch' is not defined` | torch import 缺失 | 脚本已修复，重跑即可 |
| `exit 143, tcsetattr` | SIGTERM 强制终止 | 无害，忽略 |
| 20:34 启动的那条 exit 0 | 真正成功的那次 | 看这条 |

---

## 2026-04-16 增量导入（edoc_ingest.py）

### 后台进程日志读取（关键！）
Python `print()` 在非 tty 环境下有缓冲，`tail -f` 可能读不到最新行。正确做法：
```python
with open('edoc_ingest.log') as f:
    f.seek(0, 2)          # 定位 EOF
    size = f.tell()
    f.seek(max(0, size-2000))  # 读末尾2KB
    print(f.read())
```

### BGE-m3 快照路径防网络超时
首次加载后 `model.save()` 生成 snapshot，后续 `from_pretrained(snapshot_path=...)` 完全离线加载。配合 `HF_HUB_OFFLINE=1` 环境变量，第二次起启动从 ~20s 降到 ~4s。

### pymupdf 大 PDF 解析速度实测（Ryzen 7 5800H）
| 文档 | 页数 | chunks | 耗时 | 速度 |
|------|------|--------|------|------|
| KAREL Reference 6.31 | 941 | 2303 | 803s | ~1.17页/秒 |
| Bosch Servo Gun | 6 | 11 | 5s | ~1.2页/秒 |
| 系统变量表 | 503 | ~970(估) | ~430s | ~1.17页/秒 |

大 PDF（>500页）pymupdf 解析是主要耗时，GPU 编码反而快（~940 sent/s）。预估：总耗时 ≈ PDF页数 × 0.85秒/页。

### GPU 显存锁定问题
BGE-m3 在 CUDA 上加载后显存占用 ~7942 MiB（RTX 4060 Laptop 8188 MiB），进程退出前不释放。后台运行时显存被占满，但系统仍可用（Linux 显存管理）。

### 增量导入策略
1. 扫描全部 PDF 源目录
2. 对比 `indexed_sources.jsonl`，找出未导入 PDF
3. 逐个导入，每次 `add()` 后写 checkpoint
4. 完成后追加新 source 进 jsonl
5. 全量 `coll.count()` 验证 = checkpoint 理论总数

---

## 2026-04-16 第二次建库（成功）

### 压力测试发现的 checkpoint 时序 bug（关键！）
- **Bug**：checkpoint 在 ChromaDB `add()` **之前**保存。如果进程在 batch 写入中途被 SIGTERM 打断，该 batch 部分数据进入 ChromaDB 但 checkpoint 记录的是 batch 开始前的位置
- **表现**：diff = abs(checkpoint - ChromaDB count) > 0 但 < batch×2，脚本用 checkpoint 恢复 → **数据重复写入**
- **修复**：checkpoint 必须在 `coll.add()` **之后**才保存，保证最多丢当前 batch 的开头数据，不会有部分写入
- **验证**：压力测试模拟 SIGTERM + 重启恢复，diff=0，数据零重复

### GPU 显存实测数据（RTX 4060 Laptop, 8188 MiB）
| Batch | 峰值显存 | 占比 | 安全 |
|--------|---------|------|------|
| 32 | **2887 MiB** | 35.3% | ✓ |
| 48 | ~4331 MiB（估算） | 52.9% | ✓ |
| 64 | ~5775 MiB（估算） | 70.5% | ✓ |

脚本预热阶段自动测前2批峰值并估算加 batch 的安全性。

### 建库结果
- **34,100 chunks，零重复**，chroma_db_v4/edoc_v10_m3 → **38,037 chunks（增量后）**
- 推理速度：~940 sent/s（batch=48）
- B-83644CM_06.PDF（228 chunks）正确入库，p.25 含"機構部の質量 1590 kg"
- B-83644EN_06.PDF 不在源目录 chunks_v3/manifest.json（原始数据缺失，非建库问题）

## 2026-04-16 新发现（第七次崩溃）

### BGE 模型 cache 并未损坏
- 症状：WSL 重启后模型加载报错，以为 cache 损坏
- 真相：所有 symlink 都指向存在的 blob，模型完好
- 根因：`_bge_m3_checkpoint.json` 被删除 + ChromaDB count 未同步
- 教训：不要急着重下模型，先 `find ~/.cache/huggingface/ -type l` 验证 blob 存在性

### SimpleBM25 score() 严重性能 bug
- 文件：`rag_gui_server.py`
- Bug：`score()` 每次查询都把所有文档重新 tokenize，导致 O(n×d×q) 复杂度
- 影响：6144 docs × 平均 200 tokens × 查询词数 = 每次查询几十秒，服务器初始化永远卡住
- 修复：预计算每批文档的词频 cache，score 时查表

```python
# Bug: 每次 score 都重新 tokenize 整批文档
for t in query_tokens:
    if t in tokens:  # ← 每次都重新遍历
        tf = 1 + math.log(1 + sum(1 for _t in tokens if _t == t))  # ← 每次都重新统计词频

# Fix: 预计算 tf_cache
tf_cache = [{} for _ in range(self.N)]
for t in query_tokens:
    for i, tokens in enumerate(self.doc_tokens):
        if t in tokens:
            tf_cache[i][t] = tf_cache[i].get(t, 0) + 1
```

### rag_gui_server.py 初始化阻塞 bug
- Bug：`_state["ready"] = True` 放在 BM25 构建之后，导致 BM25 没建完服务器一直返回"初始化中"
- 修复：向量模型加载好就立即标记 ready，BM25 移到 daemon thread 后台构建

## 历史崩溃根因（综合）

### 崩溃根因速查表
| 根因 | 症状 | 防护 |
|---|---|---|
| WSL 重启 SIGTERM | checkpoint 不同步，ChromaDB count > checkpoint resume_from | SIGTERM 捕获 + ChromaDB count 优先 |
| BATCH=128 峰值 5GB | OOM kill | BATCH=64 + GPU 显存监控 |
| 无进程锁 | 重复启动两个实例 | fcntl LOCK_NB |
| BGE-m3 占用 7942/8188 MiB | 显存几乎满但不OOM | 进程退出前不释放，不要同时跑两个大模型 |
| BM25 cache pickle 类不匹配 | cache 存在但加载失败，每次重头建 | try/except 降级 |

### ChromaDB 1.5.7 行为
- **无显式 flush**（auto-persist），add() 后 SQLite 基本同步
- **HNSW 索引构建在后台**
- **无 thread-safe 问题**（每个请求独立 client 即可）
- **count() 准确性**：实测 count() 返回值与实际 add 数量一致（无延迟）
- **checkpoint 验证**：count() vs checkpoint 交叉验证，差异 > batch×2 视为异常

## 命中率低的真正根因
- 不是算法问题，是**数据缺失问题**
- `edoc_v10_m3` 初始只有 37 PDF / 34,100 chunks（全量至 38,037 chunks / 148 source）
- `B-83644EN_06`（R-2000iC/270R 规格书）完全不在库内
- 解决方案：持续增量导入缺失 PDF，追踪 via `indexed_sources.jsonl`

## 推荐的加固建库脚本
`~/.hermes/scripts/build_edoc_bge_m3_robust.py`（已实现以下策略）：
1. **BATCH=48**（实测峰值安全，预热后从32加到48）
2. **SIGINT + SIGTERM 双捕获**，graceful shutdown
3. **ChromaDB count 优先**作为 resume 依据（比 checkpoint 文件更可靠）
4. **checkpoint 在 `coll.add()` 之后才保存**（关键：保证最多丢当前 batch，不会有部分写入）
5. **每50批做 count vs checkpoint 交叉验证**，差异 > batch×2 告警
6. **前2批预热测峰值**，估算更高 batch 是否安全并给出建议
7. GPU 显存 >6.5GB 告警 + gc + torch.cuda.empty_cache()
8. **进程锁** fcntl.LOCK_NB 防重复启动
9. checkpoint 用原子 rename（先写 .tmp 再 os.replace）
