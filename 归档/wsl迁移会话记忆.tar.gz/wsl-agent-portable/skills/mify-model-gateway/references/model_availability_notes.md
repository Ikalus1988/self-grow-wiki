# Model Availability & Testing Notes

## Session: 2026-05-26

### Tested Models & Results

| Model ID | Owner | Status | Notes |
|----------|-------|--------|-------|
| `azure_openai/gpt-5.5` | azure_openai | ✓ Works | HTTP 200, requires temperature=1 (not 0.2) |
| `azure_openai/gpt-5.4` | azure_openai | ✓ Works | HTTP 200, requires temperature=1 (not 0.2) |
| `ppio/pa/claude-opus-4-5-20251101` | ppio | ✓ Works | HTTP 200, older opus version |
| `ppio/pa/claude-opus-4-6` | ppio | ✗ Fails | HTTP 400 "Not supported model" |
| `ppio/pa/claude-opus-4-7` | ppio | ✗ Fails | HTTP 400 "Not supported model" |
| `xiaomi/mimo-v2-flash` | xiaomi | ✓ Works | HTTP 200, reliable baseline |

### Key Findings

1. **Temperature Parameter Issue**: 
   - `test_model.py` hardcodes `temperature=0.2`
   - GPT-5.x models only support `temperature=1` (default)
   - Workaround: Use direct API calls with `temperature=1` for GPT models

2. **Opus Version Availability**:
   - Only older opus version (4-5-20251101) accessible via ppio channel
   - Newer opus versions (4-6, 4-7) require specific API Key permissions
   - Contact admin for access to newer opus models

3. **Model Naming Convention**:
   - Always use `{owner}/{id}` format (e.g., `azure_openai/gpt-5.5`)
   - Bare model IDs return HTTP 400
   - Use `list_models.py --grep <model>` to find correct format

4. **API Key Permissions**:
   - Current key has access to azure_openai and ppio channels
   - Some channels/models may require additional permissions
   - Test with `test_model.py` before assuming availability

### Testing Recommendations

1. For GPT models: Use direct API calls with `temperature=1`
2. For Opus models: Test older versions first (4-5-20251101)
3. Always verify with `list_models.py` before testing
4. Check API Key permissions if models return 400 errors

### Workarounds

1. **Temperature Issue**: 
   ```python
   # Instead of test_model.py, use direct API call:
   data = {
       "model": "azure_openai/gpt-5.5",
       "messages": [{"role": "user", "content": "hi"}],
       "max_tokens": 50,
       "temperature": 1  # Not 0.2
   }
   ```

2. **Opus Access**:
   - Use `ppio/pa/claude-opus-4-5-20251101` as fallback
   - Contact admin for newer version access

### Future Testing

- Test `azure_openai/gpt-5.5` with different prompts
- Verify `ppio/pa/claude-opus-4-5-20251101` stability
- Monitor for new model additions to gateway
