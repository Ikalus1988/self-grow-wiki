# GitHub Actions Workflow Audit Checklist

Patterns from codewhale-watcher.yml v1→v3 code review (2026-06).

## Critical Checks

### 1. `gh issue list --json comments` returns COUNT, not content
The `comments` field in `gh issue list --json` is an integer (count), not the
comments array. `jq '.comments[].body'` on a number silently produces nothing.
Always fetch comments separately via `gh api repos/{owner}/{repo}/issues/{num}/comments`.

### 2. Regex matching for bot commands (e.g., `/claim`)
- `test("/claim")` matches `/claimed`, `no /claim here` — too broad
- `test("^/claim$")` — exact line match, too strict (excludes trailing text)
- `test("^/claim\\b")` — **recommended**: word boundary after command

### 3. Duplicate action prevention
Automated workflows that post comments MUST check if they already acted:
```bash
NOTIFIED=$(gh api "repos/.../issues/$NUM/comments" \
  --jq '[.[] | select(.body | test("NOTIFICATION_KEYWORD"))] | length')
[ "$NOTIFIED" -gt 0 ] && { echo "Already done. Skipping."; continue; }
```

### 4. Token exposure in shell
- `curl -H "Authorization: token $TOKEN"` — token visible in process list
- `GH_TOKEN=$TOKEN gh api ...` — token only in subprocess env, preferred
- Python `urllib.request` with file-read token — most secure, never in any output

### 5. PR reference detection
- `--search "refs/$NUM"` — only finds if PR body mentions `refs #NUM`
- `--search "\"#$NUM\""` — slightly better, matches `#NUM` anywhere
- Timeline API `GET /issues/{num}/timeline` with `event=cross-referenced` — most reliable

## Common Failure Modes

| Symptom | Cause | Fix |
|---------|-------|-----|
| Workflow instant fail, 0 jobs | Missing secret in repo Settings | Add `${{ secrets.XXX }}` value |
| `jq` produces empty output silently | Wrong field type (int vs array) | Check API docs for field type |
| Same comment posted every cycle | No dedup check before posting | Query existing comments first |
| 401 on `gh api` but `gh auth status` ok | Stale `GITHUB_TOKEN` env var | `unset GITHUB_TOKEN` first |
