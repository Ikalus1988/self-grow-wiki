# Path-Based CI Scope Detection

Skip heavy CI gates (pytest, coverage, quality score) for lightweight PRs (lessons, docs, config).

## Pattern

Add a scope detection step early in the workflow, then condition all heavy gates on `scope == full`.

### Step 1: Detect Scope

```yaml
- name: Detect Change Scope
  id: scope
  run: |
    BASE_SHA="${{ github.event.pull_request.base.sha }}"
    HEAD_SHA="${{ github.event.pull_request.head.sha }}"

    # workflow_dispatch has no PR context — always full
    if [ -z "$BASE_SHA" ] || [ -z "$HEAD_SHA" ]; then
      echo "scope=full" >> "$GITHUB_OUTPUT"
      exit 0
    fi

    CHANGED=$(git diff --name-only "$BASE_SHA" "$HEAD_SHA" | awk -F/ '{print $1}' | sort -u)

    if echo "$CHANGED" | grep -qv "^lessons$"; then
      echo "scope=full" >> "$GITHUB_OUTPUT"
    else
      echo "scope=lessons-only" >> "$GITHUB_OUTPUT"
    fi
```

### Step 2: Conditional Gates

```yaml
# Heavy gates — only for full scope
- name: Run Tests
  if: steps.scope.outputs.scope == 'full'
  run: pytest ...

- name: Quality Score
  if: steps.scope.outputs.scope == 'full'
  uses: ./.github/actions/score-agent

# Light gates — always run
- name: DCO Audit
  uses: Ikalus1988/dco-audit@v1

- name: Validate Lesson Schema
  run: python3 scripts/validate_lessons.py
```

### Step 3: Adaptive Audit Report

The report section should check `$SCOPE` and skip irrelevant sections:

```bash
SCOPE="${{ steps.scope.outputs.scope }}"

if [ "$SCOPE" = "full" ]; then
  REPORT+="### Quality Score: ${SCORE}/100"
  REPORT+="### Test Suite: ${OUTCOME}"
fi

# Verdict logic: lessons-only only checks DCO + schema
if [ "$SCOPE" = "lessons-only" ]; then
  # Only DCO + schema matter
  [ "$DCO_RESULT" != "true" ] && VERDICT_PASS=false
  [ "$SCHEMA" = "fail" ] && VERDICT_PASS=false
else
  # Full checks
  [ "$SCORE" -lt 40 ] && VERDICT_PASS=false
  [ "$OUTCOME" != "success" ] && VERDICT_PASS=false
fi
```

### Step 4: Lightweight Deps for Lessons-Only

Lessons-only PRs still need Python for schema validation, but skip heavy deps:

```yaml
- name: Install Dependencies
  if: steps.scope.outputs.scope == 'full'
  run: pip install -r requirements.txt && pip install pytest pytest-cov

- name: Install Schema Dependencies
  if: steps.scope.outputs.scope == 'lessons-only'
  run: pip install pyyaml jsonschema
```

## Design Decisions

1. **`awk -F/ '{print $1}'`** — gets top-level directory from changed file paths. Simple, no git plumbing needed.
2. **`grep -qv "^lessons$"`** — if ANY changed file is NOT under `lessons/`, it's full scope. This means mixed PRs (lessons + code) always get full treatment.
3. **DCO always runs** — sign-off is required regardless of change type.
4. **Schema validation always runs** — even for lessons-only (that's the whole point).
5. **Auto-merge still runs** — lessons-only PRs that pass DCO + schema can auto-merge.

## Acceptance Criteria (from Issue #230)

- [x] Lessons-only PRs skip pytest, coverage, quality score gates
- [x] DCO and schema validation still run on all PRs
- [x] PR with mixed changes (lessons + code) triggers full pipeline
- [x] Auto-merge works for passing lessons-only PRs

## Example: MisakaNet pr-checks.yml

See the full implementation at `.github/workflows/pr-checks.yml` in Ikalus1988/MisakaNet
(branch `feat/230-path-based-ci`, commit `24dae87`).
