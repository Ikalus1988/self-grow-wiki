# GitHub Actions 0-Jobs Failure — Differential Diagnosis

When a workflow run completes in the same second it was created (`created_at == updated_at`), with `conclusion: failure` and `total_count: 0` jobs, the failure happened **before any job started**. No logs are generated, no annotations are created, and the error message is generic or absent.

## Key Principle: Check ALL Causes, Not Just the First

All three causes produce **identical symptoms** (0 jobs, instant failure, no error).
Finding one cause does NOT mean you're done — the workflow may have multiple issues
叠加 (stacking). In the MisakaNet case, fixing the non-ASCII characters alone didn't
work because the secret name was also wrong. Only after fixing BOTH did the workflow
succeed. Always verify by dispatching after each fix.

## Three Known Causes (check all three)

### 1. Missing or mismatched secret name
**Symptom**: Workflow references `${{ secrets.FOO }}` but no secret named `FOO` exists.
**Diagnosis**: `GET /repos/{owner}/{repo}/actions/secrets` → compare names against every `${{ secrets.XXX }}` in the YAML.
**Fix**: Create the secret with the exact name, or fix the name in the YAML.
**Note**: Secret names are case-sensitive. `ZSXH1990_PAT` ≠ `ZSXH1990_Pat`.

### 2. Non-ASCII characters in YAML
**Symptom**: Workflow contains emoji (🚀✅⚠️⏰📋), CJK characters in comments, em-dash (—), or Unicode arrows (→).
**Diagnosis**: `GET /repos/{owner}/{repo}/contents/{path}` → decode base64 → check for bytes > 127.
**Fix**: Rewrite entire file in pure ASCII. Replace:
- `✅` → `OK` or `[OK]`
- `⚠️` → `[WARN]` or `!!`
- `🚀` → remove or `==>`
- `⏰` → `(timeout)`
- `📋` → `>>`
- `—` → `-`
- `→` -> `->`
- CJK comments → English equivalents

### 3. YAML syntax error
**Symptom**: Malformed YAML (bad indentation, missing colon, unclosed quote).
**Diagnosis**: Run `actionlint` locally or use a YAML linter.
**Fix**: Fix the syntax error.

## Shared Diagnostic Steps

```python
# 1. Check secrets
import urllib.request, json
secrets = api("/repos/{owner}/{repo}/actions/secrets")
print([s['name'] for s in secrets.get('secrets', [])])

# 2. Check raw file content for non-ASCII
import base64, re
file = api("/repos/{owner}/{repo}/contents/{path}")
content = base64.b64decode(file['content'])
non_ascii = [(i, content[i]) for i in range(len(content)) if content[i] > 127]
print(f"Non-ASCII bytes: {len(non_ascii)}")

# 3. Check workflow state
wf = api("/repos/{owner}/{repo}/actions/workflows/{id}")
print(f"State: {wf['state']}")  # Should be 'active'

# 4. Try manual dispatch
req = POST "/repos/{owner}/{repo}/actions/workflows/{id}/dispatches"
# 204 = success, 422 = indexing delay or YAML issue
```

## Real-World Example (2026-06-09)

MisakaNet's `codewhale-watcher.yml` failed with all three issues simultaneously:
1. Secret `ZSXH1990_PAT` existed but workflow referenced `SHELDON_PAT` (name mismatch)
2. File contained emoji (🚀📋⏰✅⚠️), CJK comments (列出生, 检查是否), and em-dash (—)
3. Both caused the same symptom: 0 jobs, instant failure, no error message

Resolution: Rewrote entire workflow in pure ASCII + fixed secret name → `workflow_dispatch` returned HTTP 204, all 7 steps passed. Secret was later renamed again (ZSXH1990_PAT → SHELDON_PAT), requiring a second commit to update the YAML reference. Lesson: when renaming secrets, update ALL workflow files that reference them in the same commit.
