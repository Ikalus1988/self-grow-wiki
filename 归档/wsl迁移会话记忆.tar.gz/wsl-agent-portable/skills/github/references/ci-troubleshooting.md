# CI Troubleshooting Quick Reference

Common CI failure patterns and how to diagnose them from the logs.

## Reading CI Logs

```bash
# With gh
gh run view <RUN_ID> --log-failed

# With curl — download and extract
curl -sL -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/actions/runs/<RUN_ID>/logs \
  -o /tmp/ci-logs.zip && unzip -o /tmp/ci-logs.zip -d /tmp/ci-logs
```

## Common Failure Patterns

### Test Failures

**Signatures in logs:**
```
FAILED tests/test_foo.py::test_bar - AssertionError
E       assert 42 == 43
ERROR tests/test_foo.py - ModuleNotFoundError
```

**Diagnosis:**
1. Find the test file and line number from the traceback
2. Use `read_file` to read the failing test
3. Check if it's a logic error in the code or a stale test assertion
4. Look for `ModuleNotFoundError` — usually a missing dependency in CI

**Common fixes:**
- Update assertion to match new expected behavior
- Add missing dependency to requirements.txt / pyproject.toml
- Fix flaky test (add retry, mock external service, fix race condition)

---

### Lint / Formatting Failures

**Signatures in logs:**
```
src/auth.py:45:1: E302 expected 2 blank lines, got 1
src/models.py:12:80: E501 line too long (95 > 88 characters)
error: would reformat src/utils.py
```

**Diagnosis:**
1. Read the specific file:line numbers mentioned
2. Check which linter is complaining (flake8, ruff, black, isort, mypy)

**Common fixes:**
- Run the formatter locally: `black .`, `isort .`, `ruff check --fix .`
- Fix the specific style violation by editing the file
- If using `patch`, make sure to match existing indentation style

---

### Type Check Failures (mypy / pyright)

**Signatures in logs:**
```
src/api.py:23: error: Argument 1 to "process" has incompatible type "str"; expected "int"
src/models.py:45: error: Missing return statement
```

**Diagnosis:**
1. Read the file at the mentioned line
2. Check the function signature and what's being passed

**Common fixes:**
- Add type cast or conversion
- Fix the function signature
- Add `# type: ignore` comment as last resort (with explanation)

---

### Build / Compilation Failures

**Signatures in logs:**
```
ModuleNotFoundError: No module named 'some_package'
ERROR: Could not find a version that satisfies the requirement foo==1.2.3
npm ERR! Could not resolve dependency
```

**Diagnosis:**
1. Check requirements.txt / package.json for the missing or incompatible dependency
2. Compare local vs CI Python/Node version

**Common fixes:**
- Add missing dependency to requirements file
- Pin compatible version
- Update lockfile (`pip freeze`, `npm install`)

---

### Permission / Auth Failures

**Signatures in logs:**
```
fatal: could not read Username for 'https://github.com': No such device or address
Error: Resource not accessible by integration
403 Forbidden
```

**Diagnosis:**
1. Check if the workflow needs special permissions (token scopes)
2. Check if secrets are configured (missing `GITHUB_TOKEN` or custom secrets)

**Common fixes:**
- Add `permissions:` block to workflow YAML
- Verify secrets exist: `gh secret list` or check repo settings
- For fork PRs: some secrets aren't available by design

---

### Timeout Failures

**Signatures in logs:**
```
Error: The operation was canceled.
The job running on runner ... has exceeded the maximum execution time
```

**Diagnosis:**
1. Check which step timed out
2. Look for infinite loops, hung processes, or slow network calls

**Common fixes:**
- Add timeout to the specific step: `timeout-minutes: 10`
- Fix the underlying performance issue
- Split into parallel jobs

---

### Docker / Container Failures

**Signatures in logs:**
```
docker: Error response from daemon
failed to solve: ... not found
COPY failed: file not found in build context
```

**Diagnosis:**
1. Check Dockerfile for the failing step
2. Verify the referenced files exist in the repo

**Common fixes:**
- Fix path in COPY/ADD command
- Update base image tag
- Add missing file to `.dockerignore` exclusion or remove from it

---

## Auto-Fix Decision Tree

```
CI Failed
├── Test failure
│   ├── Assertion mismatch → update test or fix logic
│   └── Import/module error → add dependency
├── Lint failure → run formatter, fix style
├── Type error → fix types
├── Build failure
│   ├── Missing dep → add to requirements
│   └── Version conflict → update pins
├── Permission error → update workflow permissions (needs user)
└── Timeout → investigate perf (may need user input)
```

## Re-running After Fix

```bash
git add <fixed_files> && git commit -m "fix: resolve CI failure" && git push

# Then monitor
gh pr checks --watch 2>/dev/null || \
  echo "Poll with: curl -s -H 'Authorization: token ...' https://api.github.com/repos/.../commits/$(git rev-parse HEAD)/status"
```

---

## Shell Scripting Anti-Patterns in CI Workflows

### The `break` + `exit 1` Trap

The most common shell scripting anti-pattern in CI/CD workflows:

```yaml
- name: Step with retry
  id: my_step
  run: |
    while [ $ATTEMPT -lt 5 ]; do
      ATTEMPT=$((ATTEMPT + 1))
      if command; then
        echo "SUCCESS=true" >> $GITHUB_OUTPUT
        break          # ← exits while loop
      fi
    done
    # ← break and exhaustion BOTH reach here!
    echo "FATAL: Could not..."
    exit 1  # ← ALWAYS executes, even after break!
```

**Why it fails:** `break` exits the while loop body but execution continues to the statement AFTER `done`. An unconditional `exit 1` after `done` fires regardless — it catches loop exhaustion AND successful exits equally.

**Symptom:** The command succeeds (resource updated, containing the right values and matching the CI job timestamps) but the step reports exit code 1, preventing downstream steps from executing. The step runs in <1 second because `break` fires on the first attempt.

**Fix:** Use a flag:

```yaml
  run: |
    REGISTERED=false
    while [ $ATTEMPT -lt 5 ]; do
      ...
      if command; then
        echo "output=value" >> $GITHUB_OUTPUT
        REGISTERED=true
        break
      fi
    done
    if [ "$REGISTERED" != "true" ]; then
      echo "FATAL: Could not..."
      exit 1
    fi
```

### Detection: Timestamp Correlation

When a CI job reports failure but the resource was updated:

1. **Measure duration:** Check `started_at` vs `completed_at` from the job API. If the step ran for < time_needed_for_one_retry_cycle (e.g., 1 second when sleep=2), the loop exited via `break`, not exhaustion.
2. **Verify resource state independently:** Check the affected resource (file in repo, API endpoint, deployed artifact) for the expected update. Use the API, don't rely on CI logs.
3. **Check downstream effects:** If the failed step should produce outputs consumed by the next step (GITHUB_OUTPUT, artifacts), verify those downstream effects exist. Missing downstream output + successful resource update = the `break`+`exit` anti-pattern.

### Testing CI Workflow Changes

When modifying a CI workflow (especially registration or auto-merge workflows):

1. **Create a test trigger** (e.g., a test issue or test PR) that will invoke the workflow
2. **Wait for the run to complete** (monitor via API or gh CLI)
3. **Verify the full chain:** Not just that the step "passed" — check that downstream effects occurred (comments, commits, state changes)
4. **Clean up test artifacts** by closing the test issue/PR, and optionally reverting any state changes (counter.json, etc.)
5. **Delete the test issue:** Close via API to keep the repo clean

This prevents the "workflow says success but nothing actually happened" class of failures, and ensures you don't leave test artifacts in a production repo.
