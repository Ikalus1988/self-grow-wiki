# GitHub 连通性诊断清单

当 GitHub 操作失败时，按此顺序排查：

## 快速诊断（一行命令）

```bash
# ICMP + 端口 + API 全测
ping -c 2 github.com && timeout 5 bash -c 'echo > /dev/tcp/github.com/443' && curl -s -o /dev/null -w "%{http_code}" https://api.github.com/rate_limit
```

## 完整诊断

```bash
# 1. ICMP
ping -c 3 github.com

# 2. HTTPS 443
timeout 5 bash -c 'echo > /dev/tcp/github.com/443 && echo "443 OPEN"'

# 3. SSH 22
timeout 5 bash -c 'echo > /dev/tcp/github.com/22 && echo "22 OPEN"'

# 4. API 可达性
curl -s -o /dev/null -w "API: %{http_code} %{time_total}s\n" https://api.github.com/rate_limit

# 5. Git HTTPS 认证
git ls-remote --heads https://github.com/owner/repo.git 2>&1 | head -3

# 6. SSH 认证
ssh -T -o ConnectTimeout=8 git@github.com 2>&1 | head -1

# 7. gh CLI 状态
gh auth status 2>&1 | head -3
```

## 常见问题速查

| 症状 | 根因 | 修复 |
|------|------|------|
| ICMP 通但 443 超时 | 防火墙/GFW | 配代理或用 SSH |
| API 200 但 git push 超时 | GFW 限速 git smart HTTP | 改用 SSH: `git remote set-url origin git@github.com:...` |
| SSH 通但 push 404 | SSH key 账号无 repo 权限 | 检查 `ssh -T git@github.com` 输出的用户名 |
| API 401 | token 过期 | 更新 `~/.git-credentials` 或 `gh auth login` |
| API 404 (私有 repo) | 无认证 | 用 `git remote set-url https://user:token@github.com/...` |
| git push 超时 | WSL 网络 + GFW | 优先 SSH，其次代理 |

## WSL 特有问题

- SSH key 可能属于不同账号（如 sheldonisspark-lab vs Ikalus1988），检查 `ssh -T` 输出
- 私有仓库需要对应账号的 token，SSH key 账号可能无权限
- `/etc/hosts` 中硬编码 GitHub IP 可能过期
