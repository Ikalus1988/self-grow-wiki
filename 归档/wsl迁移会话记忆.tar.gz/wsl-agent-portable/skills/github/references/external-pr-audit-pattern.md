# External PR Audit Pattern

Audit PRs a user/org submitted to OTHER repos — interaction history, success/failure patterns, CI status.

## When to Use

- "检查大号提给别人的 PR"
- "看下 Ikalus1988 外部 PR 状态"
- "巡视我提交的 PR 进展"
- Periodic patrol: check both owned repos AND external submissions

## API Queries

### 1. Search Authored PRs (open + closed)

```python
import urllib.request, json

token = open('/tmp/.tok').read().strip()

def api(url):
    req = urllib.request.Request(url, headers={
        'Authorization': f'token {token}',
        'Accept': 'application/vnd.github+json'
    })
    return json.loads(urllib.request.urlopen(req, timeout=15).read())

# Open PRs across all repos
open_prs = api(f'https://api.github.com/search/issues?q=type:pr+state:open+author:{USER}&per_page=30&sort=updated&order=desc')

# Closed/merged PRs
closed_prs = api(f'https://api.github.com/search/issues?q=type:pr+state:closed+author:{USER}&per_page=30&sort=updated&order=desc')
```

### 2. Per-PR Detail (files, CI, comments, reviews)

```python
for item in search['items']:
    repo = item['repository_url'].split('repos/')[-1]
    num = item['number']
    
    # PR details (mergeable, additions, deletions)
    pr = api(f'https://api.github.com/repos/{repo}/pulls/{num}')
    
    # CI status
    sha = pr['head']['sha']
    status = api(f'https://api.github.com/repos/{repo}/commits/{sha}/status')
    checks = api(f'https://api.github.com/repos/{repo}/commits/{sha}/check-runs')
    
    # Comments (interaction history)
    comments = api(f'https://api.github.com/repos/{repo}/issues/{num}/comments')
    
    # Reviews
    reviews = api(f'https://api.github.com/repos/{repo}/pulls/{num}/reviews')
```

### 3. Filter Out Own Repos

```python
# Skip PRs in repos you own (those are internal, not "external")
for item in search['items']:
    repo = item['repository_url'].split('repos/')[-1]
    if 'MisakaNet' in repo:  # or your own repo pattern
        continue
```

## Output Format

For each PR, report:
```
#NNN | owner/repo
Title: ...
Created: YYYY-MM-DD | Closed: YYYY-MM-DD
Status: MERGED / CLOSED / OPEN
Changed: N files | +A -D
CI: success/pending/fail (list each check)
Comments (N):
  user (date): first 150 chars...
Reviews (N):
  user: APPROVED/CHANGES_REQUESTED/COMMENTED
Reactions: N
```

## Analysis Patterns

After gathering all PRs, analyze:

1. **Success rate**: merged / total closed
2. **Common failure modes**:
   - Duplicate submissions (same PR to same repo multiple times)
   - Ignoring project conventions (unsigned commits, missing templates)
   - Not checking existing PRs/issues before submitting
   - Being preempted by other contributors
   - Bot auto-closures (template not filled, etc.)
3. **Interaction quality**:
   - Zero comments = maintainer inactive OR PR ignored
   - Bot-only comments = automated rejection
   - Human feedback + merge = healthy contribution
   - Human feedback + no response = stalemate
4. **Timing**:
   - How long from creation to first response
   - How long from creation to merge/close
   - Bump/follow-up effectiveness

## Pitfalls

1. **Search API rate limit**: 30 requests/minute for authenticated users. Batch queries.
2. **`state: closed` includes merged**: Check `pull_request.merged_at` or `merged` field in PR detail to distinguish.
3. **Pagination**: `per_page=30` is max for search. Use `page=2` etc. for more.
4. **Own repos vs external**: Filter out repos you own — those are internal PRs, not "contributing to other projects".
5. **Body may be null**: Some PRs have no body. Handle gracefully.
6. **`repository_url` format**: Always `https://api.github.com/repos/{owner}/{repo}` — parse with `.split('repos/')[-1]`.

## Read-Only Rule

When this pattern is used as part of a **patrol/audit** (not active PR management):
- **Only gather and report** — do not comment, close, merge, or take any action on external repos
- Present the analysis, let the user decide next steps
- This is distinct from "CodeWhale PR review" where you DO act (review + merge on owned repos)
