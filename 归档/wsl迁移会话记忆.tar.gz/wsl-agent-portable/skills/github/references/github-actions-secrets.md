# GitHub Actions Secrets Management via API

## Prerequisites
- **Repo admin** account (owner, not collaborator)
- Classic PAT with `repo` scope, OR fine-grained PAT with Administration (read+write)
- `pynacl` library (`pip install pynacl` or `uv pip install pynacl --python /path/to/venv/bin/python3`)

## Set a Secret

```python
import urllib.request, json, base64, pathlib
from nacl import encoding, public

PAT = "ghp_owner_token..."
REPO = "owner/repo"
SECRET_NAME = "MY_SECRET"
SECRET_VALUE = "the-secret-value"

# 1. Get public key for encryption
req = urllib.request.Request(
    f"https://api.github.com/repos/{REPO}/actions/secrets/public-key",
    headers={"Authorization": f"token {PAT}", "Accept": "application/vnd.github+json"}
)
key_data = json.loads(urllib.request.urlopen(req).read())

# 2. Encrypt with libsodium sealed box
pubkey = base64.b64decode(key_data["key"])
sealed = public.PublicBox(pubkey)
encrypted = base64.b64encode(sealed.encrypt(SECRET_VALUE.encode())).decode()

# 3. PUT secret
body = json.dumps({"encrypted_value": encrypted, "key_id": key_data["key_id"]}).encode()
req2 = urllib.request.Request(
    f"https://api.github.com/repos/{REPO}/actions/secrets/{SECRET_NAME}",
    data=body,
    headers={"Authorization": f"token {PAT}", "Accept": "application/vnd.github+json", "Content-Type": "application/json"},
    method="PUT"
)
resp = urllib.request.urlopen(req2)
print(f"Secret set: HTTP {resp.status}")  # 201 = created, 204 = updated
```

## Using gh CLI (simpler, handles encryption)

```bash
# gh handles pynacl internally — no manual encryption needed
GH_TOKEN=*** gh secret set MY_SECRET --repo owner/repo --body "the-value"
```

## List Secrets (admin only)

```python
req = urllib.request.Request(
    f"https://api.github.com/repos/{REPO}/actions/secrets",
    headers={"Authorization": f"token {PAT}", "Accept": "application/vnd.github+json"}
)
secrets = json.loads(urllib.request.urlopen(req).read())
print([s["name"] for s in secrets.get("secrets", [])])
```

## Common Errors

| Error | Cause |
|-------|-------|
| 403 on `/actions/secrets/public-key` | PAT lacks admin rights on the repo |
| 403 on `/actions/secrets` (list) | Non-owner PAT — secrets listing requires repo admin |
| 422 on secret set | Invalid key_id or encrypted_value format |
| Empty secrets list `[]` | Either no secrets exist, or PAT lacks admin read access |

## Workflow Instant Failure Diagnosis

If a workflow run shows `conclusion: failure` with 0 jobs and `created_at == updated_at`:
1. Check if referenced `${{ secrets.XXX }}` exist in repo → Settings → Secrets
2. Use `GET /repos/{owner}/{repo}/actions/secrets` with an admin PAT to verify
3. Common: workflow references `ZSXH1990_PAT` but only `GITHUB_TOKEN` exists
