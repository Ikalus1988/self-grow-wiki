# Pre-Commit Hook Contribution to Ikalus1988/pre-commit-hooks

Fork of `pre-commit/pre-commit-hooks`. Adding a new hook requires changes in 5 files + full validation.

## Checklist (all 5 files)

| # | File | Change |
|---|------|--------|
| 1 | `pre_commit_hooks/<hook>.py` | Hook implementation |
| 2 | `tests/<hook>_test.py` | pytest test cases |
| 3 | `.pre-commit-hooks.yaml` | Register hook (id, entry, language, stages) |
| 4 | `setup.cfg` | Add `console_scripts` entry point |
| 5 | `README.md` | Add `#### \`<hook-id>\`` section |

## Hook Implementation Pattern

```python
from __future__ import annotations
import sys
from collections.abc import Sequence

def main(argv: Sequence[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]
    # ... validation logic ...
    return 0  # pass, or 1  # fail

if __name__ == '__main__':
    raise SystemExit(main())
```

- Zero external dependencies preferred (pure stdlib)
- `main()` takes filename(s) from `argv`, returns int exit code
- Print errors to `sys.stderr`

## Registration

### `.pre-commit-hooks.yaml`

```yaml
-   id: check-dco
    name: check dco sign-off
    description: verifies ...
    entry: check-dco          # matches console_scripts name
    language: python
    stages: [commit-msg]      # default is [pre-commit, pre-push, manual]
```

### `setup.cfg`

```ini
[options.entry_points]
console_scripts =
    check-dco = pre_commit_hooks.check_dco:main
```

### `README.md`

Must contain backtick-wrapped hook ID: `` #### `check-dco` `` — the
`test_readme_contains_all_hooks` test asserts every hook ID from
`.pre-commit-hooks.yaml` appears as `` `{id}` `` in README.

## Validation Before Push

```bash
cd pre-commit-hooks
pip install -e . pytest flake8 mypy

# 1. Unit tests (AC-1~10)
pytest tests/<hook>_test.py -v --tb=short

# 2. README consistency (AC-CI-6)
pytest tests/readme_test.py -v

# 3. Full suite (419+ tests)
pytest tests/ -v --tb=short

# 4. Lint (AC-CI-4, AC-CI-5)
flake8 pre_commit_hooks/<hook>.py tests/<hook>_test.py
mypy pre_commit_hooks/<hook>.py

# 5. E2E CLI
echo -e "msg\n\nSigned-off-by: A <a@b>" > /tmp/msg
python3 pre_commit_hooks/<hook>.py /tmp/msg  # expect exit 0
```

## CI Matrix (GitHub Actions)

Uses `asottile/workflows/.github/workflows/tox.yml@v1.8.1` reusable workflow.

```yaml
# .github/workflows/main.yml
jobs:
  main-linux:
    uses: asottile/workflows/.github/workflows/tox.yml@v1.8.1
    with:
      env: '["py310", "py311", "py312", "py313"]'
      os: ubuntu-latest
  main-windows:
    uses: asottile/workflows/.github/workflows/tox.yml@v1.8.1
    with:
      env: '["py310"]'
      os: windows-latest
```

The reusable workflow automatically creates a `collector` job that depends on
all tox matrix jobs. Job names become: `main-linux / py310`, `main-linux / collector`, etc.

AC-CI-2 (`main-linux / collector` + `main-windows / collector`) passes automatically
if all tox matrix jobs pass — no separate collector testenv needed.

## Pitfalls

### flake8 E501 is NOT ignored despite `tox.ini [pep8]` section

The `tox.ini` has `[pep8] ignore=E265,E501,W504` but flake8 7.x reads the
`[flake8]` section, not `[pep8]`. The `.pre-commit-config.yaml` runs flake8
with default max-line-length=79. **All code must be ≤79 chars per line.**

Pattern for breaking long strings:
```python
msg.write_text(
    'feat: add search\n\n'
    'Signed-off-by: Alice <alice@example.com>\n',
)
```

### Regex multiline for commit message matching

When matching lines inside a multi-line commit message, always use `re.MULTILINE`:
```python
RE = re.compile(r'^pattern$', re.MULTILINE)
```
Without it, `^` and `$` only match the start/end of the entire string.

### commit-msg stage hooks

`stages: [commit-msg]` in `.pre-commit-hooks.yaml` means the hook runs at
commit-msg stage. Users must install with:
```bash
pre-commit install --hook-type commit-msg
```
Plain `pre-commit install` only injects pre-commit stage hooks.

### Push credentials

See github skill pitfall #32 (`.git-credentials` first-match) and #33 (`gho_` can't push).
The Ikalus1988 fork uses HTTPS with credential store.
