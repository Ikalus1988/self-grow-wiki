# GitHub Actions YAML Pitfalls

## When to Use
- Creating or editing `.github/workflows/*.yml`
- Debugging workflow runs with 0 jobs (instant failure)
- Workflow dispatch returns 422 "does not have trigger"
- Understanding why a workflow fails on push but has no push trigger

## Pitfall 1: Non-ASCII Characters Cause 0-Jobs Failure

**Symptom**: Workflow runs fail instantly (created_at == updated_at), 0 jobs, no error message, no annotations, no logs.

**Root cause**: GitHub's YAML parser rejects files containing non-ASCII bytes. This includes:
- Emoji (U+1F000+, e.g. 🚀📋⏰✅⚠️)
- CJK characters in comments (Chinese/Japanese/Korean)
- Em dash (U+2014 `—`) and other Unicode punctuation
- Unicode arrows (→←↑↓)

**Fix**: Replace ALL non-ASCII with pure ASCII equivalents:
- `🚀` → remove or use `===`
- `📋` → remove
- `⏰` → `Window expired` (text)
- `✅` → `OK` or `PASS`
- `⚠️` → `Warn` or `WARN`
- `—` → `-`
- `→` → `->`
- Chinese comments → English or remove

**Verification**: After push, check that the new run has `jobs > 0`. A run with `jobs=0` and `conclusion=failure` within the same second as `created_at` means YAML parse rejection.

**Exception**: `actions/github-script` JavaScript blocks can contain non-ASCII in string literals (it's inside a YAML string). But top-level YAML keys, step names, and `run:` shell blocks cannot.

## Pitfall 2: Secret Name Must Match Exactly

**Symptom**: Same as Pitfall 1 (0 jobs, instant failure) — or the step that uses the secret fails silently.

**Root cause**: `${{ secrets.FOO_BAR }}` references a secret named `FOO_BAR` in repo Settings → Secrets. If the secret doesn't exist under that exact name:
- GitHub may silently substitute empty string (step fails)
- Or the entire workflow YAML validation fails (0 jobs)

**Common mistakes**:
- Renaming a secret in Settings but not updating the workflow
- Using `ZSXH1990_PAT` in the workflow when the secret is `SHELDON_PAT`
- Typos: `GITHUB_TOEKN` vs `GITHUB_TOKEN`

**Verification**: Check repo secrets list:
```python
# Via API (needs admin token)
api("https://api.github.com/repos/{owner}/{repo}/actions/secrets")
```

## Pitfall 3: Complex `${{ }}` Expressions Can Break YAML

**Symptom**: 0 jobs failure even though the file looks syntactically correct.

**Root cause**: Overly complex GitHub Actions expressions in YAML values can confuse the parser:
```yaml
# BAD — long expression in ref: field
ref: ${{ github.event_name == 'workflow_dispatch' && github.event.inputs.pr_number != '' && format('refs/pull/{0}/head', github.event.inputs.pr_number) || github.ref }}

# GOOD — use default checkout, handle PR ref in a separate step
ref: ${{ github.ref }}
```

**Fix**: Simplify expressions. Move complex logic into shell `run:` blocks or `actions/github-script` where you have full control.

## Pitfall 4: `actions/github-script` Template Injection Fragility

**Symptom**: Workflow intermittently fails or produces unexpected behavior.

**Root cause**: Heavy `${{ }}` interpolation inside `actions/github-script` JavaScript:
```yaml
# BAD — mixing GitHub expressions with JS
script: |
  const prNumber = '${{ github.event.inputs.pr_number }}'
    ? parseInt('${{ github.event.inputs.pr_number }}')
    : context.issue.number;

# GOOD — use github-script's built-in context
script: |
  const prNumber = context.payload.inputs?.pr_number || context.issue.number;
```

**Fix**: Prefer `github.context` and `github.rest` over `${{ }}` template expressions inside `actions/github-script`.

## Pitfall 5: 0-Jobs Push Runs for Non-Push Workflows

**Confusion**: "My workflow only triggers on `pull_request`, but I see failed push runs with 0 jobs."

**Normal behavior**: When a workflow YAML is **invalid**, GitHub creates a failed run (0 jobs) for EVERY push event, even if the workflow has no `push` trigger. This is because GitHub validates all workflow files on push.

**Abnormal behavior**: When a workflow YAML is **valid**, GitHub does NOT create a run for events that don't match the trigger. If you see no push runs for a pull_request-only workflow, that's correct behavior.

**Decision tree**:
- Invalid YAML + push event → failed run with 0 jobs (fix the YAML)
- Valid YAML + push event → no run created (expected)
- Valid YAML + matching event → run with jobs (working)

## Pitfall 6: workflow_dispatch 422 on New Workflows

**Symptom**: `gh workflow run` or API dispatch returns HTTP 422 "Workflow does not have 'workflow_dispatch' trigger" even though the YAML clearly has it.

**Root cause**: GitHub needs time to index newly pushed workflow files. The `workflow_dispatch` trigger may not be recognized immediately.

**Fix**: Wait 1-5 minutes, or push a small commit to re-trigger indexing. Alternatively, wait for the first scheduled run.

## Pitfall 7: Heredoc in `run: |` Block Scalars Breaks YAML

**Symptom**: YAML validation fails with `while scanning an alias` or `while scanning a simple key` on lines inside a `run: |` block that look like valid bash.

**Root cause**: Bash heredoc delimiters (`EOF`, `SUMMARY_EOF`, etc.) **must** appear at column 0 for bash to recognize them. But in YAML, a `run: |` block scalar's indentation is set by the first content line (e.g., 10 spaces). Any subsequent line with **less** indentation (like column 0) terminates the block scalar, causing the YAML parser to interpret the heredoc delimiter and content as top-level YAML keys/anchors.

```yaml
# BAD — SUMMARY_EOF at col 0 ends the YAML block scalar
      - name: Write Summary
        run: |
          cat <<'SUMMARY_EOF' >> "$GITHUB_STEP_SUMMARY"
## Section Title
Content here
SUMMARY_EOF
```

**Fix**: Replace heredocs with `printf` (single-line) or brace-group `echo` blocks:

```yaml
# GOOD — printf stays within the run block's indentation
      - name: Write Summary
        run: |
          printf '## Section Title\n\nContent here\n\n' >> "$GITHUB_STEP_SUMMARY"

# ALSO GOOD — brace-group echo (multi-line content)
      - name: Write Summary
        run: |
          {
            echo "## Section Title"
            echo ""
            echo "Content here"
            echo ""
          } >> "$GITHUB_STEP_SUMMARY"
```

**Key constraint**: Inside `run: |`, every line must be indented at least as much as the first content line. Heredoc delimiters at column 0 violate this. Use `printf` with `\n` escapes for short content, or brace-grouped `echo` for longer content.

## Quick Checklist Before Pushing a New Workflow

```
[ ] All non-ASCII characters removed (emoji, CJK, em-dash)
[ ] Secret names match exactly with repo Settings
[ ] No overly complex ${{ }} expressions in YAML values
[ ] actions/github-script uses context.* not ${{ }} where possible
[ ] LF line endings (no CRLF)
[ ] workflow_dispatch: has empty line after it (or at least valid YAML)
[ ] No heredoc delimiters (EOF, etc.) at column 0 inside run: | blocks
[ ] YAML validates: python3 -c "import yaml; yaml.safe_load(open('file.yml'))"
[ ] printf or { echo; } used instead of heredoc for GITHUB_STEP_SUMMARY writes
```

## Debugging: When You Get 0-Jobs Failure

1. Check if YAML has non-ASCII: `python3 -c "data=open('file.yml','rb').read(); print(any(b>127 for b in data))"`
2. Check secret references: `grep -oP '\$\{\{\s*secrets\.(\w+)' file.yml`
3. Try dispatch via API — 422 means YAML is broken, 204 means it works
4. Check if other workflows in the repo also fail (repo-wide issue vs file-specific)
