---
name: add-pre-commit-hook
description: Add a new hook to the Ikalus1988/pre-commit-hooks fork (pre-commit/pre-commit-hooks upstream). Covers hook code, tests, registration, README sync, lint, CI.
tags: [github, pre-commit, hooks, python, CI]
triggers:
  - add hook to pre-commit-hooks
  - new pre-commit hook
  - check-dco hook
  - register hook in setup.cfg
---

# Add a New Hook to pre-commit-hooks

Repo: `Ikalus1988/pre-commit-hooks` (fork of `pre-commit/pre-commit-hooks`).

## 5 Files to Touch

| # | File | What |
|---|------|------|
| 1 | `pre_commit_hooks/<hook_name>.py` | Hook implementation — pure Python, zero deps if possible |
| 2 | `tests/<hook_name>_test.py` | pytest cases using `tmp_path` fixture |
| 3 | `.pre-commit-hooks.yaml` | Register hook (id, name, description, entry, language, stages) |
| 4 | `setup.cfg` | Add `console_scripts` entry point |
| 5 | `README.md` | Add `#### \`<hook-id>\`` section in alphabetical order |

## Hook Code Pattern

```python
from __future__ import annotations
import sys
from collections.abc import Sequence

def main(argv: Sequence[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]
    # ... validate, return 0 (pass) or 1 (fail)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
```

- Use `argparse` if args needed; for simple hooks, just read `argv[0]` (filename).
- Print errors to `stderr`.
- Return `0` for pass, `1` for fail.

## Test Pattern

```python
from __future__ import annotations
from pre_commit_hooks.<hook_name> import main

def test_pass(tmp_path):
    f = tmp_path / 'msg'
    f.write_text('valid content\n')
    assert main([str(f)]) == 0

def test_fail(tmp_path):
    f = tmp_path / 'msg'
    f.write_text('invalid\n')
    assert main([str(f)]) == 1
```

- Use `tmp_path` (pytest built-in), NOT `/tmp` manually.
- No `import pytest` unless using `@pytest.mark` or `pytest.raises`.
- Group tests: success cases → failure cases → CLI integration.

## `.pre-commit-hooks.yaml` Entry

```yaml
-   id: <hook-id>
    name: <human readable name>
    description: <what it does>
    entry: <console-script-name>
    language: python
    stages: [<stage>]  # e.g. [commit-msg], [pre-commit]
```

- Insert in **alphabetical order** by id (repo convention).
- `stages: [commit-msg]` for message-level hooks; omit for default `pre-commit`.

## `setup.cfg` Entry

Add under `[options.entry_points] > console_scripts`, alphabetical:

```ini
<hook-script-name> = pre_commit_hooks.<module_name>:main
```

## README Entry

Add `#### \`<hook-id>\`` section in alphabetical order among existing hooks. Include:
- One-line description
- Usage notes / args if any

**Critical**: `tests/readme_test.py::test_readme_contains_all_hooks` verifies that every hook ID from `.pre-commit-hooks.yaml` appears as `` `<hook-id>` `` in README.md. CI fails if any are missing.

## Lint Checks (pre-commit.ci / CI)

- **flake8**: max line length 79 chars (no `.flake8` config override in repo). `pep8` section in tox.ini is NOT read by flake8.
- **mypy**: `disallow_untyped_defs = true` for hook code, `false` for tests.
- **pyupgrade**: `--py310-plus` — no `Optional[X]`, use `X | None`.
- **reorder-python-imports**: `--py310-plus --add-import 'from __future__ import annotations'` — enforced by CI.

## CI Matrix

| Job | Runner | Envs |
|-----|--------|------|
| `main-linux / tox (py3XX)` | ubuntu-latest | py310, py311, py312, py313 |
| `main-linux / collector` | ubuntu-latest | checks all tox jobs passed |
| `main-windows / tox (py310)` | windows-latest | py310 |
| `main-windows / collector` | windows-latest | checks all tox jobs passed |
| `pre-commit.ci` | pre-commit.ci | flake8, mypy, pyupgrade, etc. |

Workflow: `.github/workflows/main.yml` uses `asottile/workflows/.github/workflows/tox.yml@v1.8.1`.

## Pitfalls

1. **`re.MULTILINE` for line-level regex**: Without it, `^` and `$` only match string start/end, not line boundaries. Any hook checking line patterns MUST use `re.MULTILINE`.
2. **Chinese path in WSL**: `check_executables_have_shebangs` tests fail when repo is under a path with Chinese characters (`自研`). This is a pre-existing env issue, not hook code.
3. **`.pre-commit-config.yaml`** (repo's own CI hooks) is SEPARATE from `.pre-commit-hooks.yaml` (hooks this repo exports). Don't confuse them.
4. **Push auth**: `~/.git-credentials` stores tokens. `gho_` (OAuth) tokens cannot do git push. Need `ghp_` or `github_pat_` classic PAT with `repo` scope.

## Verification Checklist

```bash
# 1. Lint
flake8 pre_commit_hooks/<hook>.py tests/<hook>_test.py
mypy pre_commit_hooks/<hook>.py

# 2. Tests
python3 -m pytest tests/<hook>_test.py -v --tb=short

# 3. README sync
python3 -m pytest tests/readme_test.py -v

# 4. Full suite (expect pre-existing shebang failures on Chinese paths)
python3 -m pytest tests/ -v

# 5. E2E
echo "valid msg" > /tmp/msg && python3 pre_commit_hooks/<hook>.py /tmp/msg
echo "invalid" > /tmp/msg && python3 pre_commit_hooks/<hook>.py /tmp/msg  # expect exit 1

# 6. Commit and push
git add -A && git commit -s -m "feat: add <hook-id> hook"
git push origin main
```
