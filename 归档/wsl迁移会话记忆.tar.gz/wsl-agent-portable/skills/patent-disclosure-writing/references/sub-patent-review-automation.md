# 分案交底书自动化审查脚本

## 用途

当生成多份分案交底书后，用 Python 脚本批量执行结构化审查，替代逐份人工检查。

## 审查脚本模板

```python
import re

# 读取所有分案文件
files = {
    "P2": read_file("path/to/P2.md"),
    "P3": read_file("path/to/P3.md"),
    # ...
}

issues = []

# === CHECK 1: 结构完整性 ===
required_sections = [
    "1.1 技术领域", "1.2 现有技术方案情况", "1.3 在先专利情况",
    "2.1 应用场景", "2.2 解决的技术问题", "2.3 完整内容",
    "2.4 技术效果", "2.5 关键创新点总结",
    "3. 附录：专利家族建议", "修改记录", "模糊化对照表"
]
for name, content in files.items():
    for section in required_sections:
        if section not in content:
            issues.append(f"❌ {name}: 缺少 section '{section}'")

# === CHECK 2: 编号一致性 ===
# 母案用 S1-S9，分案必须用不同前缀
prefix_map = {"P2": "R", "P3": "F", "P4": "A"}
for name, content in files.items():
    prefix = prefix_map.get(name, "X")
    # 检查不应出现母案编号
    s_refs = re.findall(r'\bS[1-9]\b', content)
    if s_refs:
        issues.append(f"⚠️ {name}: 出现母案编号 {set(s_refs)}，应使用 {prefix} 前缀")
    # 检查正确编号存在
    correct = re.findall(rf'\b{prefix}[1-9]\b', content)
    if not correct:
        issues.append(f"❌ {name}: 未找到 {prefix} 编号步骤")

# === CHECK 3: 模糊化一致性 ===
fuzzy_checks = [
    ("飞书", "即时通讯平台"),
    ("BGE-m3", "预训练语言模型"),
    ("SQLite", "本地持久化存储"),
    ("cron", "定时调度机制"),
    ("λ=0.001", "衰减率可配置"),
]
for name, content in files.items():
    for raw, fuzzy in fuzzy_checks:
        lines = content.split('\n')
        for i, line in enumerate(lines):
            if raw in line:
                # 排除模糊对照表和修改记录（这些地方出现原始术语是合规的）
                context_window = lines[max(0,i-3):i+1]
                context_str = ' '.join(context_window)
                if any(kw in context_str for kw in ["原始表述", "原始值", "模糊化", "对照"]):
                    continue
                issues.append(f"⚠️ {name} L{i+1}: 出现原始术语 '{raw}'")

# === CHECK 4: CN专利号标注 ===
for name, content in files.items():
    cn_refs = re.findall(r'CN\d+[A-Z]', content)
    for cn in cn_refs:
        idx = content.find(cn)
        context = content[max(0,idx-20):idx+50]
        if "待验证" not in context:
            issues.append(f"❌ {name}: CN专利号 {cn} 未标注'待验证'")

# === CHECK 5: 专利家族完整性 ===
for name, content in files.items():
    siblings = {"P2": ["P1","P3"], "P3": ["P1","P2"], "P4": ["P1","P2","P3"]}
    for s in siblings.get(name, []):
        if f"MEDICI-{s}" not in content:
            issues.append(f"❌ {name}: 专利家族缺少 MEDICI-{s}")

# === 输出 ===
p0 = [i for i in issues if i.startswith("❌")]
warnings = [i for i in issues if i.startswith("⚠️")]
```

## 关键陷阱

1. **模糊对照表中的原始术语是合规的** — 脚本必须排除"原始表述/原始值/模糊化/对照"上下文窗口，否则全是误报
2. **跨专利编号引用** — 分案正文引用母案步骤编号（如"与 P1 的 S8/S9 互补"）是 P1 问题，应改为描述性引用
3. **对比表行首的 `|`** — patch 操作时注意行首双竖线 `||` 是常见格式错误
