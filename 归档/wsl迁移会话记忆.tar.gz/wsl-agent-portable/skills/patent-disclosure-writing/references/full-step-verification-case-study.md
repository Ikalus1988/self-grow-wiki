# 全步骤代码验证案例：MEDICI-P1 V2→V3 审计 — 2026-05-06

> 此案例演示对交底书方法流程（S1-S9）逐条对照代码文件的系统性验证。
> 与 claims-reality-check-case-study.md 的区别：前者审计单个 claim 元素，
> 此处审计**完整的步骤流程**，发现整个步骤（S5）无代码实现。

---

## 审计方法

对交底书中的每个步骤（S1-Sn），确定其对应的代码文件，然后逐项验证：

```
交底书步骤 → 确定代码文件 → 读取代码 → 逐字段/逐机制比对 → 标注状态
```

### 审计文件清单

| 步骤 | 交底书描述 | 对应代码文件 |
|------|-----------|-------------|
| S1 | Agent 写入知识片段 | `misakanet/scripts/queue_lesson.py` |
| S2 | Hub 同步并构建索引 | `orchestrator/skill_indexer.py` + `hub_poller.py` |
| S3 | 领域订阅声明 | `orchestrator/subscription.py` |
| S4 | 订阅匹配与分发 | `subscription.py` + `hub_poller.py` (feishu) |
| S5 | 任务驱动知识消费 | `search_knowledge.py`（候选） |
| S6 | 拉取与增量同步 | `misakanet/scripts/standby_poller.py` |
| S7 | Hub 离线自治 | `standby_poller.py` |
| S8 | 矛盾检测与仲裁 | `orchestrator/arbitration_queue.py` |
| S9 | 三维度置信度 | `orchestrator/confidence.py` |

---

## 审计结果

### S1-S4, S6-S7, S9: 完全匹配 ✅

具体验证项（以 S1 为例）：

| 交底书描述 | 代码验证 | 状态 |
|-----------|---------|------|
| JSON frontmatter (title/domain/source/status/tags/created/updated) | queue_lesson.py L106-114: `frontmatter = {"title": ..., "domain": ..., "source": ..., "status": ..., "tags": ..., "created": ..., "updated": ...}` | ✅ |
| git add/commit/push | L136-142: `subprocess.run(["git", "add"...])`, `["git", "commit"...]`, `["git", "push"...]` | ✅ |
| push 失败 → .feedback/pending/ | L152-166: `pending_dir = REPO_ROOT / ".feedback" / "pending"` | ✅ |

S9 逐数值验证（最关键）：

| 公式要素 | 交底书 | confidence.py | 状态 |
|---------|--------|--------------|------|
| 默认权威度 | 0.5 | `DEFAULT_AUTHORITY = 0.5` | ✅ |
| 仲裁胜出 | +0.1 | `WIN_AUTHORITY_BOOST = 0.1` | ✅ |
| 仲裁失败 | -0.05 | `LOSE_AUTHORITY_PENALTY = 0.05` | ✅ |
| 权威度范围 | [0.1, 1.0] | `AUTHORITY_RANGE = (0.1, 1.0)` | ✅ |
| 时间衰减 | e^(-0.001×t) | `math.exp(-self.LAMBDA * age_days)`, LAMBDA=0.001 | ✅ |
| 交叉验证 1节点 | 0.8 | `if source_count == 1: return 0.8` | ✅ |
| 交叉验证 2节点 | 0.95 | `elif source_count == 2: return 0.95` | ✅ |
| 交叉验证 3+节点 | 1.0 | `else: return 1.0` | ✅ |

### S2: 部分匹配 ⚠️

| 交底书描述 | 代码实际 | 状态 |
|-----------|---------|------|
| "Hub 定期执行 git pull 拉取知识片段" | hub_poller.py 从 GitHub Issues 消费反馈，不 git pull lessons | ⚠️ |
| 索引表字段: lesson_id/title/tags/domain/source/created | skill_index.json 结构: {skills: {}, tools: {}, users: {}, version, sync_version} | ⚠️ |

### S5: 完全无实现 ❌ （核心发现）

**交底书描述**：
> Agent 在任务开始前自动检索本地知识库中与当前任务相关的经验。
> 领域匹配 + 关键词匹配 + 语义匹配(BGE-m3, 阈值0.75)
> Top-K(默认5)注入任务上下文
> 形成"写入→同步→检索→消费→再写入"闭环

**实际代码 (search_knowledge.py)**：

```python
# 整个检索逻辑就是一个 grep：
if query.lower() not in content.lower():
    continue
score = content.lower().count(query.lower())
```

| 交底书 S5 声称 | 代码实际 | 状态 |
|---------------|---------|------|
| 领域过滤 (domain matching) | ❌ 无 | 不存在 |
| 关键词提取 | ❌ 无 | 用户手动输入查询词 |
| BGE-m3 语义匹配 (阈值0.75) | ❌ 无 | 纯 grep 文本匹配 |
| Top-K 注入任务上下文 | ❌ 无 | 打印到 stdout，无注入机制 |
| 闭环 (写入→消费→再写入) | ❌ 无 | 手动触发，非自动 |

**AGENTS.md 的实际使用模式**：
```
遇到问题 → 手动执行 python3 search_knowledge.py "关键词" → 读结果
```
这是"遇到问题时手动检索"，不是"任务开始前自动消费"。

### S8: 部分匹配 ⚠️

| 交底书描述 | 代码实际 | 状态 |
|-----------|---------|------|
| SQLite 仲裁队列 | arbitration_queue.py ✅ | ✅ |
| 飞书交互卡片 | format_for_feishu() ✅ | ✅ |
| BGE-m3 ≥0.92 自动检测冲突→入队 | skill_indexer.py 有 dedup，但与 arbitration_queue 无自动触发链路 | ⚠️ |

---

## 发现的 5 种常见 Gap 模式

### Gap 1: 整个步骤无实现（本次 S5）

交底书新增了一个完整步骤（S5），描述了详细的三维检索+Top-K注入机制，
但代码中完全没有对应实现。最近似的代码（search_knowledge.py）只是 grep。

**检测方法**：对声称的每个步骤，搜索代码库中的关键函数名/类名/数据结构。
如果搜不到任何匹配，该步骤就是零实现。

### Gap 2: 模块存在但链路断裂（本次 S8）

两个模块各自存在且功能正确，但缺少把它们串联起来的触发代码。
例：skill_indexer.py 检测到重复 → ??? → arbitration_queue.py 入队。
中间的"???"不存在。

**检测方法**：不仅验证每个模块独立工作，还要验证模块间的调用关系。
搜索 A 模块中对 B 模块的 import/调用。

### Gap 3: Schema 不一致（本次 S2）

交底书描述的字段名/结构与代码中的实际数据结构不匹配。
例：交底书说索引表有 lesson_id/title/tags/domain/source/created，
代码中 skill_index.json 的结构是 {skills: {id: {name, description, domain, ...}}, ...}。

**检测方法**：读取数据结构定义代码（JSON dump、dataclass、CREATE TABLE），
逐字段比对交底书描述。

### Gap 4: 机制描述错误（push vs pull）

交底书描述"Hub 主动推送"，代码实际是"Agent 定时 pull"。
例：standby_poller.py 用 `git pull --ff-only`，hub_poller.py 从 Issues 消费。

**检测方法**：对每个"推送/拉取/同步"描述，追踪代码中的实际数据流方向。

### Gap 5: "设计中" vs "已实现"未标注

交底书没有区分哪些功能是已实现的、哪些是设计目标。
审查员看到完整的方法流程会认为全部已实现。

**检测方法**：对每个步骤标注状态（✅已实现 / ⚠️部分 / ❌未实现），
交底书中对未实现部分加"（设计目标）"标注。

---

## 关键启示

1. **新增步骤是最危险的** — 修改交底书时新增的步骤往往是为了"补齐"而写的，
   容易没有代码支撑。新增步骤必须做完整的代码搜索验证。

2. **"最接近的代码" ≠ "实现了"** — search_knowledge.py 存在且能搜索知识，
   但它只是 grep，不等于 S5 声称的三维检索+语义匹配+Top-K注入。

3. **AGENTS.md 描述的使用模式 ≠ 交底书描述的自动化** —
   AGENTS.md 说"遇到问题时手动搜索"，交底书说"任务开始前自动消费"。
   这是手动 vs 自动的根本差异。

4. **验证要到字段级** — 不是"有索引功能"就通过，要验证索引的每个字段名、
   每个参数值、每条数据流路径是否与交底书一致。

5. **创新点闭环描述要验证每个环节** — "写入→同步→检索→消费→再写入"
   需要 5 个环节都有代码。如果"检索→消费"断了，整个闭环就不成立。

---

## S5 Gap 的修复（方案B：补齐代码）

用户选择方案B（补齐代码再提交），在 search_knowledge.py 中实现了 `task_driven_search()`：

- **领域匹配**：解析 frontmatter 的 domain 字段，精确过滤
- **关键词匹配**：正则分词 + 停用词过滤 + tags/title/content 匹配
- **语义匹配**：BGE-m3 embedding 余弦相似度（可选，模型不可用时降级为纯关键词）
- **综合评分**：语义可用时 0.6×语义 + 0.4×关键词；语义不可用时纯关键词
- **Top-K 输出**：按分数降序取前 K 条（默认 5）
- **CLI 接口**：`--task "描述" --domain X --top-k N --json`

**关键设计决策**：语义匹配为可选（graceful degradation），因为 BGE-m3 模型在部分节点上不可用。
交底书 S5 中已明确标注"当语义模型不可用时，系统自动降级为关键词匹配模式"。
这避免了"声称有语义匹配但代码跑不了"的 aspirational claim 问题。

**验证结果**：
```
$ python3 search_knowledge.py --task "FANUC检索混淆修复" --domain rag-retrieval --no-semantic --top-k 3
🎯 任务驱动检索 (Top-3)
   1. [rag-retrieval] FANUC R-2000iC 检索混淆修复 — 关键词强制召回
      分数: 1.0000 | 匹配: keyword | 来源: hermes_wsl
```
