# Multi-Agent Patent Review Pattern

> When the user runs a multi-round review with multiple agents, use this evaluation framework.

## Typical Flow

1. **Agent A (me)**: Initial draft + first review (Phase 1.5 Claims Reality Check)
2. **Agent B (Node 2/3, DeepSeek)**: Second review with fresh eyes
3. **Agent A (me)**: Evaluate Agent B's review — independent judgment, not blind agreement

## Evaluating Another Agent's Review

### Classify each critique into 4 buckets:

| Bucket | Action | Example |
|--------|--------|---------|
| ✅ Valid | Accept and fix | Letta URL 404, S4/S6 push-offline contradiction |
| ⚠️ Partially valid | Accept the observation, fix the severity rating | "权威度与置信度不一致" — actually it's a clarity issue, not P0 |
| ❌ Wrong advice | Reject with reasoning | "删掉待验证注释" — removing honesty markers makes it worse |
| 📊 Strategic disagreement | Accept the analysis, reject the conclusion | "缩窄保护范围" — narrower name = weaker commercial value |

### Common WRONG advice to watch for:

1. **"Remove uncertainty markers"** — "待验证" is honest defense, not weakness. Removing it risks false citation.
2. **"Narrow the patent scope"** — focusing only on one innovation loop may make prosecution easier but destroys commercial breadth. The right answer is usually broader independent claims + narrower dependent claims.
3. **"分案技术依赖 = 权利要求不独立"** — this is incorrect. Chinese patent practice allows 分案 to have technical dependencies while maintaining independent claims.
4. **"每个创新点都不新颖"** — true individually, but the complete closed-loop chain may be novel. Don't accept defeat on innovation without analyzing the combination.

### What to accept even when it hurts:

- Code-claim mismatches (these are P0, no matter how small)
- Terminology inaccuracies (git "去重" → "增量存储")
- Missing boundaries (Hub online/offline behavior)
- Prior art descriptions that are oversimplified (Cognee "自动合并")

## Key Insight: Innovation Assessment

Individual components of a system rarely have novelty. Patent strength comes from:
1. The **specific combination** of components
2. The **closed-loop feedback** mechanism
3. The **application context** (e.g., industrial AI agents, not generic distributed systems)

When evaluating innovation claims, ask: "Is this combination of A+B+C+D+E in this specific order documented anywhere?" If not, the loop is the invention.
