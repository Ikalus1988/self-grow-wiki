# Phase 0 Output Gate — 知识检索硬性门禁模板

> **来源：** patent-disclosure-writing skill 的曳光弹（2026-05-06），已验证有效。
> **本模板的用途：** 其他 skill 可直接复制此模式的 Phase 0 到自己的 SKILL.md，替换关键词和目录路径即可。
> **根因：** 此前 agent 看到"搜 lessons/"等建议可以跳过无后果。
> **修复：** 改为必须输出检索报告（Output gate），未输出 = 不准进入后续步骤。

## 通用模式

### Phase 0: 知识检索（硬性门禁 — 必须输出检索报告才能开始正式工作）

> 此前的教训：做相似任务时，reference/ 下有现成分析但 agent 没打开。
> 根因：检索是"建议"不是"强制输出门禁"。
>
> **以下每一步都有 Output gate — 必须输出显式结果才能继续。**

#### Step 0.1: 列出相关知识目录

```bash
# 根据 skill 的领域，列出相关的知识目录
ls -la ~/Agent-Medici/reference/   # 完整方案
ls ~/Agent-Medici/lessons/          # 踩坑记录
```

**Output gate：** 列出全部文件名。不要只看文件名就跳过——至少读每个文件的前 2 行。

#### Step 0.2: 搜索 lessons + reference

用 `python3 ~/Agent-Medici/search_knowledge.py "<域关键词>" --lessons` 和 `--ref` 检索。

搜索词应包括：
- 当前任务的核心技术域（如 FANUC、RAG、debug、architecture）
- 当前工具/环境的关键词（如 Hermes、cc-haha、git、WSL）
- 常见的失败模式关键词（如 connection refused、timeout、auth）

**Output gate：** 输出命中数量 + top-3 文件的实际摘要。如果 search_knowledge.py 返回空，输出 `"search_knowledge.py 空结果"` ± 补充手动 grep/查找。

#### Step 0.3: 输出检索结论

```
📋 检索结论
  - 可复用的文件: [文件名]
  - 与当前任务的具体相关性: [这段内容能避免什么坑/复用什么结论]
  - 核心风险（如果不做这次检索会犯什么错）: [一句话]
```

**Output gate：** 必须输出此结论块。不输出 = 不允许进入任务执行阶段。

## 关键词生成策略

| 任务类型 | 推荐搜索词 |
|---------|-----------|
| 调试/排错 | 错误信息关键词、组件名（Hermes/Gateway/ChromaDB）、OS 层面（WSL/Windows） |
| 代码评审 | 项目名、语言/框架、涉及的工具名 |
| 方案规划 | 项目名、架构关键词（distributed/agent/sync）、核心组件 |
| 文档撰写 | 产品名、术语、已有文档类型 |
