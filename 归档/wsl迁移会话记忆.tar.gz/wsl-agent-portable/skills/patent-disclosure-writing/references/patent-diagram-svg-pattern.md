# 专利交底书附图 SVG 生成模式

专利附图要求黑白、简洁、等宽字体，与技术架构图（暗色主题、彩色渐变）完全不同。

## 视觉规范

| 属性 | 规范 |
|------|------|
| 背景 | 白色 (#fff) |
| 边框 | 纯黑 (#000)，无渐变 |
| 字体 | Courier New / Consolas 等宽字体 |
| 圆角 | 无圆角 (rx="0")，直角矩形 |
| 颜色 | 仅黑色，无彩色 |
| 箭头 | 实线=顺序流程，虚线=反馈/循环 |
| 粗框 | stroke-width: 2.4（核心创新步骤），普通 stroke-width: 1.8 |
| 外部实体 | 虚线边框 stroke-dasharray="4,2" |

## 两种图的结构

### 图1：方法流程图

```
S1 → S2 → S3 → ◇S4(判断) → S5 → S6 → S7 → S8 → S9
                                    ↑               |
                                    └───飞轮反馈────┘
```

- 步骤用直角矩形，内部两行（粗体标题 + 灰色子说明）
- S4 去重检查用菱形（polygon），分叉出"是/否"两条路径
- 飞轮反馈用虚线箭头，标注"飞轮反馈"文字（旋转90°沿竖线）
- 核心创新步骤（S6强制检索、S9置信度）用粗框

### 图2：系统架构图

```
┌─────────────────────────────────────┐
│  共享知识库（粗框）                    │
│  [CDN] ←── [Hub]                    │
├─────────────────────────────────────┤
│  智能体节点（外框）                    │
│  [M1] 节点接入模块                    │
│  [M2] 事件钩子模块                    │
│  [M3] 错误分类模块                    │
│  [M4] 知识生成模块                    │
│  [M5] 强制检索模块（粗框）             │
│  [M6] 仲裁模块（粗框）                │
│  [M7] 置信度计算模块                  │
│  ┌─ 执行环境层（虚线框）─┐            │
│  └──────────────────────┘            │
├─────────────────────────────────────┤
│  [IM平台]  [其他节点]  [用户]         │
│  （虚线框=外部实体）                   │
│  [正向飞轮]（虚线框）                  │
└─────────────────────────────────────┘
```

- 外部实体用虚线边框
- 普通模块用实线边框
- 核心创新模块用粗实线边框
- 数据流箭头旁标注简短文字（指令/卡片、知识同步、仲裁结果）
- 底部放图例框（普通模块 / 核心创新模块 / 外部实体）

## SVG 代码模板

```svg
<style>
  text { font-family: 'Courier New', 'Consolas', monospace; }
  .box { fill: #fff; stroke: #000; stroke-width: 1.8; }
  .box-heavy { fill: #fff; stroke: #000; stroke-width: 2.4; }
  .diamond { fill: #fff; stroke: #000; stroke-width: 1.8; }
  .arrow { stroke: #000; stroke-width: 1.4; fill: none; marker-end: url(#arr); }
  .arrow-dash { stroke: #000; stroke-width: 1.2; fill: none; stroke-dasharray: 6,4; marker-end: url(#arr); }
  .label { font-size: 13px; font-weight: bold; fill: #000; }
  .sub { font-size: 10.5px; fill: #333; }
  .tag { font-size: 10px; fill: #666; }
</style>
<defs>
  <marker id="arr" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
    <polygon points="0 0, 8 3, 0 6" fill="#000"/>
  </marker>
</defs>
```

## 与 architecture-diagram skill 的区别

| 维度 | architecture-diagram | 专利附图 |
|------|---------------------|---------|
| 用途 | 技术架构演示 | 专利交底书附图 |
| 风格 | 暗色渐变、彩色分类 | 纯黑白、无彩色 |
| 字体 | JetBrains Mono | Courier New / Consolas |
| 背景 | #020617 + 网格 | 纯白 #fff |
| 圆角 | rx="6" | rx="0" 直角 |
| 外部实体 | 半透明+深色 | 虚线边框 |
| 适用场景 | 演示/汇报 | 专利申请/代理所 |

## 实战参考

MEDICI-PX V5 (2026-05-07): 图1方法流程图(9步骤+菱形判断+飞轮虚线) + 图2系统架构图(7模块+3外部实体+图例)，总代码约 14KB HTML。
