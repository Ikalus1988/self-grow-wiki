---
name: patent-disclosure-writing
title: Chinese Patent Disclosure Document Generation
description: "Generate, review, and batch-fix Chinese patent 交底书 from software projects: code analysis → claim mapping → disclosure docs + patent matrix → review against optimization reports → apply structural fixes (claims gaps, numbering collisions, regex bugs, O(1) qualifiers, missing data structures/formulas, hardcoded values)"
version: 1.4.0
tags: [patent, disclosure, 交底书, 知识产权, claims, 权利要求]
category: productivity
related_skills: [codebase-inspection, research-paper-writing, writing-plans]
metadata:
  hermes:
    tags: [patent, disclosure, 交底书, 知识产权, claims, 权利要求]
    category: productivity
    related_skills: [codebase-inspection, research-paper-writing, writing-plans]
references:
  - references/claims-reality-check-case-study.md — 两轮实战案例（MEDICI-01/02/03 + MEDICI-P1 v1），含完整 Claims 验证表和公式比对
  - references/medici-p1-review-case-study.md — MEDICI-P1 完整审查案例（两轮：12问题+6自查问题），含代码验证文件清单和 Claims 验证表最终版
  - references/full-step-verification-case-study.md — 全步骤代码验证案例（MEDICI-P1 V2→V3），S5 整步骤零实现的发现过程和 5 种 Gap 模式 + S5 方案B修复（task_driven_search 实现）
  - references/disclosure-evaluation-rubric.md — 专利交底书评估打分框架（6维度100分制），含实战案例和改进优先级排序
  - references/patent-diagram-svg-pattern.md — 专利附图 B&W SVG 生成模式（流程图+架构图），含与 architecture-diagram 的风格对比
  - references/sub-patent-generation-workflow.md — 分案交底书生成工作流：从母案提取定义→读代码→生成分案→模糊化一致性→验证
  - references/patent-fuzzy-treatment-pattern.md — 代理所提交前的模糊化处理模式：工具名/参数值/字段名/实现细节的标准化替换规则
  - references/sub-patent-cross-review-case-study.md — 分案交底书交叉评审案例（P2/P3/P4），含自动自检脚本、创新性评估矩阵、7项修复记录
  - references/patent-innovation-assessment.md — 专利创新性评估框架：三维度打分、放弃决策标准、claim 缩减策略
  - references/sub-patent-review-automation.md — 分案交底书自动化审查脚本（8项检查）
---

# Chinese Patent Disclosure Document (技术交底书) Generation

Generate structured Chinese patent disclosure documents from software project codebases. Used when the user asks to create patents, 交底书, or IP documentation from a technical project.

## When to Use

- User asks to generate patent disclosure documents (交底书) from code
- User needs to map code implementation to patent claims (权利要求)
- User wants to create or update a patent matrix (专利矩阵)
- User provides optimization suggestions for existing patents and wants revised docs
- User asks to evaluate a project's patentability

## Workflow

### Phase 0: 知识检索（硬性门禁 — 必须输出检索报告才能进入 Phase 1）

> **曳光弹（2026-05-06）：** 此前的 Phase 0 写着"不可跳过"但仍被跳过。根因不是措辞不够强硬，
> 而是 agent 在 context 中看到"搜 lessons/""搜 reference/"时，可以选择跳过而不产生任何可见后果。
>
> **修复：Phase 0 不再是一个"建议列表"，而是一个必须执行的输出清单。**
> 以下每一步都有 output gate：未输出 = 状态不完整 = 不准进入 Phase 1。
>
> 这是虫群飞轮三层注入框架的 Layer 1 曳光弹。先验证此模式在专利 skill 有效，
> 再推广到其他 skill。

**执行以下检索并逐项输出结果。** 完成全部输出后，方可进入 Phase 1。

#### Step 0.1: 列出 reference/ 目录

```bash
ls -la ~/Agent-Medici/reference/
```

**Output gate：** 列出全部 reference 文件名 + 文件的贡献节点和用途（从文件名和路径推断）。不要只看文件名就跳过，至少读第 1 行。

#### Step 0.2: 读取匹配的 reference 文件

对以下关键词，用 `python3 ~/Agent-Medici/search_knowledge.py "<关键词>" --ref` 检索：
- `专利`
- `patent`
- `交底`
- 当前任务的领域关键词（如 `FANUC`、`RAG`、`agent`）

对命中结果中排名 top-3 的 reference 文件，**逐篇读取前 50 行**并输出：

```
📄 文件: reference/xxx.md
  - 贡献节点: [文件名推断]
  - 摘要: [首段内容概述]
  - 与当前任务的相关性: [具体说明这段内容能帮我避免什么坑/复用什么结论]
```

**Output gate：** 必须输出至少 1 篇 reference 文件的实际摘要。如果 search_knowledge.py 返回空，输出 `"search_knowledge.py 空结果"` 并补充手动 `ls reference/` 的检查。

**注意：reference 文件不会自动出现在 CLAUDE.md 的 lessons 区块里。CLAUDE.md 只包含 lessons/ 的标题摘要。** 必须手动读取 reference/。

#### Step 0.3: 搜索 lessons/

```bash
python3 ~/Agent-Medici/search_knowledge.py "<关键词>"
grep -r "专利\|patent\|交底\|权利要求" ~/Agent-Medici/lessons/ --include="*.md" -l
```

**Output gate：** 输出匹配的 lessons 数量 + top-3 标题。如果 lessons 有直接相关（如 node2-配置完成-git-credentials-设置），输出该 lesson 的完整内容摘要。

#### Step 0.4: 输出检索结论

```
📋 检索结论
  - 可复用的 reference 文件: [文件名列表]
  - 可复用的 lessons: [标题列表]
  - 是否已有前人的专利分析结论需要纳入: [是/否，具体引用]
  - 核心风险（原本可能踩的坑）: [一句话说明如果没做这次检索会犯什么错]
```

**Output gate：** 必须输出此结论块。不输出 = 不允许进入 Phase 1。

### Phase 1: Project Analysis

1. **Read key source files** — focus on core modules, not boilerplate
2. **Extract implementation features** — for each significant function/class:
   - What problem does it solve?
   - What is novel vs. prior art?
   - What are the concrete steps (算法步骤)?
3. **Identify patentable innovations** — look for:
   - Novel algorithms or data structures
   - Unique system architectures
   - Non-obvious combinations of known techniques
   - Specific technical effects (性能提升, 准确率, 速度)

### Phase 1.5: Claims Reality Check (claims 与代码的逐条验证)

**这是最容易跳过也最致命的步骤。** 不验证就写 claim 会导致交底书中的技术特征在实际代码中不存在，审查员一旦发现=驳回。

对每个候选的独立权利要求，逐条验证其核心技术特征在代码库中是否存在：

1. **对每个 claim 元素**，在代码库中搜索对应的函数名、数据结构、算法
2. **使用 delegate_task 进行多文件并行审计**，每个候选方案一个 agent：
   - 搜索关键函数/类名是否存在
   - 读取对应代码确认逻辑与 claim 描述一致
   - 检查该代码是否在生产环境中运行（vs. 死代码/待机状态）
3. **输出 Claims 验证表**：

```markdown
| Claim 元素 | 审计结果 | 证据 | 风险 |
|-----------|---------|------|------|
| PostToolUseFailure Hook 捕获失败事件 | 🟡 半实现 | 上游钩子基础设施存在，但特定钩子从未部署到 cc-haha | 高 — 核心特征未部署 |
| 模板状态机（空→待修复→已修复） | ✅ 已实现 | queue_hook_stats.py _is_template_lesson / _fill_template / cmd_promote | 低 |
| BGE-m3 语义匹配阈值 0.75 | 🟡 待机代码 | orchestrator/dedup_engine.py 中存在但标记为 DEAD CODE | 中 |
| 本地离线队列 + 网络恢复自动同步 | ⚠️ 部分 | queue_lesson.py 有本地存储，但自动重试未实现 | 中 |
```

4. **状态定义**：

| 状态 | 含义 | 处理方式 |
|------|------|----------|
| ✅ 已实现 | 代码存在且逻辑与 claim 一致 | 可写入专利 |
| ⚠️ 部分 | 代码存在但缺少部分功能 | 修改 claim 描述以匹配实际实现，标注"预期扩展" |
| 🟡 待机/死代码 | 代码存在但标记为 dead code 或 standby | 需在背景技术中注明"系统已完成实验室验证，待生产部署" |
| ❌ 不存在 | 代码中找不到对应实现 | 删除该 claim 或改为"设计目标"并在实施方式中标注 |
| 🔬 设计中 | 有设计文档但未编码 | 不能作为独立 claim，仅可作为背景技术中的前景展望 |

5. **对于每个 ❌ / 🟡 状态**，评估修复成本 vs 专利价值：
   - 如果修复成本低（如加一行调用）→ 建议先修代码再申请
   - 如果修复成本高 → 删 claim 或转为从属 claim

### Phase 2: Industry Research

4. **Search for prior art** — use web search for:
   - Existing patents in the same domain (CN patents on Google Patents)
   - Competing products and their technical approaches
   - Academic papers describing similar methods
5. **Identify differentiation** — what makes this invention different from:
   - Existing commercial products
   - Published academic work
   - Other patents (especially CN patents)

### Phase 3: Document Generation

6. **Create patent disclosure document** with these required sections:

```markdown
# 技术交底书

## 发明名称
[Concise technical name, 25-50 chars]

## 一、技术领域
[1-2 paragraphs: which technical field, what kind of problem]

## 二、背景技术
[3-5 paragraphs: existing solutions, their limitations, prior art references (CN patents if possible)]

## 三、发明内容
### 3.1 发明目的
[What problem does this solve?]
### 3.2 技术方案
[Numbered steps (S1, S2, S3...), each with detailed technical description]
### 3.3 技术效果
[Quantified improvements: accuracy %, speed ×, cost reduction]

## 四、具体实施方式
[System architecture, data structures, code examples (pseudocode), flowcharts described in text]

## 五、附图说明
[List of figures: 图1, 图2, 图3... with brief descriptions]

## 六、权利要求书
[Independent claims (权利要求1, 5...) + dependent claims (权利要求2-4, 6-8...)]
```

7. **Create/update patent matrix** with:
   - Patent name, type, relevance, maturity, status
   - Dependency diagram (which patents depend on which)
   - Code-to-claims mapping table (each claim element → specific function/file)
   - Prior art comparison table
   - Priority ranking (P0/P1/P2)

### Phase 3.5: Sub-Patent Disclosure Generation (分案交底书生成)

When the parent disclosure (母案, e.g. MEDICI-P1) defines a patent family with sub-patents (分案), generate each sub-patent disclosure as a standalone document. See `references/sub-patent-generation-workflow.md` for the complete workflow and template.

**Key rules:**
1. **Read parent's 专利家族建议 section** to extract each sub-patent's case number, title, and relationship to parent
2. **Read source code files** relevant to each sub-patent's specific technical content
3. **Mirror parent structure** exactly: same section numbering (1.背景技术 → 2.本发明 → 3.附录 → 修改记录), same table formats
4. **Each sub-patent gets its own:**
   - 内部案号 header (e.g. MEDICI-P2)
   - 专利家族建议 section referencing all siblings
   - 修改记录 section (V1_模糊)
   - 模糊化对照表 appendix
5. **模糊化 rules must be consistent** across parent and all children — use the same generic terms for the same tools/parameters
6. **Sub-patent naming convention**: `专利交底书_P{N}_{简称}_V1_模糊.md`
7. **Relationship types**: "技术依赖 P1（基于 XX 机制），权利要求独立" or "技术独立，权利要求独立"

### Phase 4: Review Feedback Integration (复审修改)

When given a review report (复审报告) with optimization suggestions:

8. **Categorize issues by type** — read the full review report first, then classify each issue:
   - P0 硬伤: claim logic errors, missing steps, no prior art description → **必须修复，否则审查员直接驳回**
   - P1 结构: claim scope issues, cross-patent boundary unclear → **建议修复，影响保护范围**
   - P2 细节: terminology inconsistency, formatting, parameter justification → **可选修复，提升专业度**

9. **Apply common fix patterns** across all affected documents:

   **编号统一 (Numbering Consistency)**:
   - 全文统一使用 S1/S2/S3... 编号，不要混用"步骤1""第一步"等
   - 流程图、14步列表、正文标题中的编号必须一致
   - 正文描述和权利要求书的编号必须一一对应

   **量化指标措辞 (Quantitative Metrics)**:
   - 无实验数据支撑的指标 → 加"设计目标"或"预期达到"标注
   - 格式：`**指标名**（设计目标≥95%）：说明` 或 `（预期达到85%以上）`
   - 有实验数据的 → 补充简要测试描述（基准、样本量、方法）

   **权利要求展开 (Claim Expansion)**:
   - 概括性S步骤 → 拆分为Sxa/Sxb/Sxc子步骤，补充具体数据输入/输出
   - 硬编码参数（如"加0.12分"）→ 改为"预设加权值"或"动态计算"
   - "预设数量"等模糊表述 → 与正文示例值对齐（如"3个"）

   **参数选择依据 (Parameter Justification)**:
   - 工程经验值（如800字符分块）→ 补充与文档特征的关系
   - 标注"可配置参数"，说明选择依据（如"基于FANUC手册平均段落长度600-800字"）

   **技术实现补充 (Implementation Detail)**:
   - 概括性技术名词（如"规则引擎"）→ 补充数据结构定义
   - 引用其他专利的技术 → 加"详见本系列专利N：名称"，保持独立性说明
   - O(1)等复杂度声明 → 改为"哈希表常数级查找（摊销O(1)）"

   **专利间关系 (Cross-Reference Matrix)**:
   - 在专利矩阵中增加引用关系矩阵表
   - 列出：引用方 | 被引用方 | 引用内容 | 引用类型（技术依赖/数据依赖/技术引用）
   - 注明"各专利均为独立权利要求，不互相引用专利号"

10. **验证修改完整性**:
    - 逐份检查：每个review comment是否已处理
    - 交叉检查：引用关系是否对齐
    - 输出修改汇总（文件名 + 修改项数 + 具体改动列表）

### Phase 4.5: Self-Review After Modification (修改后自查)

**修改后的自查和首次审查一样重要。** 实战证明：第一轮修复会引入新的 P0 问题（格式假设错误、架构描述夸大、跨引用不一致）。修复 ≠ 完成，必须再过一遍。

**执行流程**：
1. 重新读取修改后的完整文档（不要只看 diff）
2. 对每个技术步骤（S1-Sn）逐条比对源代码：
   - 数据格式（JSON/YAML/其他）→ 读代码确认实际序列化方式
   - 字段名（node_id vs source, created_at vs created）→ 逐字段比对
   - 通信机制（push/pull/poll）→ 确认是 Hub 主动推送还是 Agent 定时拉取
   - 公式参数 → 逐个数值比对，不只看公式名称
3. 检查修改后各步骤之间的措辞一致性（S4 说"推送"，创新点#3 不能说"拉取"）
4. 检查自引用矛盾（如"在先专利：否"但现有技术中列了自己项目的专利号）
5. 输出自查报告：新增问题列表 + 修复 + 验证状态

**实战案例**（MEDICI-P1, 2026-05-05）：
第一轮修复了 12 个问题，自查发现 6 个新问题：
- frontmatter YAML→JSON（代码是 JSON，不是 YAML）
- S4 "Hub 主动推送"→ 实际 A2A broadcast 是 dead code
- S5 "收到推送后拉取"→ 实际是 cron 定时 pull
- CN 专利号未验证（推测的，需 CNIPA 确认）
- CN119441488A 自引用矛盾
- 创新点措辞仍夸大

## Key Principles for Chinese Patent Writing

### Claim Structure (权利要求书)
- **Independent claim** (独立权利要求): Broadest protection scope
  - Format: "一种[方法/系统]，其特征在于，包括以下步骤：S1...S2...S3..."
- **Dependent claims** (从属权利要求): Narrower, reference independent claim
  - Format: "根据权利要求N所述的方法，其特征在于，所述步骤SX包括..."

### Technical Field (技术领域)
- Always start with "本发明涉及...技术领域"
- Be specific: not just "计算机技术" but "工业自动化知识库检索技术"

### Background Technology (背景技术)
- Must cite at least 2-3 existing solutions and their limitations
- Reference specific prior art (CN patent numbers if available)
- End with "现有技术中，...但其未涉及..." pattern

### Technical Solution (技术方案)
- Use numbered steps (步骤S1, S2, S3...)
- Each step must be concrete enough to implement
- Include specific parameters (thresholds, dimensions, data formats)
- Reference specific algorithms or data structures

### Technical Effects (技术效果)
- Quantify improvements: "准确率提升15~20%", "响应延迟<200ms"
- Compare with baseline (prior art or naive approach)

## Output Files

Save all files to the user-specified directory. Default naming:
- `交底书_NN_发明名称简写.md` — individual disclosure documents
- `专利矩阵_更新版.md` — updated patent matrix
- `项目评估报告.md` — project patentability assessment (optional)

## Lessons Learned

### 审核问题演进规律

两轮审核的典型路径：
```
第1轮：P0硬伤为主（逻辑错误、步骤残缺、缺背景技术）→ 修复后进入"细节打磨"阶段
第2轮：P2细节为主（编号统一、措辞优化、参数依据）→ 修复后可提交申请
```
**启示**：第一版交底书不必追求完美，先确保P0不犯（结构完整、背景有现有技术、权利要求步骤齐全），细节留给复审修改。

### 两轮审核共性问题清单（按出现频率排序）

| 排名 | 问题类型 | 出现次数 | 典型表现 | 修复模板 |
|------|---------|---------|---------|---------|
| 1 | 编号不统一 | 7/7份 | "步骤1"与"S1"混用 | 全文替换为S1-S7，流程图同步 |
| 2 | 量化指标无依据 | 5/7份 | "准确率≥95%"无实验数据 | 加"设计目标"或"预期达到"标注 |
| 3 | 概括性步骤未展开 | 3/7份 | "包括参数校验、安全检查" | 拆分为Sxa/Sxb/Sxc子步骤 |
| 4 | 参数选择依据缺失 | 3/7份 | "分块800字符"无解释 | 补充文档特征统计+标注"可配置" |
| 5 | 硬编码数值 | 2/7份 | "加0.12分" | 改为"预设加权值"或"动态计算" |
| 6 | 抽象概念未定义 | 2/7份 | "规则引擎"无数据结构 | 补充表结构/格式定义 |
| 7 | 复杂度声明不严谨 | 1/7份 | "O(1)时间复杂度" | 改为"哈希表常数级查找（摊销O(1)）" |
| 8 | 专利间关系不透明 | 1份矩阵 | 无引用关系表 | 新增引用矩阵（引用方/被引用方/内容/类型） |

### 交底书撰写质量自检清单（提交前必查）

在提交给审核人之前，逐份检查以下项目：

**结构完整性**：
- [ ] 六大章节齐全（技术领域、背景技术、发明内容、具体实施、附图说明、权利要求书）
- [ ] 背景技术有2-3个现有技术方案 + 至少1个CN专利引用
- [ ] 背景技术以"现有技术中，...但其未涉及..."收尾
- [ ] 技术方案有编号步骤（S1, S2, S3...），不少于5步
- [ ] 权利要求书有独立权利要求 + 2-4个从属权利要求

**编号一致性**：
- [ ] 正文步骤标题、流程图、14步列表、权利要求书中编号完全一致
- [ ] 全文统一使用S1/S2/S3...，不混用"步骤1""第一步"等
- [ ] 从属权利要求引用的步骤编号在独立权利要求中存在

**措辞规范性**：
- [ ] 无实验数据的量化指标 → 标注"设计目标"或"预期达到"
- [ ] 硬编码参数 → 改为"预设加权值"/"预设数量"或与正文对齐
- [ ] 复杂度声明 → 使用"摊销O(1)"/"哈希表常数级查找"等严谨表述
- [ ] 抽象技术名词（规则引擎、降级策略等）→ 在实施方式中定义数据结构

**专利间关系**：
- [ ] 引用其他专利的技术 → 正文标注"详见本系列专利N：名称"
- [ ] 专利矩阵有引用关系矩阵表（引用方/被引用方/引用内容/引用类型）
- [ ] 各专利独立权利要求不互相引用专利号

**技术深度**：
- [ ] 每个关键参数有选择依据（与文档特征/行业标准的关系）
- [ ] 每个技术效果有对比基准（vs 现有技术/naive方案）
- [ ] 核心算法有伪代码或数据结构示例

### 从代码到交底书的拆分策略

当一个项目有多个可专利化创新时，按**技术层次**拆分而非按**代码模块**拆分：

### 审核意见处理的工作流

```
收到审核报告
    ↓
1. 通读全文，标记每条意见的严重级别（P0/P1/P2）
    ↓
2. 按文件分组：列出每个交底书需要改的点
    ↓
3. 批量修复模式：
   a. 编号统一 → 全文替换（一次性处理所有文件）
   b. 措辞优化 → 逐文件patch
   c. 结构展开 → 逐文件patch（S5→S5a/S5b/S5c）
   d. 新增内容 → 补充小节（如数据结构定义）
    ↓
4. 交叉验证：
   a. 引用关系是否对齐（正文↔矩阵）
   b. 编号是否全文一致
   c. 从属权利要求引用的步骤是否存在
    ↓
5. 输出修改汇总（文件名 + 修改项数 + 具体改动列表）
```

## Phase 5: Batch Review & Fix (批量审查修复) — added from 2026-04-29 session

When reviewing multiple 交底书 against an optimization report, use this checklist. Each fix type includes exact before/after templates.

### P0: Claims Integrity (必须修复)

**P0a: Missing steps in claims** — 发明内容 has S1-S7 but 权利要求1 only has S1-S6.
```
Before: S6：...结束。
After:  S6：...；
        S7：[missing step description from 发明内容]。
```
Also add the missing module to the system claim (权利要求5).

**P0b: Step numbering collisions** — 发明内容 uses S1-S7, 4.3 flow uses S1-S14, both have "S7" with different meanings.
```
Before: S7. 构建 where 过滤条件
After:  步骤7. 构建 where 过滤条件  (use "步骤" not "S" for detail flows)
```
Or split 发明内容 S1 into S1+S2 so numbering aligns with claims.

**P0c: Regex/code bugs in examples** — `\u0001` (Unicode SOH) instead of `\1` (backreference).
```
Before: r'\u0001-\u0002'
After:  r'\1-\2'
```
Check all code blocks in 具体实施方式 for correctness.

**P0d: O(1) without "摊销" qualifier** — claims say "O(1)" but body says "摊销O(1)".
```
Before: 通过哈希表O(1)查找
After:  通过哈希表常数级查找（摊销O(1)）
```
Fix all occurrences in claims, figure captions, and system claims.

**P0e: Missing core innovation from claims** — e.g., "五因子动态调整置信度" in report but absent from v2 docs.
1. Extract the actual factors from code or architecture design
2. Add a new step (S5) in 技术方案 with formula and weight justification
3. Add corresponding claim with formula
4. Renumber subsequent steps (S5→S6, S6→S7, etc.) throughout the document

**P0f: Aspirational claims not backed by code (新增)** — claim describes a feature that doesn't exist in the codebase (e.g., "PostToolUseFailure hook deployed" when hook never calls hook_cc_haha.py, or "cycle detection in knowledge graph" when zero code exists).

For each such gap, pick one:
- **Option A (最好)**: Fix the code first — add the missing function call, parameter, or data path. Then write the claim.
- **Option B (可接受)**: Rewrite the claim to match actual implementation. Reduce scope, drop aspirational features.
- **Option C (风险标注)**: Keep the claim but add "（设计目标）" in every occurrence. Mark explicitly in 具体实施方式: "该系统已完成代码开发，在实验室环境通过验证，等待生产环境部署。"
- **Option D (不建议)**: Remove the claim. File separately when the feature is actually implemented.

### P1: Protection Scope (建议修复)

**P1a: Claims substantively duplicate independent claim** — claim 2/3 just restate S5a/S5b without new features.
```
Before: "参数范围校验包括：维护参数范围表..."
After:  "参数范围校验所使用的参数范围表包含以下字段：param_name(名称),
         min_value(最小值), max_value(最大值), unit(单位), severity(严重程度)..."
```
Add data structure fields, matching algorithms, priority levels — details NOT in the independent claim.

**P1b: Missing data structure definitions** — 安全规则 has example table but no formal schema.
Add a full data structure table (field name, type, description) matching the format of nearby sections (e.g., 4.2.1 format), plus matching engine logic.

**P1c: Missing technical method in claims** — "基于标题层级" but HOW to identify headings?
```
Add claim: "对于DOCX文档通过样式信息(Heading标签/字号加粗)识别标题层级；
          对于PDF文档通过结构标签和字体大小信息识别；
          对于纯文本文档通过正则匹配章节编号模式识别。"
```

**P1d: Missing math formulas** — fusion described in prose but no equation.
```
Add: Score_intermediate = max(S_semantic, S_entity, S_keyword, S_category)
     Score_final = min(Score_intermediate + W_tags + W_model, 1.0)
```
Place formulas in 技术方案 S6, reference them in claims.

**P1e: Hardcoded magic numbers** — "3" in max_per_file=3, "0.08/0.04/0.15" without "可配置" label.
```
Before: 同一文件最多保留3个chunk
After:  同一文件保留的chunk数不超过预设上限值（默认3个）
```
For thresholds: add "（预设加权值，可配置）" or "（设计目标）" annotation.

### Batch Fix Workflow

1. Read optimization report → extract per-patent issues
2. Read each 交底书 → verify each issue against actual content
3. Apply fixes in priority order: P0 first (claims integrity), then P1 (scope), then P2 (polish)
4. For renumbering fixes: update ALL occurrences — 技术方案, 系统架构图, 权利要求书
5. Verify cross-references: if claim 2 refs "S2规范化", ensure S2 IS normalization in both body and claims

## Pitfalls — 分案审查与创新性评估（2026-05-06 新增）

- **分案自检必须在提交前执行** — 生成分案后立即用 `references/sub-patent-review-automation.md` 中的脚本批量审查，不要等外部评审才发现问题。8 项检查：结构完整性、编号一致性、模糊化一致性、现有技术独立性、CN专利号标注、创新点数量、专利家族完整性、权利要求书。
- **分案正文不能引用母案步骤编号** — "与 P1 的 S8/S9 互补"是 P1 问题，审查员会追问跨专利编号关系。改为描述性引用："与母案的矛盾知识检测和多维度置信度计算技术方案互补"。
- **创新性不足的分案果断放弃** — 当分案所有 claim 都与现有成熟系统同原理（如 Stack Overflow reputation）且仅交互通道创新（IM 卡片替代 API）时，授权概率最低。如果核心技术已在母案步骤中覆盖，分案独立申请无意义。参考 `references/patent-innovation-assessment.md`。
- **无代码实现的 claim 降格为可选实施例** — 不要放弃整个分案，缩减保护范围：核心步骤保留为独立权利要求，无实现的步骤标注"（可选实施例）"。状态说明框改为"核心 XX 已有证据，YY 可选"。
- **对比表中无实现的维度必须诚实标注** — "动态能力更新 ✅"但实际没实现 = 审查员发现即驳回。改为"⚠️ 设计目标（可选实施例）"。
- **F7 类"定期推送"步骤要核实 cron 是否真的配了** — 代码有 `cmd_trigger()` + `cmd_flush()` ≠ 定期推送。flush 是手动触发还是 cron 触发？没有 cron = 降格为可选。

## Pitfalls

- **先查有无权利要求书** — 收到交底书第一件事：检查有没有独立权利要求+从属权利要求。没有权利要求书 = 不是专利，直接退回，不需要往下审。这是最低门槛。
- **Don't write claims for features that don't exist in code** — this is the #1 most dangerous mistake. Always run Phase 1.5 (Claims Reality Check) before writing. A patent examiner (or the user, who knows the codebase) will spot aspirational claims immediately.
- **Don't claim "实验验证" without data** — if the system hasn't been deployed, use "设计目标" or "预期达到"
- **Don't invent features not in the code** — patent claims must be supported by actual implementation
- **Don't write overly broad claims** — claims should be specific enough to be defensible
- **Include negative examples** — show what the invention does NOT do (误报消除, 过滤策略)
- **Quantify everything** — vague claims like "提高效率" are weak; "响应延迟从500ms降至200ms" is strong
- **Map every claim element to code** — reviewers will check; each S1/S2/S3 should trace to a function
- **Don't mix numbering styles** — pick S1-S7 and stick to it everywhere, including flowcharts and step lists
- **公式必须逐个数值比对，不能只看名称** — "三因子置信度"在交底书和代码中名称一致，但实际参数完全不同：交底书写"winner ×1.5"（乘法），代码是"+0.1"（加法）；交底书写"每确认×1.2，上限×2.0"，代码是"1节点=0.8, 2节点=0.95, 3节点+=1.0"。名称一致 ≠ 公式一致。审查员对比源代码即驳回。
- **"分布式"描述要严谨** — 如果所有节点通过 git 中心仓库（GitHub）同步，这不是真正的分布式架构，审查员会追问。git 异步消息总线 ≠ 分布式去中心化。
- **Don't leave hard-coded numbers in claims** — "加0.12分" will be challenged; use "预设加权值" or "动态计算"
- **Don't use O(1) loosely** — Python dict is amortized O(1), worst case O(n); use "哈希表常数级查找"
- **Don't skip parameter justification** — every "800字符" needs a "why" (document statistics, industry standard, configurable)
- **Don't forget cross-reference matrix** — reviewers will ask "how do patents relate"; have the table ready
- **When renumbering steps** — update all sections: 技术方案, 架构图, 权利要求书; check claim references still point to correct steps
- **When adding a step mid-document** — renumber everything after it, don't leave a gap or collision
- **When auditing codebase with delegate_task** — give each candidate its own agent with specific search/read tasks. Aggregate results into a single claims verification table.
- **Don't confuse "code exists in repo" with "code is running in production"** — a fully implemented feature might be dead code (marked DEAD CODE, standby, or never deployed). The patent's 具体实施方式 must reflect the actual state.
- **Always check project reference/ directory first** — search `search_knowledge.py "专利" --ref` and read `reference/patent-*.md` before starting. Skipping this repeats work and misses prior review conclusions.
- **reference 文件不会自动出现在 agent 上下文中** — CLAUDE.md 的 `<!-- MISAKANET_LESSONS_START -->` 区块只有 lessons 标题摘要，reference 目录的内容完全不在其中。必须 `ls reference/` + `read_file` 手动拉取。这是知识飞轮的最后一环断裂点：上传✅ 订阅✅ 复用❌。
- **Letta URL is docs.letta.com** — lettaproject.github.io is 404. Use https://docs.letta.com or https://github.com/letta-ai/letta
- **git has 增量存储, not 去重** — git stores deltas, not deduplicated content. "冲突检测" (merge conflict) requires human intervention, not automatic resolution. Use precise terminology: "增量存储" and "分支合并", not "去重".
- **Push vs offline must be bounded** — if claiming "Hub 主动推送", explicitly state what happens when Hub is offline. E.g., "Hub 在线时通过飞书推送；Hub 离线时推送暂停，各 Agent 继续定时拉取。" S4/S6 consistency is a common审查员 attack point.
- **Don't add new steps without verifying code exists — especially "闭环" steps** — When expanding a disclosure from V2 to V3 by adding new method steps (S5, S6...), each new step MUST go through Phase 1.5 verification. The most dangerous pattern: adding a "knowledge consumption" or "closed loop" step that sounds like a natural extension but has zero code backing. A grep-based search script (search_knowledge.py) is NOT "task-driven multi-dimensional retrieval with semantic matching + Top-K injection". Verify every claimed mechanism (domain matching, keyword extraction, BGE-m3 semantic search, threshold values, context injection) exists as actual code. See `references/full-step-verification-case-study.md` for the complete S5 audit.
- **跨专利引用不能用步骤编号** — 分案中引用母案的技术内容时，必须用描述性语言（如"母案的矛盾知识检测和多维度置信度计算技术方案"），不能直接写母案步骤编号（如"S8/S9"）。步骤编号是各专利文档内部编号，跨文档引用会让审查员追问编号关系，增加不必要的审查风险。正确示例：`与母案的矛盾知识检测和多维度置信度计算技术方案互补`；错误示例：`与 P1 的 S8/S9 技术方案互补`。（2026-05-06 P4 审查发现）
- **模糊一致性自动检查必须排除对照表和修改记录** — 用脚本检查分案中是否泄露原始术语时，必须排除 `模糊化对照表` 和 `修改记录` section（它们合法包含原始术语"原始表述"/"原始值"列）。误报模式：grep 命中对照表中的原始值列，实际不是泄露。2026-05-06 自动检查误报 9 条中 8 条是此原因。详见 `references/sub-patent-generation-workflow.md` Step 6 的检查脚本。
- **分案交底书的步骤编号必须与母案区分** — 母案用 S1-S9，分案应使用不同前缀（R1/R2 for 角色分配, F1/F2 for 失败捕获, A1/A2 for 仲裁），避免审查时混淆。分案编号规则写入 `references/sub-patent-generation-workflow.md`。
- **分案生成后必须做创新性自检** — 生成分案后不能直接输出，必须对照现有技术逐 claim 评估新颖性和创造性。最危险的模式："置信度模型""信誉系统""投票机制"本质上与 Stack Overflow reputation / eBay 信用同原理，审查员会以"公知常识的简单组合"驳回。自检模板：对每个 claim 列出现有技术有无 → 评价是否真正新 → 创造性高/中/低。创造性低的分案应放弃或并入母案。参考 `references/sub-patent-innovation-assessment.md`。
- **分案必须有代码实现支撑** — 纯描述性分案（无代码实现）在实质审查中容易被驳"说明书不支持"。如果某分案的步骤在代码中无对应实现，应在文档头部标注"设计目标"或降级为"扩展方案"，不要伪装为已实现的技术方案。
- **"做什么"缺"怎么做"是最常见的清晰度问题** — 交底书步骤写了"通过预定义的模式匹配规则对错误进行精细分类"（效果），但没写"预定义6类错误的正则表达式模式库，每类包含多个匹配规则"（实现）。代理人拿到后需要反复追问。自检方法：对每个步骤问"如果我是审查员，我能根据这段描述实现这个功能吗？"。补充模板：每步200-300字技术实现路径，包含数据结构（字段名/类型）、处理逻辑（匹配/提取/转换规则）、异常处理（失败时的fallback策略）。重点补充：分类规则库的构成、模板的数据格式和状态机定义、检索拦截层的实现模式（middleware/interceptor）、矛盾检测的分析模型（NLI/规则引擎）。参考：MEDICI-PX V5 S3/S5/S6/S7 补充（2026-05-07）。
- **附图必须是黑白等宽风格** — 专利附图要求纯黑白、直角矩形、等宽字体（Courier New），不能用暗色渐变、彩色分类、圆角等技术演示风格。详见 `references/patent-diagram-svg-pattern.md`。flowchart 用实线箭头表顺序、虚线箭头表反馈/循环、粗框表核心创新步骤；架构图用虚线框表外部实体。两种图都用白色背景 + 纯黑线条。
- **评估→分文件生成→合并回原文档是标准工作流** — 当交底书需要补充多个维度（权利要求、附图、技术实现、创新点重组）时，先评估出改进优先级，然后逐项生成到独立文件（避免原文档过大导致 context 溢出），最后用 patch 合并回原文件。合并时逐个 patch（不要一次性写全文），每步验证 diff。这比直接在原文档上改更安全，也便于用户保留独立副本。参考：MEDICI-PX V5 增强（2026-05-07），4项改进分3个独立文件生成后合并。
- **评估后改进优先级：权利要求 > 技术实现 > 创新点重组 > 附图** — 从评估实战数据看，补权利要求草稿收益最高（+5分可操作性），其次是补技术实现路径（+7分方案清晰度），再次是创新点重组（+6分创新性实质），最后是附图（+3分完整性）。但如果原交底书完全无附图，则附图优先级提升到第二（缺附图=不完整的专利）。 — 核心 claim（多因子置信度、仲裁回写权威度）与 Stack Overflow reputation 同原理，创造性不足。仲裁+置信度技术保留在 P1 的 S8/S9 中作为母案的一部分，不再单独申请分案。参见 `references/sub-patent-innovation-assessment.md`。
- **"遇到问题时手动搜索" ≠ "任务开始前自动消费"** — AGENTS.md says agents search knowledge when they encounter problems (manual trigger). Don't write patent claims describing this as "agents automatically retrieve relevant knowledge before task execution" (automatic trigger). The manual vs automatic distinction is a fundamental architectural difference that examiners will catch.
- **Verify module-to-module call chains, not just individual modules** — Two modules (e.g., conflict detection + arbitration queue) may each work correctly in isolation but lack the trigger code that connects them. Search for imports/calls between modules, not just their existence. "A detects conflict → ??? → B enters arbitration" — the "???" is a gap.
- **Innovation = the complete loop, not individual components** — each piece (git sync, pub/sub, reputation system) has prior art. The novelty is the specific closed loop: Hook→Template→Arbitration→ConfidenceWriteback→FutureKnowledgeRanking. Frame claims around the loop, not individual mechanisms. BUT: every link in the claimed loop must have code. "Write→Sync→Retrieve→Consume→Write" is only novel if ALL 5 links exist.
- **创新点重组模式：当单个创新点不强但串联后有飞轮效应时** — 6个创新点单看评分可能都 ≤ 7/10（新颖性一般），但串联成闭环后形成的"正向飞轮"是真正的差异化。处理方式：将"闭环飞轮"提升为第一创新点，详细描述完整链路（失败捕获→知识生成→强制检索→复用验证→仲裁→置信度→路由优化），然后将6个子创新点降级为闭环的组成环节。这比"平铺6个普通创新点"在审查时更有说服力，因为审查员关注的是"整体方案是否产生了1+1>2的技术效果"。适用场景：多模块系统、知识管理/记忆系统、多Agent协作框架。参考：MEDICI-PX V5 评估（2026-05-07），重组后创新性实质从16分提升到22分。详见 `references/disclosure-evaluation-rubric.md`。
- **方法类方案只能走发明专利** — 实用新型只保护产品形状/构造，不保护方法。如果核心是方法（步骤S1-S8），必须走发明专利。同步申请软件著作权（低成本、快拿证）作为补充保护代码文本。
- **分案关系措辞** — "技术依赖 P1（基于 XX 机制），权利要求独立"是合法表述。分案的权利要求必须独立撰写，但技术实现可以依赖母案机制。这不是矛盾。
- **frontmatter 格式以代码为准** — 写交底书示例时必须读实际代码确认格式（JSON vs YAML、字段名）。queue_lesson.py 用 JSON，字段是 source/created/status，不是 node_id/created_at。
- **S/S8 衔接** — S7（仲裁调整权威度）和 S8（置信度公式）是因果关系。加一句"上述权威度调整在每次仲裁后立即生效，影响后续该节点产出知识的置信度计算"即可消除阅读歧义。
- **Cognee 描述要精确** — 不要说"简单的自动图谱合并"，Cognee 有 merge 策略和 force 参数。改为"依赖图谱合并策略，无法表达语义层面的矛盾——即两个节点描述同一事实但结论相反时，无法保留双方观点供用户判断"。
- **Don't assume data format — verify against code** — writing "YAML frontmatter" when code actually generates JSON is a P0 error. Always `read_file` the serialization code and check: JSON? YAML? custom? Also verify field names (e.g. `source` vs `node_id`, `created` vs `created_at`).
- **Don't assume "push" when code shows "pull"** — if agents run `cron git pull --ff-only`, the architecture is pull-based, not push-based. Writing "Hub pushes to subscribers" when A2A broadcast is dead code = aspirational claim. Describe the actual mechanism (cron pull + domain filter) and note push as an optional enhancement.
- **CN patent numbers must be verified before inclusion** — if you can't access CNIPA (https://pss-system.cponline.cnipa.gov.cn/), mark all CN numbers as "待验证" and add a note that verification is required before submission. Inventing plausible-sounding CN numbers is worse than having none.
- **Self-referencing contradictions kill credibility** — if section 1.3 says "在先专利：否", don't list your own project's patent in section 1.2 as "existing technology". Check for contradictions between sections after modification.
- **Fixing one claim can break adjacent claims** — when you fix S4 from "push" to "pull", you must also update: S5 (which references "收到推送"), innovation point #3 (which says "精准推送"), 缺点四 (which contrasts with "全量广播"), and 技术问题三. Cross-reference consistency check after every fix.
- **创新点措辞：避免混用 git 术语和论文术语** — 专利审查员不是程序员。"文本级合并冲突"同时涉及 git 术语（合并冲突）和论文术语（文本级/语义级），读着拗口且产生歧义。正确写法是把两个机制的责任分离："[机制A]由[系统A]检测，[机制B]由[系统B]处理"。例如："版本冲突由版本控制系统检测，语义级知识冲突由置信度机制处理"。这种结构让审查员清楚地看到两层冲突各有独立处理路径。
- **模糊化处理（V3_模糊）是提交前的标准步骤** — 代理所拿到交底书后会做形式审查，但具体的工具名、参数值、文件路径不应出现在交底书中（防止竞争对手复制实现）。模糊化规则：工具名→通用描述（飞书→即时通讯平台，BGE-m3→预训练语言模型，SQLite→本地持久化存储，cron→定时调度机制），参数值→"可配置"（λ=0.001→衰减率可配置），字段名→中文（title→标题），文件路径→泛化（./storage/skill_index.json→本地持久化存储）。保留技术架构和创新点（审查必需），保留方法步骤和公式结构（审查必需），模糊化一切实现细节。参考 `references/patent-fuzzy-treatment-pattern.md`。
- **方案选择：补齐代码 vs 删减 claim** — 当全步骤验证发现某步骤（如 S5）零实现时，有两个选项：方案A 删减 claim（安全但保护范围缩小），方案B 补齐代码再提交（保持保护范围但需额外开发）。选择方案B 时，补齐的代码必须通过 dry run 验证，且交底书中的描述必须与实际实现完全一致（不能写"BGE-m3 语义匹配"但代码只有关键词匹配——除非明确标注降级策略）。
- **RAG prior art 陷阱** — 任何"检索→注入→消费"的 claim 必须强调 Agent 集群特定场景（跨节点消费反馈、复用验证日志、消费状态追溯），不能泛化为 RAG 模式。审查员会指出 RAG 本身就是"任务驱动检索→注入上下文"的标准做法。对比表中不要用"任务驱动知识消费"这种泛化措辞，改为"跨节点知识消费与验证"。（2026-05-06 P1 交叉评审发现）
- **母子专利阈值冲突** — 母案和分案使用相似阈值做不同用途时（如母案 S2 用 0.92 做去重合并，分案 A1 用相似阈值做矛盾检测），必须在分案中标注"阈值与母案 XX 步骤独立配置"。否则相似度 0.93 时逻辑冲突：母案说"合并"，分案说"可能矛盾"。（2026-05-06 P4 交叉评审发现）
- **知识消费闭环必须有验证步骤** — "写入→同步→检索→消费→再写入"的闭环缺少"验证知识是否被应用"环节。正确闭环应为"写入→同步→检索→消费→验证→再写入"。验证机制：在 Agent 输出中检测是否包含所注入知识片段的关键词或动作标识，未检测到则记录为"未复用"，汇总生成复用验证日志。（2026-05-06 P1 交叉评审发现）
- **分案无实现代码时必须降级** — 分案的技术方案在代码中完全没有实现时（如 P2 的 R2-R6 动态能力发现），纯描述性专利在实质审查中容易被驳"说明书不支持"。必须在文件头部加状态说明，标注哪些步骤是设计目标、哪些有实际代码。用户可选择：降级为扩展方案（安全）或补充实现后再申请。（2026-05-06 P2 交叉评审发现）
- **S1/S 措辞区分当前限制与技术方案** — 不要把当前实现的限制（如"不会自动重试"）写成技术方案本身。正确做法：描述实际行为（"暂存本地仓库"）+ 标注未来扩展方向（"自动重试机制为未来扩展方向"）。审查员看的是技术方案，不是运维日志。
- **分案生成后做创新性评估** — 生成全部分案后、提交前，逐篇做三维评估：新颖性（与 prior art 的区别）、创造性（非显而易见性）、说明书支持（有无代码实现）。评估结果决定申请优先级。实战排序：P3（有代码，最强）> P1（部分实现）> P2（无实现，降级）> P4（创造性弱，暂缓）。详见 `references/sub-patent-cross-review-case-study.md`。
- **专利家族表注明上下游关系** — 当分案之间是上下游关系时（如 P3 生产知识、P1/S5 消费知识），专利家族表的关系列应明确注明"P3 为知识生产端，P1/S5 为知识消费端，两者为上下游关系"，避免审查员认为两者功能重叠。
