---
name: edoc-rag
description: FANUC 机器人知识库 RAG 检索 — 向量库 wiki_docs 200,752+ vectors，BGE-base-zh-v1.5 768维，ChromaDB + BM25 混合检索，支持飞书 Bot 自动调用
category: data-science
---

# FANUC Robot Knowledge Base RAG

## Phase 0: 知识检索（硬性门禁）

> RAG 查询是高频操作，查询结果直接影响答案质量。开始查询前，先确认 lessons/ 中是否有已知检索问题或已修复的故障。

### Step 0.1: 搜索 lessons

```bash
cd ~/Agent-Medici
python3 search_knowledge.py "rag\|FANUC\|检索\|chromadb\|BM25" --lessons
```

**Output gate：** 输出匹配 lessons 数量 + top-3 文件的实际摘要。如果返回空则输出 `"search_knowledge.py 空结果"`。

### Step 0.2: 输出检索结论

```
📋 检索结论
  - 可复用的 lessons: [标题列表]
  - 已知检索问题与本查询的关联: [具体说明]
  - 核心风险（不检索可能踩的坑）: [一句话]
```

**Output gate：** 必须输出此结论块。不输出 = 不允许进入查询阶段。

## 快速调用

### 方式 A：rag_answer.py（完整管道，含 LLM 生成）

```bash
# ⚠️ 路径需确认存在，不同部署可能不同
# 有参数：单次查询（供 gateway subprocess 调用）
~/.hermes/hermes-agent/.venv/bin/python3 ~/.hermes/scripts/rag_answer.py "SRVO-001 急停报警"
# 输出：格式化字符串，含来源、耗时、答案（供飞书展示）

# JSON 模式（gateway 用 --json，精准拿结构化数据）
~/.hermes/hermes-agent/.venv/bin/python3 ~/.hermes/scripts/rag_answer.py --json "SRVO-001 急停报警"
```

### 方式 B：rag_core.retrieve()（纯检索，无 LLM，适合 agent 内联调用）

当 `rag_answer.py` 不存在时（路径因部署而异），直接 import rag_core：

```python
import rag_core
results = rag_core.retrieve('你的查询关键词')
for r in results[:5]:
    print(f'score={r["score"]:.4f} src={r["source"]}')
    print(r['text'][:400])
```

- rag_core.py 位于 `/home/hp/rag_core.py`
- retrieve() 返回 list[dict]，每个 dict 含 `text`, `source`, `score`, `filename`, `entity_alarms`, `entity_models`, `topic_tags`, `brand` 等字段
- 首次调用需加载嵌入模型 + 向量库（~8s），后续调用复用
- ⚠️ 终端输出会有 HF Hub warning + 进度条，可用 `grep -v "Warning\|Loading\|嵌入\|已加载"` 过滤

**`log_channel` 参数（2026-06-05 新增）**：传 `log_channel="feishu"` 时自动将查询写入 `rag_query_log.db`，不传则不记录（不影响内部调用）：

```python
# 飞书 bot 回答时 — 自动记录查询日志
results = rag_core.retrieve('SRVO-023 报警', log_channel='feishu')

# agent 内部检索（不记录日志）
results = rag_core.retrieve('SRVO-023 报警')
```

## RAG 本地 Web 界面

```bash
bash /home/hp/start_rag.sh
```

启动 4 个服务：

| 服务 | 端口 | 用途 |
|------|------|------|
| RAG Web UI | localhost:7860 | Gradio 问答交互界面 |
| 管理面板 | localhost:7861 | 巡检报告、badcase 审核 |
| RAG API | localhost:8002 | 飞书/微信机器人接口 |
| Ollama | localhost:11434 | 本地 LLM (Qwen2.5:3B) |

停止：`pkill -f ollama; pkill -f rag_web; pkill -f rag_api; pkill -f rag_admin`

## BM25 检索（2026-06-02 更新）

- 向量检索 + BM25 并行，RRF 融合排序
- 200,752+ vectors，嵌入模型运行于 CPU
- 4 通道 LLM：MiMo-Flash/Pro（Mify API）、DeepSeek-V3、Qwen2.5:3B（Ollama 本地）
- 启动预热：向量库 + BM25 索引 + 嵌入模型

## Tag Filter 覆盖情况

- **数据源**：`~/.hermes/scripts/tag_results.jsonl`（127 条，2026-04-15）
- **已知问题**：67/127 PDF 的 `robot_model: Unknown`，tag 过滤对这些查询失效
- **当前行为**：无匹配关键词时返回 `[]`（不过滤），不影响检索结果

## 使用场景

| 向量库 | 路径 | Chunks | 模型 | 状态 |
|--------|------|--------|------|------|
| **wiki_docs** | `/home/hp/rag_chromadb/` | 200,742+ | BGE-base-zh-v1.5 768维 | ✅ 生产主力 |
| edoc_v10_zh | `/mnt/d/Eric/知识库/chroma_db_v3` | 14,889 | BGE-large-zh 1024维 | 备用 |

- **检索脚本**：`~/.hermes/scripts/rag_answer.py`
- **BM25 索引**：`/home/hp/rag_chromadb/bm25_index.pkl`（首次查询自动重建，手动触发：`_bm25_index._ensure_index()`）
- **Query Embedding 缓存**：`~/.hermes/scripts/q_embeddings.npz`

## 关键路径（2026-04-16 确认）

| 资源 | 路径 |
|------|------|
| 向量库 | `/home/hp/rag_chromadb/`（NOT `~/.hermes/chroma_db_v4`） |
| Collection 名 | `wiki_docs`（200,752+ vectors，2026-06-15 更新） |
| BM25 索引 | 内置于 rag_core.py，启动时自动构建 |
| Embedding 模型 | BAAI/bge-base-zh-v1.5 (768维, CPU) |

## 关键参数

- `coll.query(..., n_results=20)` — 向量 Top-20 候选
- BM25 rerank：取 top-20 向量候选后用关键词命中重排
- **合并策略**：每个 source 保留 min dist chunk，最终按 final_score 排序
- **Metadata 过滤**：通过 `_get_tag_filter` 从 `tag_results.jsonl` 实现

## FANUC 报警代码 PDF 直查（RAG 兜底方案）

当 RAG API 超时或向量库未命中 FANUC 报警代码时，可直接从 PDF 手册中用 `pdftotext` 提取。

**所有报警代码系列（SRVO/SSPC/SVGN/SYST/TAST）均在 B-83284EN-1_08_01.PDF 中。**

详见：📄 [references/fanuc-alarm-code-pdf-mapping.md](references/fanuc-alarm-code-pdf-mapping.md)

## FANUC 选件号解码（1A05B-2600-XXXX）

当用户给出 FANUC 零件号时，按前缀字母分类：**H**=硬件、**J**=软件功能、**R**=机器人/附加轴。

详见：📄 [references/fanuc-option-code-catalog.md](references/fanuc-option-code-catalog.md)

## 备份与恢复（全备份 vs 镜像备份）

用户问备份时必须区分两种：**全备份**（文件级，可选择性恢复）和**镜像备份**（FROM/SRAM 全盘，F1+F2 启动恢复）。

**常见陷阱**：镜像恢复后报 SRVO-038 是正常现象，需要重新做简易零点标定。

详见：📄 [references/fanuc-backup-and-restore.md](references/fanuc-backup-and-restore.md)

## ⚠️ FANUC TP 编程知识（非手册来源）

DB 附加指令、运动指令与 CALL 的兼容性等 TP 编程细节，RAG 向量库中无对应 PDF（FANUC_spot+说明书.pdf 未入库）。

详见：📄 [references/fanuc-tp-programming-knowledge.md](references/fanuc-tp-programming-knowledge.md)

## ⚠️ 伺服焊枪第三方马达使用

用户问"伺服点焊使用第三方马达"时，直接查此参考文件。

详见：📄 [references/fanuc-servo-gun-third-party-motor.md](references/fanuc-servo-gun-third-party-motor.md)

## ⚠️ PRIO 报警处理（安全/通信类）

PRIO 系列报警涉及安全功能和现场总线通信，处理时需要额外谨慎。

| 报警 | 含义 | 处理要点 |
|------|------|----------|
| **PRIO-378** | **待确认**：可能是 Safety I/O 参数不一致 或 PROFINET 连接失败 — RAG 知识库返回"PROFINET 连接失败"（2026-06-03 纠正），但此前记录为"安全 I/O 参数不一致"。遇到此报警时**必须直查 PDF 确认**，不能凭记忆回答 | 直查 B-82864EN_05.PDF 确认含义后给出处理步骤 |
| PRIO-323 | CC-Link CRC 错误 | 检查终端电阻、线缆、站点编号/波特率配置 |

**PRIO-378 详细处理**（⚠️ 含义待 PDF 确认，见上表）：
1. 确认安全状态：`MENU → 6 系统 → F1 类型 → 安全`
2. 重新验证 DCS 参数（安全速度、安全区域、轴范围、碰撞检测阈值）
3. 保存并应用 → 关电重新上电
4. 如果无法解除：检查安全 IO 模块地址拨码、安全门信号、DCS 安全板固件版本

⚠️ PRIO-378 涉及安全功能，解除后**必须验证安全功能正常**（安全速度、安全区域、急停）。不能简单忽略。

## ⚠️ FANUC UI 画面查询的桥接策略（中文口语 ≠ 手册术语）

**痛点**：用户问"X 画面里的输入信号/变量"时，纯语义检索常返回 ≤0.5 分，因为中文口语（"抓手物料搬运阀"、"焊枪夹紧信号"）和 FANUC 手册英文术语（MH Valves / Spot Equip / Clamp Inputs）不直接对应。

**桥接策略**：用相关**报警代码**作桥接词，再用标准术语二次验证。

| 用户口语 | 桥接报警 | 命中术语 |
|---------|---------|---------|
| 抓手物料搬运阀输入信号 | `MHND-236 valve not setup` | MH Valves |
| 抓手夹紧/松开信号 | `MHND-237 clamp not setup` | Clamp Inputs |
| 焊枪关闭信号 | `SPOT-021 GUN CLOSE ON` | Spot Equip I/O |
| 抓手/夹具变量 | `MHND-234/235 Valve %s` | S#（阀门号） |

**执行步骤**：
1. 用户原词查询 → top-1 score ≤0.5
2. 识别主题相关的 FANUC 报警前缀（**MHND**=物料搬运、**SPOT**=点焊、**SRVO**=伺服、**SYST**=系统、**PRIO**=安全通信、**ARC**=弧焊）
3. 用 `"<现象> not setup"` / `"<现象> fault"` + 报警前缀作桥接查询 → 报警对策字段直接给出 UI 路径（"MENU → I/O → X"）
4. 直查对应 PDF（报警代码手册 B-83284EN-1 + 应用功能手册 B-83124CM-6 等）确认 UI 字段名 + 变量
5. **外部文档优先**：关键文档可能在 `/mnt/c/Users/hp/Downloads/待入库/` 等非标准 wiki 目录（如小米《FANUC机器人小米标准软件使用手册_v19.pdf》就在 Downloads 而非 `/mnt/d/知识库wiki/`），但已被 RAG 索引到

**常见命中模式**：`报警代码"对策"段` = 画面路径 + 变量名。例：
> "MHND-236 … 对策：选择 MENU（菜单）、I/O（输入/输出）、MH Valves（MH 阀门），设置夹具信号。"
> → 直接得到 `MENU → I/O → MH Valves` 路径，且明确点出"阀门信号数（S#）"变量。

完整案例见：[references/fanuc-mh-valves-and-input-signals.md](references/fanuc-mh-valves-and-input-signals.md)

## ⚠️ 主板七段 LED 报警码 vs TP 报警码

用户说"主板报警代码 5/6"时，是**七段 LED 硬件诊断码**（0-7），不是 TP 上的 SRVO/SYST 软件报警码。两者是完全不同的体系。

| 体系 | 显示位置 | 报警格式 | 来源文档 |
|------|---------|---------|---------|
| TP 报警码 | 示教器屏幕 | SRVO-023, SYST-347 等 | B-83284EN-1_08_01.PDF |
| 主板七段 LED | 主板上的 7 段数码管 | 0-7 数字 | book.pdf (B-82285EN-2/02) |

**检索策略**：七段 LED 用英文关键词检索效果远好于中文（英文 score=0.980 vs 中文 0.580）。

详见：📄 [references/fanuc-alarm-code-pdf-mapping.md](references/fanuc-alarm-code-pdf-mapping.md) → "主板七段 LED 报警码" 章节。

## ⚠️ SRVO 报警处理：硬件报警 vs 可配置项

用户问"在哪里改"时，需区分报警性质：

| 报警 | 性质 | 用户意图判断 |
|------|------|-------------|
| SRVO-006（保险丝熔断） | **硬件报警**，不能在软件里改 | 用户可能混淆了"改配置"和"换硬件"，需追问 |
| SRVO-038（脉冲值不匹配） | **标定问题**，做零点标定即可恢复 | 常见于镜像恢复/电池更换后 |
| SRVO-062（BZAL 电池报警） | **硬件问题**，换电池+重新标定 | 先换电池再标定，顺序不能反 |
| PRIO-378（安全IO参数不一致） | **配置问题**，DCS参数需重新保存 | 恢复镜像后常见；进安全配置画面核对并保存 → 重启 |
| Collision Guard 灵敏度 | **可配置**，`$COLLGUARD` 系统变量 | 这才是真正"能改"的 |

**处理策略**：先用 RAG 查报警定义 → 判断是硬件还是软件 → 如果用户问"改"但报警是硬件性质，澄清后给出正确处理步骤。

## ⚠️ 机型变体对比查询（F vs R / 不同后缀）

> RAG 语义搜索对"XX 和 YY 有什么区别"类查询效果差 — 每个 chunk 只含单一机型信息片段，无法同时召回两个变体的对应规格行。**必须用 pymupdf 直查 PDF 规格表。**

**查询路径**：
1. 确定系列 → 找对应 PDF（R-2000iC → B-83644CM, R-2000iB → B-83195CM, M-900iA → B-83624CM 等）
2. 用 pymupdf 搜索两个机型名同时出现的页面（规格一览表、搬运标签、选购件列表）
3. 规格表通常在 PDF 前 10% 页面（前言/基本规格章节）

**FANUC 型号后缀含义**：F=地面, R=高台, U=通用/顶吊, L=长臂, P=冲压, T=搬运, S=特殊, H=中空腕, WE=焊接环境

**⚠️ 清洗型（防水/防滴）vs 常规型 — 保养周期不同（用户纠正 2026-06-11）**

用户明确指出：回答保养/润滑相关问题时，**必须区分机器人是常规型还是清洗型（防水/防滴型）**，两者保养周期不同。

| 维度 | 常规型 | 清洗型（防水/防滴） |
|------|--------|-------------------|
| 润滑油更换周期 | 1年 或 3840小时 | 通常更短（需查清洗型专用手册） |
| 密封件检查 | 标准周期 | 需更频繁检查（防水密封结构） |
| 润滑脂规格 | 标准规格 | 可能需防水型润滑脂 |

**处理策略**：
1. 回答保养问题前，先确认机器人型号是否有防水/防滴后缀或属于清洗系列
2. 如果是清洗型，**必须检索对应的清洗型维修说明书**，不能直接套用常规型数据
3. 常见清洗型标识：型号含"W"后缀、文档标题含"洗净"/"防滴"/"防水"、或用户明确说明是清洗环境

详见：📄 [references/fanuc-model-naming-and-comparison.md](references/fanuc-model-naming-and-comparison.md)

## ⚠️ DCS（双检安全）操作

> B-83184CM_09.PDF 已被 RAG 向量库索引（DCS介绍.pdf 等），DCS 相关查询可命中。
> 另有3篇专题文档补充：`FANUC安全信号体系.md`、`FANUC碰撞检测功能.md`、`FANUC_DCS安全功能配置.md`（2026-06-15 创建）。
> 对比型查询（如"DCS vs Collision Guard"）仍建议直查 PDF 获取完整对比数据。

详见：📄 [references/fanuc-3dv-cobot-terminology.md](references/fanuc-3dv-cobot-terminology.md)

| 查询类型 | PDF 手册 | 快速入口 |
|---------|---------|---------|
| DCS 密码更改/重置 | B-83184CM_09.PDF section 2.5 (p28-29) | `references/fanuc-dcs-procedures.md` |
| 应用至 DCS 参数 | B-83184CM_09.PDF section 1.3 (p15-16) | 同上 |
| DCS 画面操作 | B-83184CM_09.PDF section 2 (p21+) | 同上 |
| 报警代码 SYST-212/219 | B-83284CM-1_08.PDF | `references/fanuc-alarm-code-pdf-mapping.md` |

详见：📄 [references/fanuc-dcs-procedures.md](references/fanuc-dcs-procedures.md)

## ⚠️ 常见故障：飞书 Bot 报 401 Invalid API Key

**症状**：RAG API 直接测试正常，但飞书 bot `@正义` 返回 401。根因通常是 `auxiliary.compression` 缺少 `api_key_env` 配置。

**快速诊断**：
```bash
# RAG API 正常但 bot 报 401 = Gateway auxiliary 问题
curl -s http://localhost:8002/query -H "Content-Type: application/json" \
  -d '{"query":"test","session_id":"test"}' | head -c 100

# 检查 Gateway 日志确认
hermes logs --lines 30 | grep -E "auxiliary|compression|401"
```

**修复**（两步）：
```bash
# 1. 重启 Gateway 使 auxiliary 配置生效
hermes gateway restart

# 2. RAG API 是独立进程，检查是否仍在运行
curl -s http://localhost:8002/health || bash ~/start_rag_api.sh
```

→ 详见完整排错指南：[references/feishu-bot-401-troubleshooting.md](references/feishu-bot-401-troubleshooting.md)

## ⚠️ RAG API 全通道故障诊断

**症状**：所有查询返回"所有模型通道均不可用，已降级为纯检索模式"。

**诊断顺序**：

```bash
# 1. API 进程是否存活
curl -s -o /dev/null -w "%{http_code}" http://localhost:8002/health
# 200 = API 进程正常，问题在 LLM 通道；000 = API 进程挂了

# 2. 各通道状态（看 rag_api 启动日志）
tail -20 /tmp/rag_api.log
# 或 grep 错误类型
grep "不可用" /tmp/rag_api.log
```

**常见根因**（按概率排序）：

| 症状 | 根因 | 修复 |
|------|------|------|
| MiMo 两个通道都是 401 | `MIOFFICE_API_KEY` 过期或未设置 | 更新 `.bashrc` 中的 key → 杀进程重启 rag_api.py |
| DeepSeek Authentication Fails | `DEEPSEEK_API_KEY` 过期 | 同上 |
| Qwen Connection error | Ollama 没启动 | `OLLAMA_MODELS=/mnt/d/ollama/models /mnt/d/ollama/bin/ollama serve` |
| **进程启动即崩溃** (RuntimeError: client has been closed) | **HF Hub 网络不可达** — 模型加载时 httpx 崩溃 | 设 `local_files_only=True` + `HF_HUB_OFFLINE=1`，详见陷阱 1 |

**⚠️ rag_api 必须用 mkdocs-env venv 启动**

Hermes Agent 的 venv (`~/.hermes/hermes-agent/venv/`) 中的 httpx/huggingface_hub 版本与 mkdocs-env 不同，会导致模型加载行为差异。**永远用 start_rag.sh 或显式 `source /home/hp/mkdocs-env/bin/activate`** 启动 rag_api/rag_web/rag_admin。

**⚠️ MiMo API Key 生命周期**：Mify 的 key 可能有使用次数或时间限制。测试时 200 但进程重启后变 401 的情况出现过。如果 key 反复失效，去 api.llm.mioffice.cn 重新生成。

**⚠️ .bashrc 旧 key 覆盖陷阱（2026-06-02 踩坑）**：`.bashrc` 中的 `MIOFFICE_API_KEY` 会在 shell 启动时加载。如果 `.bashrc` 里有旧 key，即使 inline 设置新 key（`MIOFFICE_API_KEY=新key python3 rag_api.py`），也可能因 shell 变量优先级问题导致旧值残留。

**正确 key 更新流程**：
```bash
# 1. 先测试新 key 有效
curl -s -w "\n%{http_code}" "https://api.llm.mioffice.cn/v1/chat/completions" \
  -H "Authorization: Bearer 新key" -H "Content-Type: application/json" \
  -d '{"model":"xiaomi/mimo-v2-flash","messages":[{"role":"user","content":"hi"}],"max_tokens":5}'
# 200 = 有效

# 2. 更新 .bashrc（不能直接 sed 因为 key 含特殊字符，用 python3）
python3 -c "
import re
with open('/home/hp/.bashrc') as f: content = f.read()
content = re.sub(r'MIOFFICE_API_KEY=*** open('/home/hp/.bashrc', 'w') as f: f.write(content)
print('Updated')
"

# 3. 杀旧进程 + source .bashrc + 重启
ps aux | grep rag_api | grep -v grep | awk '{print $2}' | xargs kill
# 必须用 background=true 启动，不能用 &
```

**重启 RAG API 流程**：
```bash
# 1. 杀旧进程
ps aux | grep rag_api | grep -v grep | awk '{print $2}' | xargs kill
# 2. 用新 key 重启（必须 export 在 python3 之前）
cd /home/hp && MIOFFICE_API_KEY=新key CUDA_VISIBLE_DEVICES="" python3 rag_api.py &>/tmp/rag_api.log &
# 3. 等待向量库加载（~8s），验证
sleep 10 && curl -s http://localhost:8002/query -H "Content-Type: application/json" \
  -d '{"query":"test","session_id":"test"}' | head -c 200
```

## ⚠️ log_query 错误降级（2026-06-15）

DB 写入失败时自动写入 `query_log_fallback.jsonl` 兜底，不丢失日志。兜底文件最大 1000 行自动截断。

每个 `retrieve()` 调用自动生成 `request_id`（格式 `rq_xxxxxxxx`），透传到日志记录。可从飞书消息回溯到 query_log 记录。

## ⚠️ 查询日志（rag_query_log.db）

飞书 bot 查询通过 `retrieve(log_channel="feishu")` 自动写入 `rag_query_log.db`（2026-06-05 修复）。

**2026-06-15 增强：**
- `log_query()` 失败时自动写入 `query_log_fallback.jsonl` 兜底，不丢失日志
- 兜底文件最大 1000 行，超过自动截断
- `retrieve()` 自动生成 `request_id` (rq_xxxxxxxx) 透传到日志，可从飞书消息回溯
- `sqlite3.connect(timeout=5)` 防止锁等待
- `infer_risk_tags()` 自动标记 9 种风险标签（low_confidence/no_chunks/slow_query 等）
- `risk_tags/has_source/source_count` 列已入库

**⚠️ log_query() 静默失败陷阱**：`query_log` 表 schema 必须包含 `category` 列（TEXT DEFAULT ""）。如果缺失，`log_query()` 会因 `OperationalError: table query_log has no column named category` 静默返回 None，所有日志写入全部丢失。

**诊断**：
```bash
python3 -c "
import sqlite3
db = sqlite3.connect('/home/hp/rag_query_log.db')
cols = [row[1] for row in db.execute('PRAGMA table_info(query_log)').fetchall()]
print('Has category:', 'category' in cols)
db.close()
"
```

**修复**：
```bash
python3 -c "
import sqlite3
db = sqlite3.connect('/home/hp/rag_query_log.db')
db.execute('ALTER TABLE query_log ADD COLUMN category TEXT DEFAULT \"\"')
db.commit()
print('Fixed')
db.close()
"
```

## ⚠️ 巡检题库维护（RAG巡检题库_200题_20260508.json）

**题库文件位置**（双写，必须同步）：
| 文件 | 路径 | 用途 |
|------|------|------|
| 主题库 | `/mnt/c/Users/hp/Desktop/自研/rag-docs/RAG巡检题库_200题_20260508.json` | daily_audit.py 加载源 |
| 镜像 | `/home/hp/audit_reports/questions_200.json` | 备用加载路径 |

**daily_audit.py 加载逻辑**：先查 `_RAG_DOCS/RAG巡检题库_200题_20260508.json`（`_RAG_DOCS` 默认 `/mnt/c/Users/hp/Desktop/自研/rag-docs`），找不到再查 `/home/hp/RAG巡检题库_200题_20260508.json`。修改主题库后必须同步镜像。

**题库 JSON 格式**：
```json
{
  "id": "L3-041",        // L1/L2/L3 前缀 + 3位数字
  "level": "L3",         // L1=单实体, L2=跨文档, L3=高难度
  "tag": "弧焊",          // 分类标签
  "query": "焊接过程中...",
  "expect": {
    "must_contain_any": ["关键词1", "关键词2"],  // 结果中至少命中一个
    "min_top_score": 0.45
  }
}
```

**题库来源层次**：
1. MD 原始题库（人工编写，质量最高）
2. candidate_questions_*.md（候选题，需人工审核后合并）
3. badcase_pending.jsonl（`status: pending` 的条目会被 daily_audit 自动纳入，ID 前缀 `V2-`）
4. 从知识库实际内容生成的新题（需验证 retrievability）

**维护流程**：
1. 修改 JSON → 2. 同步镜像 → 3. `daily_audit.py --dry-run` 验证抽样 → 4. 确认无重复 ID

**⚠️ 去重陷阱**：按 word overlap >60% 去重太激进，会误删合法题目（如"焊接速度过快过慢产生什么缺陷" vs "焊接电流电压匹配关系对焊缝成型的影响"只有4个共同词但 overlap 可能超阈值）。去重后必须人工检查被删题目列表，确认没有误杀。

## ⚠️ 知识库无内容的分类不要加题

ROBODRILL/CNC加工/激光切割/协作机器人(CR系列) 在知识库中无实质内容，加了只会产生 bad case。选型时先用 `rag_core.retrieve()` 测试该分类的 top_score 是否 ≥0.6。

**⚠️ SVGN 系列是 FANUC 合法报警前缀**（已在 FANUC_ALARM_PREFIXES 中）。报告中将 svgn-382 归类为"非FANUC代码"是指题库噪音（知识库中该代码无对应文档），不是说 SVGN 本身不是 FANUC 前缀。检索层不应硬过滤 SVGN 查询。

## ⚠️ RRF 融合 0.500 分数天花板（2026-06-15 发现）

**症状**：新文档在 BM25 独立检索中排 #1（40.920），纯向量检索中也命中（0.830），但 hybrid retrieve 返回 score=0.500。

**根因**：RRF 融合中向量候选数 `n_results=top_k=8`。如果新文档只在 BM25 前列、不在向量 top-8 中：
- RRF = 1/(60+1) = 0.0164（仅 BM25 单路贡献）
- 归一化: 0.0164 / (2/61) = 0.500

**触发条件**：新导入的文档被大量相似 PDF 挤出向量 top-8，但 BM25 关键词匹配高。

**缓解**：
1. 增加向量 `n_results` 参数（当前 DEFAULT_TOP_K=8，可考虑调到 20）
2. 新文档写入后立即测试，确认在目标查询中进入向量 top-8
3. 如果文档内容足够独特（如专题文档），通常在向量检索中也能排前列

## ⚠️ 库内文件名带 "FANUC" 不等于 FANUC 官方（标签污染陷阱）

**案例**（2026-06-22 发现）：
- 库内文件：`[4] FANUC's Standard Manual Handling Programming(Version 5.0).pdf`（49 chunks）
- 文件名看起来像 FANUC 官方手册
- 实际内容：**Jaguar Land Rover (JLR) 内部 PAN Projects 标准** —— chunk 1 标题就是 "Jaguar Land Rover / PAN Projects / Manual Handling Standard / for FANUC's R30iB Controller"
- 召回效果：用户问 MH Valves / S# 时，BM25 0/20 + 向量 0/20 命中（用的是 JLR 内部术语，不是 FANUC 标准术语）

**污染后果**：
- 后续 LLM 综合回答时可能错误地拿 JLR 内部术语当 FANUC 官方
- 答案里出现"JLR 内部代号"而非 FANUC 标准命名
- 用户在群里看到来源是 "[4] FANUC's ..." 但内容是 JLR，会质疑答案质量

**入库前检查清单**：
1. 读 chunk 1-3 确认作者 / 发布机构 / 适用对象
2. 与同一手册的"标准 FANUC 编号"对比（JLR 用客户代码 / PAN Projects 代码，不是 B-83xxx）
3. 在 metadata 里加 `vendor: jlr` / `vendor: xiaomi` / `vendor: fanuc_official` 标签
4. 来源文件名若可能误导，**重命名为 `[JLR] FANUC Manual Handling Programming.pdf`** 等带厂商前缀的格式

**判定快捷法**：
```bash
# 提取 chunk 1 看是否含 JLR / 小米 / PAN / 三一等客户/集成商标识
pdftotext "<file>" - | head -100 | grep -iE "jaguar|JLR|PAN Projects|小米|xiaomi|客户|end user"
```

## ⚠️ PDF 扫描版提取：pymupdf4llm 自动 OCR 兜底

**场景**：入库扫描型 PDF（`pdftotext` 提取出 0 字符，但 PDF 文件 4-5MB+）。

**正确工具**：`pymupdf4llm`（不是 `pdftotext`）。`pymupdf4llm.to_markdown()` 在文本层为空时自动回退到 Tesseract OCR，并把结果转为 markdown。

**真实案例**（2026-06-22）：
```python
import pymupdf4llm
md = pymupdf4llm.to_markdown('/path/to/scan.pdf')
# 42 页扫描 PDF → OCR 提取 61619 字符 markdown
# 标题结构 / 章节 / 列表均保留
```

**OCR 耗时**：约 5-15 秒 / 页（CPU）。42 页扫描 PDF 约 5 分钟。

**前置依赖**：
```bash
# Tesseract 系统包
sudo apt install tesseract-ocr tesseract-ocr-chi-sim  # 中文 OCR 需要 chi-sim
```

**反模式**：
- ❌ 扫描 PDF 直接 `pdftotext` 拿到 0 行就放弃 — 文本层为空不代表内容为空
- ❌ 把扫描 PDF 强加入向量库（实际是 0 内容 chunk，污染检索）— 必须先 OCR
- ❌ 用普通 OCR 工具（Tesseract CLI）— 丢格式，丢章节结构

## ⚠️ ripgrep 搜不到但 RAG 能命中的情况

**案例（2026-06-10）**：用户问"Solution Arm"，ripgrep 在 `/mnt/d/知识库wiki/` 全目录（含 `rag_data/extracted/*.json`）搜索均无命中，但 RAG API 语义检索命中了 `GM global 1 R-30iA Controller addendum.pdf`（相关度 0.865）。

**根因**：向量库的部分 PDF 来源路径不在 `/mnt/d/知识库wiki/` 目录树内（如 `07_机器人/FANUC手册/` 下的手册），ripgrep 覆盖范围 < 向量库索引范围。

**教训**：ripgrep 全文检索是 RAG 的补充手段，不是替代手段。当 ripgrep 无果时，**必须继续用 RAG API 查询**，不能直接下结论"知识库没有"。参照零结果查询策略的层次 1→4→5 顺序。

## ⚠️ RAG 字段名：query 不是 question

```bash
# ❌ 错误
curl -d '{"question": "..."}}'
# 返回 422: Field required

# ✅ 正确
curl -d '{"query": "..."}}'
```

## ⚠️ 反馈收集（飞书交互卡片）

RAG 回答的反馈通过飞书交互卡片收集（👍👎 按钮）。按钮点击 → Hermes 网关拦截 → 调用 `http://localhost:8002/feedback` → 写入 SQLite feedback 表。

**完整实现**：`rag_feedback_card.py`（发送卡片）+ `feishu.py` 的 `_handle_rag_feedback_card_action()`（处理回调）

详见 `gradio-feedback-panel` skill 的 [references/feishu-card-feedback.md](references/feishu-card-feedback.md) 和 `feishu` skill 的 [references/hermes-card-action-interception.md](references/hermes-card-action-interception.md)。

## ⚠️ 查询规范化（中文别名 + CR系列 + 同义词扩展）

查询进入 retrieve() 前经过 `_normalize_query` → `expand_query` 两级处理。
中文别名（法那科/发那科/法兰克→FANUC）、CR系列（CR35iA→CR-35iA）、
同义词扩展（DCS/干伸长度/起弧收弧等）已部署到 rag_core.py + synonyms.json。

详见：📄 [references/query-normalization-patterns.md](references/query-normalization-patterns.md)

## ⚠️ 报警代码实体提取陷阱（2026-06-13 修复）

**症状**: 某些报警代码（如 MEMO-001）在知识库中有内容，但检索时精确匹配排在第 5 条以后，分数只有 0.500。

**根因 1: `FANUC_ALARM_PREFIXES` 缺少前缀**

`rag_phase1_entity_extract.py` 中的 `FANUC_ALARM_PREFIXES` 决定了哪些报警代码会被提取到 `entity_alarms` 元数据中。如果某个前缀（如 `MEMO`）不在列表中，该系列报警代码不会被索引，`_entity_alarm_search` 就找不到它们。

**诊断**:
```python
# 检查报警代码是否在实体索引中
from rag_core import get_collection, _build_entity_index, _entity_alarm_index
collection = get_collection()
_build_entity_index(collection)
print('MEMO-001 in index:', 'MEMO-001' in _entity_alarm_index)

# 检查元数据
results = collection.get(where_document={'$contains': 'MEMO-001'}, limit=3, include=['metadatas'])
for meta in results['metadatas']:
    print(f'entity_alarms: {meta.get("entity_alarms", "[]")}')
```

**修复**:
1. 在 `rag_phase1_entity_extract.py` 的 `FANUC_ALARM_PREFIXES` 中添加缺失前缀
2. 重新运行实体提取: `CUDA_VISIBLE_DEVICES="" python3 rag_phase1_entity_extract.py`
3. 重启使用向量库的进程（实体索引缓存 `_entity_index_built` 会在新进程中自动重建）

**已确认的完整前缀列表**（2026-06-13）:
```python
FANUC_ALARM_PREFIXES = (
    'SRVO', 'MATE', 'PRIO', 'SYST', 'MENH', 'TPIF', 'MOTN', 'GRP',
    'TSTP', 'PROG', 'FILE', 'SVOF', 'UALM', 'HOST', 'SERVO', 'COMM',
    'DNBT', 'OPTI', 'MACR', 'SPOT', 'STRT', 'TCH', 'PAINT', 'ARC',
    'FCTN', 'DSQC', 'SMB', 'ENC', 'PNIO', 'DRAG', 'JPOS', 'SYS',
    'SVO2', 'SVON', 'CMND', 'MCTL', 'TUN', 'DMIO', 'GIOP',
    'ROTP', 'WELD', 'CUT', 'TOOL', 'DIST', 'MOT', 'CURR',
    'MEMO',  # 2026-06-13 新增
)
```

**根因 2: RRF 融合降低精确匹配分数**

RRF（Reciprocal Rank Fusion）基于排名重新计算分数。即使向量检索返回了包含报警代码的 chunk（原始分数 0.716），如果它排在第 3 名，RRF 融合后分数可能降到 0.500，被语义检索的高分结果（0.976）挤下去。

**修复**（已部署到 `rag_core.py` 排序逻辑后）:
```python
# 报警代码精确匹配加分：确保精确匹配排在语义相似结果前面
alarm_codes = _ALARM_CODE_RE.findall(query)
if alarm_codes:
    for c in chunks:
        text_upper = c["text"].upper()
        for code in alarm_codes:
            code_upper = code.upper()
            if code_upper in text_upper or code_upper.replace("-", "－") in text_upper:
                if c["score"] < 0.95:
                    c["score"] = min(c["score"] + 0.30, 0.95)
                    c["_alarm_exact_match"] = code
                break
```

**效果**: MEMO-001 精确匹配分数从 0.500 提升到 0.800-0.950，排在前 5 条。

**⚠️ SYST 报警码前导零陷阱（2026-06-21 发现）**：`_normalize_query` 给报警码补零（SRVO023 → SRVO-023），但 SYST 系列中部分报警码原始格式不含前导零（如 SYST-347 而非 SYST-0347）。查询 "SYST-347" 命中 B-83184CM_09.PDF score=0.950，而 "SYST-0347" 仅 0.526。**建议**：SYST 系列查询先试不带前导零的格式。

**⚠️ 新增报警前缀后必须重新运行实体提取**: 修改 `FANUC_ALARM_PREFIXES` 后，必须运行 `rag_phase1_entity_extract.py` 更新所有 chunks 的 `entity_alarms` 元数据，否则新前缀不会生效。

详见：📄 [references/alarm-code-entity-extraction-fix.md](references/alarm-code-entity-extraction-fix.md)

## ⚠️ 查询规范化模块（_normalize_query）开发陷阱

### Pattern.sub() 不接受 flags 参数

```python
# ❌ 错误 — 编译后 Pattern.sub() 没有 flags 参数
_CHINESE_ALIAS_RE = re.compile("|".join(re.escape(k) for k in aliases))
q = _CHINESE_ALIAS_RE.sub(lambda m: ..., q, flags=re.I)  # TypeError!

# ✅ 正确 — 编译时加 flags
_CHINESE_ALIAS_RE = re.compile("|".join(re.escape(k) for k in aliases), re.I)
q = _CHINESE_ALIAS_RE.sub(lambda m: ..., q)
```

区别：`re.sub(pattern, repl, string, flags=re.I)` 是模块级函数，接受 flags；`compiled_pattern.sub(repl, string)` 是编译后对象方法，flags 已内嵌在编译时。Pyright 对 `re.sub` + lambda + flags 会误报 `reportCallIssue`，可忽略。

### 新增规范化规则流程

1. 在 `_normalize_query()` 函数中添加规则（位于函数体前部，`expand_query` 之前）
2. 中文别名映射：用 `_CHINESE_ALIASES` dict + 预编译正则，编译时加 `re.I`
3. 型号规范化：用 `re.sub` 模块级函数 + `flags=re.I`
4. 同义词扩展：在 `synonyms.json` 中添加条目
5. 补空格：中文别名替换后，如果别名末尾接英文/数字，需 `re.sub(r'(替换结果)([A-Z0-9])', r'\1 \2', q)` 补空格
6. 验证：`source /home/hp/mkdocs-env/bin/activate && python3 -c "from rag_core import _normalize_query; print(_normalize_query('测试输入'))"`

### 已有的规范化功能（截至 2026-06-15）

| 功能 | 实现位置 | 示例 |
|------|---------|------|
| 中文别名→FANUC | `_CHINESE_ALIASES` dict | 法那科/发那科/法兰克 → FANUC |
| CR系列规范化 | `re.sub` in `_normalize_query` | CR35iA → CR-35iA |
| 型号规范化 | `re.sub` in `_normalize_query` | M900 → M-900 |
| 报警码规范化 | `re.sub` in `_normalize_query` | SRVO023 → SRVO-023 |
| 负载→型号映射 | `_expand_load_to_model` | 360 → M-900iB/360L |
| 同义词扩展 | `expand_query` + `synonyms.json` | DCS → 双检安全/safety speed |

## ⚠️ PDF 内容提取策略

### 大文件提取：pdftotext 页面范围

```bash
# 提取指定页面范围（1-indexed）
pdftotext -f 1 -l 10 "/path/to/large.PDF" - 2>/dev/null | head -100

# 全文提取 + grep 关键词
pdftotext "/path/to.PDF" - 2>/dev/null | grep -n -B2 -A8 "关键词"
```

⚠️ 全文提取大 PDF（500+页）可能超时（>30s），务必用 `-f -l` 限定页面范围。

⚠️ **PDF 文件页码 ≠ 文档印刷页码**（FANUC 手册普遍存在 1-15 页偏移）。`pdftotext -f N` 中的 N 是 PDF 文件的物理页号，不是 PDF 内部的"X / 165"印刷页号。例如小米《FANUC机器人小米标准软件使用手册_v19.pdf》文档第 61 页（印刷页 "61 / 165"）对应 PDF 文件约第 71 页。**两种解决方式**：
- 全文提取后 grep 章节标题（如 "8.3 MH Valves 配置"），用行号反推
- 先用 `pdftotext -f 1 -l 5` 看印刷页号 vs 物理页号的差值

⚠️ **不能凭"用户引用了第 X 页"就用 `-f X -l X+5` 直接抓**——大概率抓到的是上一章或下一章。先 grep 章节标题确认。

### RAG 检索 vs ripgrep

- RAG 向量库索引范围 > ripgrep 覆盖范围（向量库含 wiki 目录外的 PDF）
- ripgrep 无果不代表知识库没有，必须继续用 RAG API 查询
- 用 `retrieve()` 测试新领域的可检索性：`top_score >= 0.6` 表示有内容，`< 0.4` 表示空白

### 安全文档创建经验（2026-06-15）

创建专题文档时的跨文档一致性审查流程：
1. 每篇文档标注出处（PDF文件名+章节号）
2. 核心数据（安全等级、信号名称、报警代码）必须在所有文档中一致
3. 交叉引用使用完整文档名
4. 委托子代理做 PASS/WARN/FAIL 结构化审查
5. FAIL 项需用户确认后才能修复
6. **文档完成后必须做 PDF 交叉验证**：提取关键断言 → RAG 检索 PDF → 逐条比对

详见：📄 [references/safety-documentation-workflow.md](references/safety-documentation-workflow.md)
详见：📄 [references/cross-verification-against-pdfs.md](references/cross-verification-against-pdfs.md)

## ⚠️ 查询规范化 _normalize_query 编码陷阱（2026-06-15）

**症状**：`re.sub()` 报 `TypeError: 'flags' is an invalid keyword argument for sub()`

**根因**：`Pattern.sub()`（编译后的正则对象方法）不接受 `flags` 参数，只有模块级 `re.sub()` 才接受。

```python
# ❌ 错误 — 编译后再传 flags
_CHINESE_ALIAS_RE = re.compile("|".join(re.escape(k) for k in aliases))
q = _CHINESE_ALIAS_RE.sub(lambda m: ..., q, flags=re.I)  # TypeError!

# ✅ 正确 — 编译时加 flags
_CHINESE_ALIAS_RE = re.compile("|".join(re.escape(k) for k in aliases), re.I)
q = _CHINESE_ALIAS_RE.sub(lambda m: ..., q)  # OK
```

**规则**：需要 `flags` 时，要么用 `re.sub()` 模块函数（每次重新编译），要么在 `re.compile()` 时传入 flags。不要在 `Pattern.sub()` 上传 flags。

## ⚠️ 向量库写操作需 HF Hub 离线模式（2026-06-15）

**症状**：`chromadb.collection.add()` 报 `RuntimeError: Cannot send a request, as the client has been closed.`

**根因**：ChromaDB 的 `SentenceTransformerEmbeddingFunction` 初始化时会联网检查 `adapter_config.json`（PEFT 检测）。HF Hub 不可达时 httpx 崩溃。

**修复**：
```bash
HF_HUB_OFFLINE=1 python3 your_import_script.py
```
或在脚本内：
```python
import os
os.environ["HF_HUB_OFFLINE"] = "1"
```

## ⚠️ rag_core.py 是符号链接（2026-06-15）

`/home/hp/rag_core.py` → `/home/hp/self-grow-wiki/rag_core.py`（symlink）
`/home/hp/synonyms.json` → `/home/hp/self-grow-wiki/synonyms.json`（symlink）

**git 操作必须在 `/home/hp/self-grow-wiki/` 目录执行**，不能在 `/home/hp/`。在 `/home/hp/` 执行 `git add rag_core.py` 会把 symlink 本身加入索引（显示为 deleted file 1690 行）。

```bash
# ❌ 错误
cd /home/hp && git add rag_core.py  # 操作的是 symlink

# ✅ 正确
cd /home/hp/self-grow-wiki && git add rag_core.py  # 操作的是实际文件
```

## 安全功能专题文档（2026-06-15）

已创建3篇安全专题文档并导入向量库（21 chunks）。详见 📄 [references/safety-docs-creation.md](references/safety-docs-creation.md)。

## ⚠️ 新文档导入向量库（2026-06-15 新增）

**场景**：向 `/mnt/d/知识库wiki/` 添加新的 .md 专题文档后，需要手动导入向量库。

**导入脚本**：
```python
import os; os.environ["HF_HUB_OFFLINE"] = "1"
import chromadb, hashlib, re
from pathlib import Path
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

ef = SentenceTransformerEmbeddingFunction(
    model_name="BAAI/bge-base-zh-v1.5", device="cpu", trust_remote_code=False)
coll = chromadb.PersistentClient(path="/home/hp/rag_chromadb").get_collection("wiki_docs", embedding_function=ef)

def chunk_md(text, size=800):
    chunks, cur = [], ""
    for sec in re.split(r'\n(?=#{1,3} )', text):
        if len(cur) + len(sec) > size and cur:
            chunks.append(cur.strip()); cur = sec
        else:
            cur += "\n" + sec if cur else sec
    if cur.strip(): chunks.append(cur.strip())
    return chunks

# 对每个 md 文件：
src = "文件名.md"
text = Path(f"/mnt/d/知识库wiki/07_机器人/{src}").read_text("utf-8")
h = hashlib.md5(src.encode()).hexdigest()
chunks = chunk_md(text)
ids = [f"md_{h}_{i:03d}" for i in range(len(chunks))]
metas = [{"source": src, "filename": src, "brand": "fanuc", "category": "...", "content_type": "技术文档"} for _ in chunks]
# 删除旧的同名文档 chunks（幂等）
try:
    old = coll.get(where={"source": src})
    if old["ids"]: coll.delete(ids=old["ids"])
except: pass
coll.add(ids=ids, documents=chunks, metadatas=metas)
```

**⚠️ 必须设 HF_HUB_OFFLINE=1**：WSL 环境下 HF Hub 网络不可达会导致 httpx 崩溃，embedding function 无法初始化。

## ⚠️ BM25 缓存重建（新文档导入后必做）

**问题**：向 ChromaDB 添加新 chunks 后，BM25 缓存（pickle 文件）不含新文档，RRF 融合中新文档只出现在 BM25 一侧，分数被压到 0.500。

**重建方法**：
```python
from rag_core import _bm25_index, BM25_INDEX_PATH
BM25_INDEX_PATH.unlink(missing_ok=True)  # 删除旧缓存
_bm25_index._ensure_index()              # 从 ChromaDB 重建
# 200k chunks 耗时约 3-5 分钟（jieba 分词最慢）
```

**验证**：重建后 `_bm25_index.N` 应等于 `coll.count()`。

## ⚠️ RRF 融合对比型查询 0.500 问题（2026-06-15 发现）

**症状**：对比型查询（"A和B区别"、"X vs Y"）返回 0.500 分数，新专题文档不在 top 结果中。

**根因**：向量检索 `n_results=8`（DEFAULT_TOP_K）太小，PDF 碎片占满 top-8，新专题文档被挤出 RRF 融合。新文档在 BM25 中排 #1，但只出现在一个检索通道中：RRF = 1/(60+1) = 0.0164，归一化 = 0.500。

**影响**：对比型查询（坐标系对比、协议对比、安全信号对比）的召回率受影响。单实体查询（报警码、型号）不受影响。

**短期缓解**：新专题文档内容足够丰富，LLM 综合回答时会参考 top-5 中的文档，用户体验影响有限。

**长期方案**：
1. 调大 `DEFAULT_TOP_K` 从 8 到 16-20（有性能代价）
2. 对对比型查询走独立检索路径（`retrieve_compare()` 已存在）
3. 对新专题文档做 BM25 关键词加权

## ⚠️ 向量库写操作需 HF Hub 离线模式（2026-06-15）

新增文档（PDF/md）后 BM25 缓存失效，retrieve() 返回 0.500。
重建步骤 + md 增量导入代码 + Pattern.sub() flags 陷阱。
详见：📄 [references/bm25-rebuild-and-md-import.md](references/bm25-rebuild-and-md-import.md)

## ⚠️ 新文档导入向量库流程

当需要向 ChromaDB 增量添加新文档（md 文件）时：

完整流程见：📄 [references/new-doc-import-workflow.md](references/new-doc-import-workflow.md)

## ⚠️ 跨语言文档（英文/日文 FANUC 手册）导入

源文档主体语言 ≠ 用户查询主流语言时，必须在 recursive chunking 之外**额外插入一个手工写的双语 summary chunk**，作为该文档的语义锚点。

**真实案例**（2026-06-22）：FANUC Material Handling Option Manual MAROBHT8203131E REV C（英文，42 页扫描 PDF）入库后中文查询 "抓手物料搬运阀 输入信号 配置" 仍 0 命中。加入双语 summary chunk（抓手=gripper/Tooling、MHND 报警前缀、章节中英并列）后 → 中文短查询从 ❌ NOT IN TOP-15 跳到 #1 0.980。

**完整指南**（含手工 summary 模板、invalidation 顺序、跨语言判定规则）：📄 [references/cross-language-retrieval-fix.md](references/cross-language-retrieval-fix.md)

快速步骤：
1. 撰写文档 → `/mnt/d/知识库wiki/07_机器人/<文档名>.md`
2. 交叉验证 → `retrieve()` 验证断言 vs PDF
3. 导入向量库 → chunk + embed + add to wiki_docs
4. 重建 BM25 → `BM25_INDEX_PATH.unlink()` + `_ensure_index()`
5. Smoke test → `retrieve()` 验证命中

```python
import os; os.environ["HF_HUB_OFFLINE"] = "1"
import chromadb, hashlib, re
from pathlib import Path
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

ef = SentenceTransformerEmbeddingFunction(
    model_name="BAAI/bge-base-zh-v1.5", device="cpu", trust_remote_code=False)
coll = chromadb.PersistentClient(path="/home/hp/rag_chromadb").get_collection("wiki_docs", embedding_function=ef)

def chunk_md(text, size=800):
    chunks, cur = [], ""
    for sec in re.split(r'\n(?=#{1,3} )', text):
        if len(cur) + len(sec) > size and cur:
            chunks.append(cur.strip()); cur = sec
        else:
            cur += "\n" + sec if cur else sec
    if cur.strip(): chunks.append(cur.strip())
    return chunks

for md_path in MD_FILES:
    text = Path(md_path).read_text("utf-8")
    src = Path(md_path).name
    h = hashlib.md5(src.encode()).hexdigest()
    chunks = chunk_md(text)
    ids = [f"md_{h}_{i:03d}" for i in range(len(chunks))]
    metas = [{"source": src, "filename": src, "brand": "fanuc", ...} for _ in chunks]
    # 删除旧的同名文档chunks
    try:
        old = coll.get(where={"source": src})
        if old["ids"]: coll.delete(ids=old["ids"])
    except: pass
    coll.add(ids=ids, documents=chunks, metadatas=metas)
```

⚠️ **导入后必须重建 BM25 缓存**：新 chunks 不在旧缓存中，RRF 融合时新文档只有 BM25 分数（0.500）。删除缓存后下次查询自动重建（~150s/200k chunks）：
```python
from rag_core import _bm25_index, BM25_INDEX_PATH
BM25_INDEX_PATH.unlink(missing_ok=True)
_bm25_index._ensure_index()  # ~150s
```

⚠️ **RRF 0.500 陷阱**：新文档在 BM25 rank#1 但不在向量 top-8（PDF 碎片占满位），RRF = 1/(60+1) 归一化 = 0.500。这是结构性问题，不是文档质量问题。新文档在纯向量检索中通常 score > 0.80。

## ⚠️ AI 生成文档必须交叉验证

新增专题文档后，必须用 `retrieve()` 逐条验证关键技术断言 vs PDF 原文：
- 安全等级（类别/PL/SIL）
- 报警代码含义
- 配置路径/菜单
- 力限值/参数范围
- 信号名称（SIR/SPO/FENCE/EAS）

验证流程：提取 3-5 个关键断言 → 检索 PDF → 比对 → CONFIRMED/NEEDS REVIEW/CONTRADICTED。CONTRADICTED 的必须立即修复。

详见：📄 [references/new-doc-cross-verification.md](references/new-doc-cross-verification.md)

[出处: 2026-06-15 交叉验证发现 SRVO-002 描述错误]

## ⚠️ 查询规范化新增项（2026-06-15）

`_normalize_query()` 已扩展：
- **中文别名**：法那科/发那科/法兰克/法纳科 → FANUC（`_CHINESE_ALIAS_RE`，编译时加 `re.I`）
- **CR 系列**：CR35iA → CR-35iA（`re.sub` 模块级函数，flags 参数可用）
- **FANUC 空格补全**：FANUCM-900 → FANUC M-900

⚠️ **Pattern.sub() 不接受 flags 参数**：编译正则时必须加 `re.I`，不能在 `.sub()` 调用时传。
```python
# ✅ 正确
_CHINESE_ALIAS_RE = re.compile("...", re.I)
result = _CHINESE_ALIAS_RE.sub(replacement, text)

# ❌ 错误 — TypeError: 'flags' is an invalid keyword argument for sub()
result = re.compile("...").sub(replacement, text, flags=re.I)
```

**synonyms.json 新增 10 组**：协作机器人(cobot)、DCS(双检安全)、工具坐标系(UTOOL)、干伸长度(stick-out)、起弧(arc start)、收弧(arc end)。补全 6 组占位符（报警处理方法/设定方法区别/每日巡检/信号抖动/站点编号/高惯量）。

## ⚠️ 常见故障：hybrid_search 返回空

**症状**：所有查询返回"无法完成检索"或空列表。

**根因 1：Python .pyc 缓存**（最常见）
```bash
# 每次修改 rag_answer.py 后必须清理
rm -f ~/.hermes/scripts/__pycache__/rag_answer.cpython-*.pyc
```

**根因 2：CHROMA_PATH 错误**
```python
# ❌ 错误（hermes venv 中路径不存在）
CHROMA_PATH = os.path.expanduser("~/chroma_db_v4")

# ✅ 正确
CHROMA_PATH = "/mnt/d/Eric/知识库/chroma_db_v4"
```

**根因 3：Collection 名写错**
```python
# ❌ 旧版 edoc_v10（7015 docs）
coll = client.get_collection("wiki_docs")  # NOT "rag_docs" or "edoc_v10_m3"
print(f'count={coll.count()}')  # 应为 200736+
# ✅ edoc_v10_m3（34100 docs）
coll = client.get_collection("wiki_docs")  # NOT "rag_docs" or "edoc_v10_m3"
print(f'count={coll.count()}')  # 应为 200736+

**根因 4：hybrid_search 缩进断裂**
- `_get_tag_filter` 必须嵌套在 `hybrid_search` 函数内部（8 空格缩进）
- `hybrid_search` 函数体（4 空格缩进）包含关键词提取 → 向量检索 → RRF 合并
- 验证：`python3 -c "import rag_answer as ra; print(len(ra.hybrid_search.__code__.co_code))"` 应 >1000 字节

## ⚠️ 新增文档入库流程（增量导入 Markdown）

> 详细流程和跨文档一致性审查方法见 📄 [references/safety-document-creation-workflow.md](references/safety-document-creation-workflow.md)

向量库索引的是 PDF（通过 `rag_import_fanuc.py`），新写的 wiki 目录 md 文件不会自动被索引。手动增量导入流程：

```python
import chromadb, hashlib, re
from pathlib import Path

CHROMA_DIR = "/home/hp/rag_chromadb"
COLLECTION = "wiki_docs"

client = chromadb.PersistentClient(path=CHROMA_DIR)
coll = client.get_collection(COLLECTION)

def chunk_markdown(text, chunk_size=800):
    """按二级标题分块"""
    sections = re.split(r'\n(?=#{1,3} )', text)
    chunks, current = [], ""
    for section in sections:
        if len(current) + len(section) > chunk_size and current:
            chunks.append(current.strip())
            current = section
        else:
            current += "\n" + section if current else section
    if current.strip():
        chunks.append(current.strip())
    return chunks

for md_path in ["/mnt/d/知识库wiki/07_机器人/新文档.md"]:
    path = Path(md_path)
    text = path.read_text(encoding="utf-8")
    source = path.name
    src_hash = hashlib.md5(source.encode()).hexdigest()
    chunks = chunk_markdown(text)

    ids, docs, metas = [], [], []
    for i, chunk in enumerate(chunks):
        ids.append(f"md_{src_hash}_{i:03d}")
        docs.append(chunk)
        metas.append({"source": source, "filename": source, "brand": "fanuc", "category": "...", "subcategory": "...", "content_type": "技术文档"})

    # 删除旧的同名文档chunks
    existing = coll.get(where={"source": source})
    if existing["ids"]:
        coll.delete(ids=existing["ids"])

    coll.add(ids=ids, documents=docs, metadatas=metas)
```

导入后需重启 rag_api 进程使新数据生效。

### BM25 索引重建

向量库增量导入后，BM25 缓存不自动更新（仍含旧数据）。需手动触发重建：

```bash
# 删除旧缓存 + 重建（约 5 分钟 / 200k chunks）
rm -f /home/hp/rag_chromadb/bm25_index.pkl
source /home/hp/mkdocs-env/bin/activate && HF_HUB_OFFLINE=1 python3 -c "
from rag_core import _bm25_index
_bm25_index._ensure_index()
print(f'BM25: {len(_bm25_index.docs)} chunks')
"
```

⚠️ **Python 陷阱：`Pattern.sub()` 不接受 `flags` 参数**

```python
# ❌ 错误 — 编译后的 Pattern.sub() 没有 flags 参数
re_compiled = re.compile(pattern, re.I)
re_compiled.sub(repl, string, flags=re.I)  # TypeError!

# ✅ 正确 — 在编译时设置 flags
re_compiled = re.compile(pattern, re.I)
re_compiled.sub(repl, string)  # flags 已在编译时生效

# ✅ 模块级 re.sub() 可以用 flags
re.sub(pattern, repl, string, flags=re.I)  # 正常
```

## ⚠️ RRF 融合分数 0.500 诊断

**症状**：查询结果 top1 分数恰好为 0.500。

**根因**：文档只在 BM25 或向量其中一个排名列表中出现，另一个列表中缺失（候选数不足）。

RRF 分数 = sum(1/(k+rank_i))，k=60。理论最大值 = 2/(60+1) = 0.0328。
- 仅 BM25 rank #1：1/61 = 0.0164 → 归一化 0.0164/0.0328 = **0.500**
- 仅向量 rank #1：同上 = **0.500**
- 两边都有 rank #1：2/61 → 归一化 = **1.0**

**诊断步骤**：
```python
from rag_core import _bm25_index
bm25_results = _bm25_index.search(query, n_results=10)
# 检查目标文档是否在 BM25 top-10
# 如果在但 retrieve 返回 0.500 → 向量检索 n_results=8 太小，目标文档未进向量 top-8
```

**缓解**：向量 `n_results` 参数（当前 8）限制了 RRF 候选数。调大可让更多文档参与融合，但有性能影响。

## ⚠️ 中文别名与型号规范化（2026-06-15 新增）

`_normalize_query()` 已增强：
- 中文别名：法那科/发那科/法兰克/法纳科 → FANUC（编译时 re.I）
- CR 系列：CR35iA → CR-35iA, CR7iA → CR-7iA
- 空格补全：FANUCM-900 → FANUC M-900

⚠️ **Pattern.sub() 陷阱**：编译正则的 `.sub()` 不接受 `flags` 关键字参数。必须在 `re.compile()` 时传入 `re.I`，不能在 `.sub(re.I)` 时传。

```python
# ✅ 正确
_CHINESE_ALIAS_RE = re.compile(pattern, re.I)
_CHINESE_ALIAS_RE.sub(replacement, text)

# ❌ 错误（TypeError: 'flags' is an invalid keyword argument for sub()）
_CHINESE_ALIAS_RE = re.compile(pattern)
_CHINESE_ALIAS_RE.sub(replacement, text, flags=re.I)
```

## 文档导入与跨文档审查

新增专题文档到 RAG 知识库的完整流程。
详见：📄 [references/rag-document-import-pipeline.md](references/rag-document-import-pipeline.md)

## ⚠️ risk_tags 自动风险打标系统（2026-06-16，PR #1 合并）

`log_query()` 写入时自动调用 `infer_risk_tags()` 生成风险标签，存入 `risk_tags` 列（逗号分隔字符串）。

**9 种风险标签**：

| 标签 | 触发条件 | 含义 |
|------|---------|------|
| `no_chunks` | chunks 为空 | 检索完全失败 |
| `very_low_confidence` | top_score < 0.4 | 极低置信度 |
| `low_confidence` | top_score < 0.65 | 低置信度 |
| `no_source` | 无有效 filename | 无来源 |
| `source_scatter` | ≥5 个来源且 top_score < 0.8 | 来源过于分散 |
| `runtime_error` | status != "success" | 运行时错误 |
| `has_error_msg` | error_msg 非空 | 有错误信息 |
| `slow_query` | latency_ms ≥ 30000 | 慢查询 |
| `explicit_negative` | 查询含否定词 | 用户显式负面反馈 |
| `possible_multimodal_gap` | 查询含"图片/截图/拍照" | 可能需要多模态 |

**阈值常量**（rag_core.py）：
```python
RISK_LOW_CONFIDENCE = 0.65
RISK_VERY_LOW_CONFIDENCE = 0.4
RISK_SLOW_QUERY_MS = 30000
```

**DB 新增列**：`risk_tags TEXT`, `has_source INTEGER`, `source_count INTEGER`（带自动迁移）

## ⚠️ log_query 失败时的兜底机制（2026-06-16）

**机制**：`log_query()` 在 DB 写入失败时自动写入 `query_log_fallback.jsonl` 兜底文件，不丢失日志。

- 兜底路径：`/home/hp/rag_query_log_fallback.jsonl`
- 自动截断：超过 1000 行时保留最新 1000 行
- sqlite3 连接加 `timeout=5` 防止锁等待
- request_id：`retrieve()` 自动生成 `rq_xxxxxxxx` 短 ID 透传到日志

## ⚠️ PR 冲突分析与 GitHub 凭证处理

多个 PR 改同一文件时的冲突分析决策流程 + WSL 下 GitHub token 过期处理。
详见：📄 [references/pr-conflict-and-credential-workflow.md](references/pr-conflict-and-credential-workflow.md)

## 调试命令

```bash
# 验证集合数据量
source /home/hp/mkdocs-env/bin/activate
python3 -c "
import chromadb
coll = chromadb.PersistentClient(path='/home/hp/rag_chromadb').get_collection('wiki_docs')
print(f'count={coll.count()}')  # 应为 200736+
"

# 检查 BM25 缓存
python3 -c "
import pickle
d = pickle.load(open('/home/hp/rag_chromadb/bm25_index.pkl','rb'))
print(f'bm25.N={len(d[\"docs\"])}')  # 应为 200736+
"

# 手动触发 BM25 重建（删除缓存后首次查询自动重建，约 5 分钟）
rm -f /home/hp/rag_chromadb/bm25_index.pkl
python3 -c "from rag_core import _bm25_index; _bm25_index._ensure_index()"

# 测试检索（无 LLM，用 mkdocs-env venv）
source /home/hp/mkdocs-env/bin/activate && HF_HUB_OFFLINE=1 python3 -c "
from rag_core import retrieve
results = retrieve('SRVO-001')
print(f'results={len(results)}')
for r in results[:3]: print(f'  {r[\"source\"]} score={r[\"score\"]:.3f}')
"
```

## ⚠️ 交叉验证脚本 subprocess 陷阱

**问题**：`rag_cross_validate.py` 原来用 subprocess 调用 `rag_answer.py`，每次查询重新 warmup ~70s × 18 queries = 21min，远超 120s timeout，导致全部超时返回空结果。

**修复**：改为直接 import `rag_answer` 模块（单次 warmup）：
```python
from rag_answer import warmup, hybrid_search
warmup()  # 只做一次
# 然后循环调用 hybrid_search(query)
```

## ⚠️ tasks 表 schema 注意

> 2026-04-17 更新：`rag_cross_validate.py` 依赖 `state.db` tasks 表 schema

| 列 | 类型 |
|---|---|
| `id, created_at, updated_at, status, priority, assignee, title, description, result, source, parent_id, section` |
| **无 `tags` 列**（原来代码错误地使用了 `tags`） |
| `created_at` 和 `updated_at` 都是 `NOT NULL`，INSERT 时两个都要传 |

正确 INSERT 示例（退化任务）：
```python
now = datetime.now().timestamp()
cur.execute("""INSERT INTO tasks (id, title, status, priority, description, created_at, updated_at)
               VALUES (?, ?, 'todo', 8, ?, ?, ?)""",
    (task_id, title, json.dumps(data), now, now))
```

## ⚠️ rag_cross_validate.py subprocess 陷阱（已修复）

**问题**：原脚本用 subprocess 调用 `rag_answer.py`，每次查询重新 warmup ~70s × 17 queries = 19min，超时。

**已修复**（2026-04-17）：
- 改用直接 `import rag_answer as _ra`，单次 `warmup()`
- 清理了 `tasks` 表 schema 不匹配问题（去掉了 `tags` 列，`updated_at` 补全）



- 列：`id, created_at, updated_at, status, priority, assignee, title, description, result, source, parent_id, section`
- **无 `tags` 列**（错误地用 section 或直接去掉）
- `created_at` 和 `updated_at` 都是 `NOT NULL`，INSERT 时两个都要传
- 正确 INSERT 示例：
```python
now = datetime.now().timestamp()
cur.execute("""INSERT INTO tasks (id, title, status, priority, description, created_at, updated_at)
               VALUES (?, ?, 'todo', 8, ?, ?, ?)""",
    (task_id, title, json.dumps(data), now, now))
```

## ⚠️ BM25 缓存与新增文档不同步

新增文档导入 ChromaDB 后，BM25 缓存（`/home/hp/rag_chromadb/bm25_index.pkl`）仍是旧数据。RRF 融合时新文档只有 BM25 分数（排名 #1 → RRF 0.500），没有向量分数补充，导致最终分数被压低。

**症状**：新导入的专题文档在纯向量检索中命中良好（0.8+），但 retrieve() 返回 0.500。

**诊断**：
```python
from rag_core import _bm25_index, get_collection
coll = get_collection()
print(f"向量库: {coll.count()} chunks")
_bm25_index._ensure_index()
print(f"BM25缓存: {len(_bm25_index.docs)} chunks")
# 两者不一致 → 需要重建
```

**修复**：清除缓存后手动触发重建（约 3-5 分钟 / 200k chunks）：
```python
from rag_core import _bm25_index, BM25_INDEX_PATH
BM25_INDEX_PATH.unlink(missing_ok=True)
_bm25_index._ensure_index()  # 从 ChromaDB 重建
## ⚠️ BM25 缓存在沙箱中加载失败

`sandbox` 环境 pickle.load 会报 `Can't get attribute 'SimpleBM25'`，会自动重建缓存（无害）。

## ⚠️ BM25 缓存需手动触发重建

新增文档入向量库后，BM25 缓存（pickle）不会自动更新。下次查询时检测到 `coll.count() != cache.N` 会自动重建，但 200k+ chunks 重建耗时约 3-5 分钟。

手动触发重建：
```bash
cd /home/hp && source mkdocs-env/bin/activate && HF_HUB_OFFLINE=1 python3 -c "
from rag_core import _bm25_index, BM25_INDEX_PATH
BM25_INDEX_PATH.unlink(missing_ok=True)
_bm25_index._ensure_index()
print(f'完成: {len(_bm25_index.docs)} chunks')
"
```

⚠️ **新增文档后必须重建 BM25 缓存**，否则 RRF 融合中新文档只能拿到 BM25 分数（0.500），无法参与向量排名。

## ⚠️ RRF 融合对对比型查询的结构性限制

当 `top_k=8`（向量候选数）时，PDF 碎片可能占满 top-8，专题文档被挤出向量候选。RRF 融合只能看到 BM25 侧的新文档，最终分数被压到 0.500。

**症状**：对比型查询（"A和B区别"、"X和Y优缺点"）返回 0.500，但新专题文档在纯向量检索中排名靠前。

**根因**：向量候选 `n_results=top_k=8` 太小，语义相近的 PDF 碎片占满位置。

**缓解**：
- 长期：调大 `top_k` 或对对比型查询走独立检索路径
- 短期：0.500 不影响 LLM 回答质量（新文档仍在 top-5 结果中供 LLM 参考）
- 不需要立即修复 — 当前用户查询以单实体为主，对比型占比较低

## ⚠️ Query 向量必须 L2 归一化

```python
# ✅ 正确
vec = model(**tokenizer([text])).last_hidden_state[:, 0].float().cpu().numpy()[0]
q_emb = vec / np.linalg.norm(vec)  # 手动归一化！

# ❌ 错误
q_emb = vec  # 未归一化
```

## ⚠️ 专业术语必须溯源（硬性规则）

**用户纠正（2026-06-01）**：回答 FANUC 专业术语时，必须附上出处 PDF 文件名 + 页码/章节，引用原文关键句。"大概解释"不可接受。

**执行方式**：
1. 用 RAG 向量库查询术语，取 top-3 结果
2. 从返回的 metadata（source/filename）提取 PDF 文件名
3. 从 document 内容提取关键定义/描述原文
4. 回答格式：术语 → 定义 → 引用 `[出处: B-xxxxxCN/EN_xx.PDF, pXX]` + 原文摘录

## ⚠️ 引用三模式：硬引（严禁）/ 回指（合法降级）/ 直接引（默认）

**用户隐性偏好（2026-06-22）**：写答案时引用文档来源必须诚实。本地无原文 = 不能编造 chunk ID。本节是引用写法的标准框架。

| 模式 | 写法 | 何时用 | 用户感受 |
|------|------|--------|---------|
| **直接引** | `出处: <文件名> 第 X 节，原文: "..."`（本地 `pdftotext` 可验证） | 默认首选 | 最可信 |
| **回指** | `以 <文档名> 为准（*本地未收录，通过 <X> 转引*）` | 官方文档公认存在但本地未入库 | 诚实 + 有补救路径 |
| **硬引** | `出处: <文件名> 第 X 页`（本地根本无此文件 / 引用内容与文档不符） | **严禁** | 被抓包后整段信誉崩塌 |

**反模式**：
- ❌ 强行引用最近的 chunk 当某变量出处（chunk 内容答非所问）— 2026-06-22 群答案初版曾把 `$master_pos`（母版夹具 mastering 校准）当 MH Valves 出处，被用户纠正
- ❌ 把第三方/应用层文档当"完整性补充"塞进答案 — 用户原问未提的不该出现
- ❌ 引用小米手册的画面字段命名（"Clamp Inputs"）作为 FANUC 官方标准 — 小米的命名习惯 ≠ FANUC 官方

**完整框架 + 引用清单模板 + 反模式速查表**：📄 [references/honest-citation-taxonomy.md](references/honest-citation-taxonomy.md)

## ⚠️ 召回缺失 3 路归因法（区分检索 bug vs 内容不存在）

**常见误判**：用户说"X 重要文档为什么没命中？"，agent 倾向于"修检索"。但很多时候是**文档内容根本不含目标主题**，召回不到是正确行为。

**3 路归因法**（决定下一步动作前必做）：

| 通道 | 操作 | 期望命中数 | 不命中含义 |
|------|------|----------|----------|
| **BM25 单独检索** | `_bm25_index.search(query, n_results=20)` | 看目标文档是否在 top-20 | 不在 → 文档和查询无关键词重叠 |
| **向量单独检索** | `coll.query(query_texts=[q], n_results=20)` | 看目标文档是否在 top-20 | 不在 → 语义空间不正交 |
| **文档全文 grep** | `pdftotext <doc> \| grep <keyword>` | 看关键词覆盖 | 0 → 文档真的没这个主题 |

**真实案例**（2026-06-22）：
- 用户问"抓手物料搬运阀输入信号"，指定引用 `发那科机器人系统变量清单 V1.0.docx` + `系统变量表.pdf`
- 3 路验证：BM25 top-20 = 0 命中 / 向量 top-20 = 0~1 命中 / grep = MHND 0 / Material Handling 0 / valve 1（无关）/ S# 1（无关）
- **结论**：两份字典**根本不包含 MH Valves 内容**，召回不到是正确的，不是检索 bug
- 正确处理：答案里诚实说"反查为证，字典中无 MH Valves 直接变量"

**反模式**：
- ❌ 看到 0 召回就调 `top_k` / 调 `n_results` — 这是表象优化，不是根因修复
- ❌ 强行给最近的 chunk 加权重当"补救引用" — 答非所问，引入更多噪音
- ❌ 告诉用户"知识库应该有"但不去验证 — 浪费用户时间

**3 路全 0 命中且无法本地核验时的对策**：跨语言手册（英文 FANUC 官方文档被中文查询召回）→ 加**双语 summary chunk**。详见 `references/cross-language-retrieval-fix.md`。

## ⚠️ 引用来源优先级：默认仅引用用户原文涉及的文档层级（硬性规则）

**用户硬性规则（2026-06-22 明确）**："本问题的原文未提及小米，所以答案默认仅提供官方回答，除非原文明确问了小米 xiaomi 标准内容。"

**执行原则**：引用来源的层级必须与用户原文涉及的范围匹配。**不要主动扩展**用户未提及的层级。**判定后必须整段删除**未涉及的来源层级（不是降权，是**移除**）。

**优先级分层**：

| 优先级 | 文档类型 | 代表 | 何时使用 |
|--------|---------|------|---------|
| **P0** | FANUC 官方原厂手册 | B-83284EN-1（报警代码）、B-83124CM（MH 编程）等 | **默认** — 用户原文未指定来源时一律用此层 |
| P1 | FANUC 官方其他手册 | 同上 P0 范围的其他手册 | P0 未覆盖的子主题 |
| P2 | 第三方/集成商文档 | 小米《FANUC机器人小米标准软件使用手册》 | **仅当用户原文明确提及小米/xiaomi/集成商时** |
| P3 | 应用层功能描述 | MI03_GRP 等标准软件 | 同 P2，仅当用户原文明确涉及 |

**判定流程**：
1. 看用户原文 — 是否提及小米/xiaomi/集成商/应用层？
2. 是 → 可以引用 P2/P3 内容
3. 否 → 仅用 P0/P1 官方文档回答，不引用第三方或应用层

**反模式（用户厌恶）**：
- ❌ 答案里塞第三方/应用层内容当"补充" — 用户会觉得答案偏题
- ❌ 把第三方文档和官方文档并列引用 — 默认应该只用官方
- ❌ "为完整性"主动引入 MI03_GRP 等应用层内容
- ❌ 引用小米手册的画面字段名（如 "Clamp Inputs"）作为标准答案 — 这只是小米的命名习惯，不等于 FANUC 官方

**正确做法**：
- ✅ 用户问"抓手物料搬运阀里的输入信号配置界面" → 答案仅引用 B-83284EN-1 + B-83124CM（均 FANUC 官方）
- ✅ 用户问"小米手册里 MI03_GRP 如何监控 MH Valves" → 可以引用小米手册 + MI03_GRP
- ✅ 答案末尾加"引用文档清单"，标注每条引用的性质（P0/P1/P2/P3）

**例外**：如果 P0 文档确实无相关条目（如 MH Valves 画面字段命名官方未明确），可以在引用清单里标注 "P0 未覆盖，引用 P2 作为实施参考"，但内容上仍以 P0 为准，并明确告知用户这是非官方来源。

**出处**：本次规则明确由用户在 RAG 助手测试群（oc_1bf03d465a785da56ae541a1ce5e77fa）纠正。原答案同时引用 B-83284EN-1 + 小米手册 + MI03_GRP 被认为"偏题"——用户原问未提及小米，应用层描述不应主动出现。

完整案例（MH Valves）见：[references/fanuc-mh-valves-and-input-signals.md](references/fanuc-mh-valves-and-input-signals.md) → 第 9 节"报警码引用纪律"

## ⚠️ 答案引用审查纪律：未验证 = 不宣称错误

**陷阱**：事后审查 AI 答案中的引用时（如用户问"检查下群消息"），本地知识库查不到某 PDF **≠** 该 PDF 内容有误。可能只是未收录到本地。

**典型场景**：
- 答案引用 "B-83124CM-6/01 物料搬运说明书" 描述 MHND-236 对策。本地 wiki 目录只有 B-83284EN/CM，B-83124CM 未收录。
- 草率结论："B-83124CM-6/01 引用不准确，报警码定义在 B-83284EN-1" — 这是**过度断言**。B-83124CM 仍是 FANUC 合法手册编号，可能包含相关内容，只是本地不可核验。

**正确审查三步**：
1. **区分缺失 vs 错误**：`本地找不到文件`（未收录）vs `找到文件但内容不符`（确实有误）。前者不能下"错误"结论。
2. **多源引用不一定错**：答案同时引用 B-83284EN-1（报警定义）和 B-83124CM-6（应用功能描述）是**互补引用**，不是冗余。报警代码定义在 EN 系列，应用场景描述在 CM 系列。
3. **本地能核验的部分优先标"已验证"，不能核验的标"未本地验证"**：
   - ✅ "B-83284EN-1_08_01.PDF 包含 MHND-236/237 完整定义（已 grep 验证）"
   - ⚠️ "B-83124CM-6/01 未收录到本地 wiki,引用合理性无法本地核验"

**审查话术模板**：
> "答案中 [文档A] 引用已通过本地 PDF grep 验证；[文档B] 引用本地未收录,但作为 FANUC 标准手册编号在工业实践中常见,建议保留但标注'未本地核验'。"

**反模式（用户厌恶）**：
- ❌ 在群里宣称"你引用的文档不存在/错误"——会被挑刺
- ❌ 反复用"可能是错的"措辞——降低可信度
- ❌ 把"未收录"等同于"错误"

## 中文术语检索策略

用户用中文提问时，FANUC 手册原文术语可能与口语不同。直接搜口语表达常返回无关结果（弧焊 vs 圆弧追踪）。

**策略：多轮变体查询，不要只试一次。**

| 用户口语 | FANUC 手册实际用词 | 说明 |
|---------|-------------------|------|
| 圆弧跟踪 | 圆弧追踪、跟踪类型、传送带设定 | 传送带拾取场景 |
| 焊缝跟踪 | TAST、seam tracking、电弧传感 | 焊缝跟踪传感器 |
| 弧焊 | Arc Tool、弧焊功能、焊接数据 | B-83284CM-3 手册 |
| **报警代码** | **SRVO-xxx、报警代码、报警报警一览** | **报警诊断手册** |
| **主板报警代码 X** | **seven segment LED main board alarm（英文检索 score=0.980，中文仅 0.580）** | **book.pdf (B-82285EN-2/02)，七段 LED 码 0-7，非 TP 报警** |
| **型号简称** | **360→M-710iC/50, 700→M-710iC/70, 120→ARC Mate 120iD, 2000→R-2000iC, 900→M-900iA** | 用户常用负载数或简写代号称呼机器人 |
| **3DV** | **3DV/400, 3DV/600, 3D视觉传感器** | FANUC 3D Vision Sensor, B-83914CM 系列手册 |
| **Cobot** | **协同作业机器人**（非"协作机器人"） | FANUC 官方中文名, B-83744CM_01.PDF |
| **DCS 密码** | 主代码编号、DCS 密码设置画面 | DCS 安全功能密码，非用户登录密码 |
| **安全密码** | 主代码编号、项目密码（基准/位置速度检查/I/O连接） | DCS 分两级密码，详见 `references/fanuc-dcs-procedures.md` |
| **PRIO-378** | **待 PDF 确认**（可能是 PROFINET 连接失败，非安全 I/O 参数不一致） | 直查 B-82864EN_05.PDF 确认，详见 SKILL.md PRIO 报警表 | `references/fanuc-alarm-code-pdf-mapping.md` |
| **Solution Arm** | Primary Axis Solution Arm Package — GM Body Shop 主轴解决方案臂组件包（线缆+配置方案） | 来源: GM global 1 R-30iA Controller addendum.pdf (07_机器人/FANUC手册)。ripgrep 搜不到，只有 RAG 语义检索命中。适用: R-2000iB, M-710iC, ARC Mate, M-6iB, M-16iB, F-200iB |
| **1A05B-2600-XXXX** | FANUC 控制器选件号 | H=硬件, J=软件, R=机器人/附加轴，详见 `references/fanuc-option-code-catalog.md` |
| **全备份/镜像备份** | 文件级备份 vs FROM/SRAM 全盘备份 | 镜像恢复后必做零点标定，详见 `references/fanuc-backup-and-restore.md` |
| **270F vs 270R / XXF vs XXR** | F=地面安装, R=高台安装，不同机型不同结构 | RAG 语义搜索对变体对比失效，**必须直查 PDF 规格表**，详见 `references/fanuc-model-naming-and-comparison.md` |
| **清洗型/防水型** | 洗净仕様、防滴仕様、防水仕様、washproof | 保养周期与常规型不同，**不能套用常规型数据**，需查清洗型专用维修手册。详见 `references/fanuc-model-naming-and-comparison.md` |
| **法那科/发那科/法兰克** | FANUC | 中文别名，`_normalize_query` 已自动映射（2026-06-15） |
| **CR35iA/CR7iA** | CR-35iA/CR-7iA | CR 系列无连字符写法，`_normalize_query` 已自动规范化 |
| **清洗型/防水型** | 洗净仕様、防滴仕様、防水仕様、washproof | 保养周期与常规型不同，**不能套用常规型数据**，需查清洗型专用维修手册。详见 `references/fanuc-model-naming-and-comparison.md` |

**查询顺序：**
1. 先用用户原话查询
2. 若 top-3 相关度 < 0.55 或明显偏题，换 FANUC 手册术语重查
3. 若仍无结果，用更宽泛的上位概念（如"传送带"替代"圆弧跟踪"）

## ⚠️ 零结果查询策略 — 问两次才挖到的教训

**触发**：RAG 检索返回 0 结果或 top-3 相关度全部 < 0.3。

**规则：用户重复同一查询（一字不改）= 信号"继续挖，别问我"。** 绝对不要在用户重复后再次要求补充说明。

**搜索层次（按顺序执行，每层都无结果才进下一层）：**

| 层次 | 动作 | 说明 |
|------|------|------|
| 1 | 用户原词 RAG 查询 | 默认起点。**RAG API 覆盖范围 > ripgrep 覆盖范围**（向量库含 wiki 目录外的 PDF），必须先试 |
| 2 | 拆词/变体查询 | "SOLUTION ARM" → "solution arm" 分词查询、"solution" 单独查、"arm" 单独查 |
| 3 | FANUC 手册术语映射 | 用上表「型号简称」映射（如 "360"→"M-710iC/50"），反向查找是否有对应型号 |
| 4 | `search_files` 全文检索 | 在 `rag_data/extracted/*.json` 中 grep 原词和变体，绕过向量语义。⚠️ 覆盖范围 < RAG 向量库，ripgrep 无果不代表知识库没有 |
| 5 | PDF 文件名/目录扫描 | `find /mnt/d/知识库wiki -name "*.pdf" \| grep -i <keyword>`，检查是否有未索引的文档 |
| 6 | Web 搜索兜底 | 用 `web_search` 查 "FANUC <term>" 或 "<term> 机器人"，确认术语是否真实存在 |
| 7 | 请求澄清（最后手段） | 只有在以上全部无果后才问用户，并明确说明"已尝试 X/Y/Z，确认知识库和网络均无匹配" |

**输出要求**：请求澄清时必须附带已尝试的搜索路径摘要，不能只说"没找到"。例如：
> "知识库向量检索 + 全文 grep + Web 搜索均无 'SOLUTION ARM' 匹配。
> 已尝试：原词查询、拆词查询、FANUC 型号映射、PDF 文件名扫描。
> 请补充：这是 FANUC 标准型号还是项目自定义名称？"

**反模式（严禁）：**
- ❌ 用户重复后再次问同样的澄清问题
- ❌ 只做一次向量搜索就放弃
- ❌ 不说明已尝试的搜索路径就问"请补充信息"

## 使用场景

当用户问 FANUC 机器人相关问题时，自动调用 `rag_answer.py`，把返回的 Top-3 文档片段作为上下文传给 LLM 综合回答。

## ⚠️ 专题文档已入库（2026-06-15，37 chunks）

7 篇安全/工艺/通信/坐标系专题文档已导入向量库（200,715→200,752）。覆盖此前知识库空白领域（协作机器人/安全功能/焊接缺陷/坐标系对比/通信协议）。

⚠️ **新文档入库前必须交叉验证** — 见上方「专题文档交叉验证」章节。

## ⚠️ 查询规范化增强（2026-06-15 新增）

**_normalize_query() 新增 3 项**：
- 中文别名：法那科/发那科/法兰克/法纳科 → FANUC（编译时加 `re.I`，注意 `Pattern.sub()` 不接受 `flags` 参数）
- CR 系列：CR35iA → CR-35iA（正则 `CR(\d{1,2})(i[A-Z]?)`）
- 空格补全：FANUCM-900 → FANUC M-900（`(FANUC)([A-Z0-9])` → `\1 \2`）

**⚠️ Pattern.sub() 陷阱**：编译后的正则 `.sub()` 不接受 `flags` 关键字参数，`re.sub()` 才接受。必须在 `re.compile()` 时加 `re.I`，不能在 `.sub()` 时加。

**synonyms.json 新增 10 组 + 补全 6 组占位符**：
- 新增：协作机器人/DCS/工具坐标系/干伸长度/起弧/收弧
- 补全：报警处理方法/设定方法区别/每日巡检/信号抖动滤波/站点编号波特率/高惯量模式

## ⚠️ 安全功能专题文档（2026-06-15）

7 篇专题文档已导入向量库（+37 chunks）：
- FANUC安全信号体系.md — FENCE/EAS/DCS/E-Stop/Collision Guard
- FANUC碰撞检测功能.md — 灵敏度/COL GUARD ADJUST
- FANUC_DCS安全功能配置.md — 密码/安全领域/速度检查
- FANUC协同作业机器人CR系列.md — 碰触停止/退避/负载切换
- FANUC焊接参数与缺陷关系.md — 参数-缺陷矩阵
- FANUC坐标系对比与应用.md — 5种坐标系
- FANUC工业通信协议对比.md — CC-Link/EtherNet-IP/PROFINET

**交叉验证流程**：28 项断言 vs PDF 原文 → 19 确认 / 8 待查 / 1 修复（SRVO-002 描述错误）。新文档必须与 PDF 原文交叉验证，不允许未验证断言进入生产知识库。

## ⚠️ log_query 错误降级（2026-06-18）

- DB 写入失败时自动写入 `query_log_fallback.jsonl` 兜底
- 兜底文件最大 1000 行自动截断
- `sqlite3.connect(timeout=5)` 防锁等待
- `request_id` (rq_xxxxxxxx) 自动透传到日志

## ⚠️ 专题文档交叉验证（2026-06-15 新增）

AI 生成的专题文档（如安全功能/焊接参数/坐标系对比）在入库前**必须与 PDF 原文交叉验证**。2026-06-15 首次执行：28 项断言 → 19 确认 / 8 待查 / 1 修复（SRVO-002 描述错误）。

**流程：** 提取文档中的关键技术断言（安全等级、信号名、报警码、配置路径、力限值）→ RAG 检索 PDF 原文 → 逐条比对 → 标记 CONFIRMED / NEEDS REVIEW / CONTRADICTED → 修复矛盾项。

详见：📄 [references/cross-verification-pattern.md](references/cross-verification-pattern.md)

## 安全/工艺专题文档（2026-06-15 新增）

当用户问安全功能、坐标系、通信协议、协作机器人、焊接参数相关问题时，除了 RAG 检索外，还应参考以下专题文档（已在向量库中）：

| 文档 | 内容 | 对应查询关键词 |
|------|------|-------------|
| FANUC安全信号体系.md | FENCE/EAS/DCS/E-Stop/Collision Guard 对比 | 安全信号、FENCE、SAFE、急停 |
| FANUC碰撞检测功能.md | 灵敏度设定/COL GUARD ADJUST/注意事项 | 碰撞检测、Collision Guard |
| FANUC_DCS安全功能配置.md | 密码/安全领域/速度检查/恢复操作 | DCS、安全速度、安全区域 |
| FANUC协同作业机器人CR系列.md | 碰触停止/退避动作/负载切换 | CR-35iA、协作机器人、碰触停止 |
| FANUC焊接参数与缺陷关系.md | 参数-缺陷矩阵/故障排查 | 焊接缺陷、气孔、飞溅、干伸长度 |
| FANUC坐标系对比与应用.md | 5种坐标系对比/设定方法 | 坐标系、UFrame、UTool、直角/关节 |
| FANUC工业通信协议对比.md | CC-Link/EtherNet-IP/PROFINET | 通信协议、CC-Link、PROFINET |

⚠️ 交叉验证发现：SRVO-002 是"示教器紧急停止"（非"安全门打开"）。回答报警码时必须对照 PDF 原文。

## ⚠️ RAG 优化工作流（2026-06-15）

补全新专题文档的标准流程：
1. `retrieve()` 定位低分查询（score < 0.6）
2. `pdftotext` 从对应 PDF 提取原文
3. 撰写专题 markdown，标注出处 PDF + 章节
4. 跨文档一致性审查（delegate_task 验证 28 项断言 vs PDF）
5. 增量导入向量库（chromadb + SentenceTransformerEmbeddingFunction, HF_HUB_OFFLINE=1）
6. 重建 BM25 缓存（`BM25_INDEX_PATH.unlink()` + `_bm25_index._ensure_index()`）
7. smoke test 验证命中率

⚠️ BM25 缓存不自动包含新增 chunks，必须手动重建。

## 巡检题库管理（2026-06-14）

题库 JSON 路径：`/mnt/c/Users/hp/Desktop/自研/rag-docs/RAG巡检题库_200题_20260508.json`
daily_audit.py 从此文件加载，每天抽 7 题（L2: 2-3 + L3: 4-5），30 天不重复。

更新流程：MD 提取 → 候选题合并 → 知识库验证生成 → 去重(相似度>60%) → Tag 合并 → 关键词补充 → 写入 JSON → 同步 questions_200.json

详见：📄 [references/question-bank-management.md](references/question-bank-management.md)

⚠️ 测试用例设计：`must_contain_any` 关键词必须在知识库中存在（版本号/固件号等极细粒度信息不适合做关键词）；对比型问题 `min_top_score` 应设低（0.45）；知识库空白领域（CNC/激光切割/协作机器人）不要加入题库。

## ⚠️ DCS 密码问题：更改 vs 重置 — 严禁混淆

**用户纠正记录（2026-05-28）**：用户问"更改 DCS 密码"，agent 返回了"忘记密码的强制解除流程"（需联系 FANUC），操作完全不对。

**区分规则**：
- "更改/修改/换 DCS 密码" → **知道旧密码，正常更改流程**（DCS 密码设置画面 → 输入旧码 → 输入新码 → 应用 → 电源循环）
- "忘记/不知道/丢了 DCS 密码" → **强制解除流程**（需 FANUC 服务部门提供 12 位解除键）
- DCS 密码 ≠ 机器人用户登录密码。DCS 只有「主代码编号」和「项目密码」，没有"用户密码"概念

**根因**：RAG 向量库未索引 B-83184（DCS 手册），agent 用通用知识回答时混淆了"更改"和"重置"。**遇到 DCS 问题必须直查 PDF。**

## ⚠️ 增量导入新文档到向量库

新文档（md 文件）需要手动导入 ChromaDB，不会自动索引。

```python
import chromadb, hashlib, re
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

ef = SentenceTransformerEmbeddingFunction(
    model_name="BAAI/bge-base-zh-v1.5", device="cpu", trust_remote_code=False)
coll = chromadb.PersistentClient(path="/home/hp/rag_chromadb").get_collection("wiki_docs", embedding_function=ef)

def chunk_md(text, size=800):
    chunks, cur = [], ""
    for sec in re.split(r'\n(?=#{1,3} )', text):
        if len(cur) + len(sec) > size and cur: chunks.append(cur.strip()); cur = sec
        else: cur += "\n" + sec if cur else sec
    if cur.strip(): chunks.append(cur.strip())
    return chunks

# 导入
text = Path("doc.md").read_text("utf-8")
src = "doc.md"
h = hashlib.md5(src.encode()).hexdigest()
chunks = chunk_md(text)
ids = [f"md_{h}_{i:03d}" for i in range(len(chunks))]
metas = [{"source": src, "filename": src, "brand": "fanuc", "category": "...", "content_type": "技术文档"} for _ in chunks]
# 删除旧的同名文档
try:
    old = coll.get(where={"source": src})
    if old["ids"]: coll.delete(ids=old["ids"])
except: pass
coll.add(ids=ids, documents=chunks, metadatas=metas)
```

⚠️ **导入后必须重建 BM25 缓存**：新 chunks 不在旧缓存中，RRF 融合会把新文档分数压到 0.500（只有 BM25 命中，向量 top-8 没命中）。

```python
from rag_core import _bm25_index, BM25_INDEX_PATH
BM25_INDEX_PATH.unlink(missing_ok=True)
_bm25_index._ensure_index()  # 重建，约 2-5 分钟
```

## ⚠️ RRF 融合 + 向量候选数不足

对比型查询（"A 和 B 区别"）在 RRF 融合下，新文档容易被压到 0.500。根因：
- 向量检索 `n_results=8`（top_k=8），PDF 碎片占满 top-8
- 新专题文档只在 BM25 排 #1，RRF = 1/(60+1) = 0.0164，归一化 = 0.500

**不影响实际用户体验**：LLM 回答时参考 top-5 结果，新文档在 top-5 内。但 smoke test 会显示 0.500。

## ⚠️ 新文档交叉验证（anti-pollution）

AI 生成的专题文档必须与 PDF 原文交叉验证，防止噪音污染知识库。

流程：
1. 从新文档提取 3-5 个关键断言（数字、信号名、安全等级、报警码）
2. 用 `retrieve()` 搜索 PDF 原文
3. 逐条比对：CONFIRMED / NEEDS REVIEW / CONTRADICTED
4. CONTRADICTED 的必须立即修复

典型错误：SRVO-002 原标注为"安全门打开"，PDF 确认为"示教器紧急停止"。安全报警码标错会导致危险误诊。

## ⚠️ RAG 巡检题库维护（JSON/MD/候选题合并、关键词补充、badcase_pending 审查）

详见：📄 [references/audit-question-bank-maintenance.md](references/audit-question-bank-maintenance.md)

## 巡检题库维护

题库 JSON 格式、新增流程、去重规则、daily_audit 集成。
详见：📄 [references/question-bank-maintenance.md](references/question-bank-maintenance.md)

## ⚠️ 每日巡检 (daily_audit.py) 基础设施陷阱

> 2026-06-05 踩坑：巡检 8/8 全部失败但 overall_pass=true，飞书推送显示"通过"

### 陷阱 1：httpx "client has been closed" 全部题目异常

**症状**：巡检所有题目报 `retrieve异常: Cannot send a request, as the client has been closed.`

**根因 A（2026-06-05 确认）：HuggingFace Hub 网络不可达**

`SentenceTransformerEmbeddingFunction` 加载 BGE 模型时，即使模型已缓存在本地，`transformers` 仍会联网检查 `adapter_config.json`（PEFT 适配器检测）。当 HF Hub 不可达时（WSL 网络/代理问题），httpx 客户端在重试中被关闭，抛出 `RuntimeError: Cannot send a request, as the client has been closed.`。**rag_api 启动即崩溃**，所有查询全部失败。

**关键区分**：这不是"API 进程重启期间的瞬态错误"，而是**进程根本无法启动**。每次重启都会复现。

**诊断**：
```bash
# 1. API 进程是否存活（如果 HF Hub 不可达，进程根本起不来）
ps aux | grep rag_api | grep -v grep
# 2. 检查启动日志是否有 httpx 错误
tail -30 /tmp/rag_api.log | grep -i "client.*closed\|httpx\|RuntimeError"
# 3. 测试 HF Hub 连通性
curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 https://huggingface.co
# 000 = 不可达，200 = 正常
# 4. 验证模型是否已缓存
python3 -c "from huggingface_hub import try_to_load_from_cache; print(try_to_load_from_cache('BAAI/bge-base-zh-v1.5', 'config.json'))"
# 返回路径 = 已缓存，返回 None = 未缓存（需联网下载）
```

**修复（rag_core.py get_collection()）**：
```python
# 在 SentenceTransformerEmbeddingFunction 调用前加：
os.environ.setdefault("HF_HUB_OFFLINE", "1")
ef = SentenceTransformerEmbeddingFunction(
    model_name=EMBEDDING_MODEL,
    device=device,
    trust_remote_code=False,
    local_files_only=True,   # 跳过 HF Hub adapter_config 检查
)
```

**验证**：
```bash
# 杀旧进程 → 用 mkdocs-env venv 重启
pkill -f rag_api.py
source /home/hp/mkdocs-env/bin/activate
cd /home/hp && CUDA_VISIBLE_DEVICES="" python3 rag_api.py &>/tmp/rag_api.log &
sleep 15 && curl -s http://localhost:8002/status | python3 -m json.tool
# channels[].alive 应全部为 true
```

**根因 B（已存在）：API 进程重启期间的瞬态错误**

如果 API 进程在巡检运行期间被重启（如 cron 或手动），httpx 连接池被关闭导致当次请求失败。这种情况是瞬态的，重跑巡检即可。

**诊断**：同上，但进程存活且日志显示正常启动。

**修复**：确认 API 已稳定运行后重跑巡检。长期方案：在 `call_rag()` 中加重试逻辑（指数退避 2s→4s→8s）。

### 陷阱 2：overall_pass 逻辑缺陷 — 0/0 被标记为"通过"

**症状**：`audit_YYYY-MM-DD.json` 中 `total_queries: 0, passed: 0, overall_pass: true`

**根因**：当所有题目因基础设施异常无法评估时，`pass_rate` 为 `0/0`。代码将"无失败"等同于"通过"，但实际应该是"无法评估"。

**正确行为**：`total_queries == 0` 时 `overall_pass` 应为 `false`。

**修复位置**：`daily_audit.py` 约 line 350 附近的 overall_pass 计算逻辑：
```python
# ❌ 当前逻辑（有缺陷）
overall_pass = failed == 0  # 0/0 时 failed=0，误判为 pass

# ✅ 正确逻辑
overall_pass = total_queries > 0 and failed == 0
```

### 陷阱 3：基础设施异常导致 badcase_pending.jsonl 堆积

**症状**：pending 队列中大量条目 fail_reason 为基础设施错误（`client closed`、`No module named 'chromadb'`、`libcublasLt not found`），不是真实的检索质量问题。

**影响**：2026-06-05 时积压 86 条 pending，其中约 60+ 是基础设施异常导致的噪声。

**处理**：用 `badcase_review.py` 批量拒绝基础设施异常条目：
```bash
python3 /home/hp/badcase_review.py --auto-reject-infra-errors
```
或手动过滤：`fail_reason` 包含 `client closed`、`No module named`、`libcublasLt` 的条目直接 reject。

**完整分类与处理流程**：详见 📄 [references/badcase-triage-workflow.md](references/badcase-triage-workflow.md) — 6 类 badcase 分类标准、环境异常批量清理脚本、报警代码检索验证方法、分类报告模板。

### 诊断检查清单

巡检异常时，按此顺序排查：

1. `curl -s http://localhost:8002/health` — API 进程是否存活
2. `tail -5 /tmp/rag_api.log` — 最近启动/重启时间
3. `grep "401\|Invalid API Key" /tmp/rag_api.log` — LLM 通道是否正常
4. 实际发一个查询测试 — 确认检索功能是否正常
5. 检查 `audit_report.json` 的 `total_queries` — 0/0 表示基础设施问题

详见：📄 [references/daily-audit-troubleshooting.md](references/daily-audit-troubleshooting.md)

## ⚠️ RRF 融合结构性问题：新文档分数 0.500

**症状**：新增专题文档在纯向量检索和 BM25 独立检索中都命中，但 `retrieve()` 返回 0.500。

**根因**：RRF 融合需要文档同时出现在向量和 BM25 两个通道才能获得 >0.500 分数。当向量候选 `n_results=top_k=8` 太小时，PDF 碎片占满 top-8，新文档被挤出向量通道，只剩 BM25 单通道分数：`1/(60+1) / (2/61) = 0.500`。

**诊断**：
```python
# 纯向量检索确认新文档是否在 top-20
results = coll.query(query_texts=[q], n_results=20, include=["metadatas", "distances"])
# BM25 独立检索确认
bm25_results = _bm25_index.search(q, n_results=10)
```

**影响**：新文档在 top-5 结果中（LLM 可参考），但 RRF 分数显示 0.500。不影响用户体验，影响巡检评分。

**长期方案**：调大 `top_k` 或对对比型查询走独立检索路径。当前 `DEFAULT_TOP_K=8` 对单实体查询足够，对比型查询天然需要更多候选。

## ⚠️ BM25 缓存与向量库不同步

**症状**：新增文档导入 ChromaDB 后，BM25 搜索不包含新文档。

**根因**：BM25 缓存 `/home/hp/rag_chromadb/bm25_index.pkl` 是持久化快照，新增 chunks 不会自动触发重建。缓存中的 chunk 数量与向量库不一致。

**诊断**：
```python
# 对比缓存 vs 向量库
import chromadb
coll = chromadb.PersistentClient(path='/home/hp/rag_chromadb').get_collection('wiki_docs')
print(f'vector: {coll.count()}')  # 应为最新值
# BM25 缓存加载后 print(len(_bm25_index.docs))
```

**修复**：删除缓存文件强制重建（约 3-5 分钟）：
```bash
rm -f /home/hp/rag_chromadb/bm25_index.pkl
# 下次查询自动重建，或手动触发：
python3 -c "from rag_core import _bm25_index; _bm25_index._ensure_index()"
```

**注意**：重建需加载 200k+ chunks 到内存并 jieba 分词，耗时 150-300 秒。

## 专题文档（2026-06-15 新增，已入向量库）

## ⚠️ BM25 缓存与向量库不同步

| 文档 | 路径 | 内容 |
|------|------|------|
| 安全信号体系 | `/mnt/d/知识库wiki/07_机器人/FANUC安全信号体系.md` | FENCE/EAS/DCS/E-Stop/Collision Guard 对比 |
| 碰撞检测 | `/mnt/d/知识库wiki/07_机器人/FANUC碰撞检测功能.md` | 灵敏度设定/COL GUARD ADJUST |
| DCS 配置 | `/mnt/d/知识库wiki/07_机器人/FANUC_DCS安全功能配置.md` | 密码/安全领域/速度检查/恢复操作 |
| CR 协作机器人 | `/mnt/d/知识库wiki/07_机器人/FANUC协同作业机器人CR系列.md` | 碰触停止/退避/负载切换 |
| 焊接参数缺陷 | `/mnt/d/知识库wiki/07_机器人/FANUC焊接参数与缺陷关系.md` | 参数-缺陷矩阵 |
| 坐标系对比 | `/mnt/d/知识库wiki/07_机器人/FANUC坐标系对比与应用.md` | 5种坐标系对比 |
| 通信协议对比 | `/mnt/d/知识库wiki/07_机器人/FANUC工业通信协议对比.md` | CC-Link/EtherNet-IP/PROFINET |

⚠️ **重要**：新增专题文档后必须（1）导入向量库（2）删除 BM25 缓存强制重建（3）运行交叉验证。

## ⚠️ 专题文档交叉验证流程

**规则**：新生成的专题文档必须与 PDF 原文交叉验证，防止 AI 生成噪音污染知识库。

**流程**：
1. 提取文档中 3-5 个关键技术断言（安全等级、报警码、信号名、配置路径）
2. 对每个断言用 `retrieve()` 搜索 PDF 原文
3. 比对结果：✅ CONFIRMED / ⚠️ NEEDS REVIEW / ❌ CONTRADICTED
4. CONTRADICTED 的断言必须修复后再入库

**实际案例**（2026-06-15）：28 项断言验证 → 19 确认 / 8 待查 / 1 修复（SRVO-002 描述错误）

## ⚠️ 巡检失败诊断：测试用例设计 vs 检索质量

巡检报告出现失败项时，**先区分是测试用例设计问题还是真实检索退化**，不要盲目优化检索。

**诊断流程**：复现检索 → 拆分关键词单独搜 → 检查关键词是否在知识库中存在 → 判定根因。

**典型案例**：V2-044 `"FANUC机器人高惯量模式V7.30P"` — "高惯量模式"单独搜 0.968 分（优秀），但 "V7.30P" 全库 0 命中（固件版本号不在任何文档中），组合查询被稀释到 0.500。根因是测试用例期望了不存在的关键词，不是检索退化。

详见：📄 [references/rag-quality-analysis.md](references/rag-quality-analysis.md)
