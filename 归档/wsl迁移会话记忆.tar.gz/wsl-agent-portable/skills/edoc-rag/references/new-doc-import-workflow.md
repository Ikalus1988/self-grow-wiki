# 新文档增量导入向量库流程

## 完整流程（2026-06-15 建立）

### 1. 撰写文档
写入 `/mnt/d/知识库wiki/07_机器人/<文档名>.md`

### 2. 交叉验证
用 `retrieve()` 验证关键技术断言 vs PDF 原文（见 `new-doc-cross-verification.md`）

### 3. 导入向量库
```python
import os; os.environ["HF_HUB_OFFLINE"] = "1"
import chromadb, hashlib, re
from pathlib import Path
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

ef = SentenceTransformerEmbeddingFunction(
    model_name="BAAI/bge-base-zh-v1.5", device="cpu", trust_remote_code=False)
coll = chromadb.PersistentClient(path="/home/hp/rag_chromadb").get_collection("wiki_docs", embedding_function=ef)

def chunk_md(text, size=800):
    chunks, cur = [], ""
    for sec in re.split(r'\n(?=#{1,3} )', text):
        if len(cur) + len(sec) > size and cur:
            chunks.append(cur.strip()); cur = sec
        else:
            cur += "\n" + sec if cur else sec
    if cur.strip(): chunks.append(cur.strip())
    return chunks

for md_path in MD_FILES:
    text = Path(md_path).read_text("utf-8")
    src = Path(md_path).name
    h = hashlib.md5(src.encode()).hexdigest()
    chunks = chunk_md(text)
    ids = [f"md_{h}_{i:03d}" for i in range(len(chunks))]
    metas = [{"source": src, "filename": src, "brand": "fanuc", "category": "...", "subcategory": "...", "content_type": "技术文档"} for _ in chunks]
    try:
        old = coll.get(where={"source": src})
        if old["ids"]: coll.delete(ids=old["ids"])
    except: pass
    coll.add(ids=ids, documents=chunks, metadatas=metas)
    print(f"{src}: {len(chunks)} chunks")
```

### 4. 重建 BM25 缓存
```python
from rag_core import _bm25_index, BM25_INDEX_PATH
BM25_INDEX_PATH.unlink(missing_ok=True)
_bm25_index._ensure_index()  # ~150s for 200k chunks
```

### 5. Smoke test
```python
from rag_core import retrieve
for q in test_queries:
    r = retrieve(q, top_k=3)[0]
    print(f'{r["score"]:.3f} | {r.get("source","?")} | {q[:30]}')
```

## 陷阱

1. **HF_HUB_OFFLINE=1 必须设置**：否则 transformers 联网检查 adapter_config.json 导致 httpx 崩溃
2. **BM25 缓存必须重建**：新 chunks 不在旧缓存中，RRF 融合只有 BM25 分数（0.500）
3. **RRF 0.500 不是质量问题**：新文档在纯向量检索中通常 score > 0.80，只是被 RRF 融合结构压低
4. **collection 名是 wiki_docs**：不是 rag_docs（skill 旧版本写的 rag_docs 已过时）
