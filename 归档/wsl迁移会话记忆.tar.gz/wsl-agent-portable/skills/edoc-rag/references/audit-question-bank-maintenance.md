# RAG 巡检题库维护指南

> daily_audit.py 每天抽 8 题巡检，题库是检索质量的核心基础设施。

## 文件路径与加载链

```
_RAG_DOCS = /mnt/c/Users/hp/Desktop/自研/rag-docs/
题库 JSON: _RAG_DOCS / "RAG巡检题库_200题_20260508.json"
备选路径: /home/hp/daily_audit.py 同目录下同名文件
同步副本: /home/hp/audit_reports/questions_200.json  (daily_audit 不读这个，仅供手动查看)
```

**⚠️ daily_audit.py 只从 `_RAG_DOCS` 加载 JSON，不读 questions_200.json。** 更新题库后必须写入 `_RAG_DOCS` 路径。

## JSON 格式

```json
[
  {
    "id": "L2-011",           // L2=跨文档, L3=高难度, C-=候选题
    "level": "L2",
    "tag": "弧焊调试",         // 分类标签
    "query": "CO2 焊接和 MAG 焊接在起弧参数设定上有什么区别？",
    "expect": {
      "must_contain_any": ["CO2", "MAG", "起弧", "参数", "焊接"],
      "min_top_score": 0.5
    }
  }
]
```

**必填字段**: id, level, tag, query, expect.must_contain_any, expect.min_top_score

## 分层抽样机制

- 每天 8 题：L1(2) + L2(3) + L3(3)
- 30 天内尽量不重复，题库耗尽时自动轮换
- 题目来源：题库 JSON + badcase_pending.jsonl 合并

## 题库更新流程

### 1. 从 MD 提取（表格格式）

MD 题库用 `| ID | 类型 | 查询 | must_contain_any | min_score |` 表格格式。
解析时注意：`split('|')[1:-1]` 去首尾空列，跳过表头和分隔行。

### 2. 合并候选题

候选题文件：`candidate_questions_YYYY-MM-DD.md`，格式为 3 列表格 `| # | 类型 | 查询 |`。
**⚠️ 候选题没有 must_contain_any 列**，合并后必须补充关键词。

### 3. 关键词自动提取

候选题和新生成的题需要自动提取关键词：
1. 型号名/代码：`[A-Z]{1,5}[- ]?\d{2,4}` 正则
2. 报警代码：`(SRVO|SYST|MATE|PRIO|MEMO|SPOT)-\d{2,3}`
3. 中文技术词：2-4 字，排除停用词（的/了/在/和/是/有/什么/怎么/如何...）
4. 英文技术词：`[A-Z][A-Za-z]{2,}`，排除 FANUC/TP/TCP

### 4. Tag 合并

容易出现的重复 tag，合并映射：
- "选型推荐" → "选型"
- "IO通信" → "IO故障"
- "操作步骤" → "操作"

### 5. badcase_pending 队列

路径：`/home/hp/audit_reports/badcase_pending.jsonl`

每行一个 JSON，格式：
```json
{"id": "BC-M-044", "query": "...", "fail_reason": "...", "top_score": 0.5,
 "proposal": {"action": "new_test", "level": "L1", "tag": "...",
   "expect": {"must_contain_any": [...], "min_top_score": 0.45}},
 "status": "pending"}
```

daily_audit.py 会将 pending 状态的条目合并进抽样池（显示为 V2-xxx ID）。

**⚠️ pending 队列可能含不现实的关键词**（如 "V7.30P" 在知识库中不存在）。
定期审查 pending 条目的 must_contain_any 是否在知识库中有对应内容。

## 常见陷阱

| 陷阱 | 说明 | 修复 |
|------|------|------|
| 文件名 200 题但实际 40 题 | JSON 只有 L2，L3 从未转 JSON | 从 MD 提取 L3 + 生成缺失分类 |
| 候选题无关键词 | 3 列表格格式无 must_contain_any 列 | 合并后自动提取 |
| 不现实的关键词 | 知识库中不存在的固件版本号等 | 搜知识库验证后修正 |
| daily_audit 读错路径 | 改了 questions_200.json 但 daily_audit 读 `_RAG_DOCS` | 必须同步写入 `_RAG_DOCS` |
| 0/0 误判通过 | total_queries=0 时 overall_pass=true | `overall_pass = total > 0 and failed == 0` |

## 题库规模参考

| 题数 | 每天 8 题不重复覆盖 |
|------|---------------------|
| 40   | ~5 天（太短） |
| 120  | ~15 天 |
| 223  | ~28 天（推荐） |
| 300+ | ~37+ 天 |
