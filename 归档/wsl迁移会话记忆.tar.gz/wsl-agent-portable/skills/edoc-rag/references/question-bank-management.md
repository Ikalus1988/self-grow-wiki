# RAG 巡检题库管理

## 题库结构

**JSON 路径**：`/mnt/c/Users/hp/Desktop/自研/rag-docs/RAG巡检题库_200题_20260508.json`
**同步副本**：`/home/hp/audit_reports/questions_200.json`
**daily_audit.py 加载路径**：`_RAG_DOCS / "RAG巡检题库_200题_20260508.json"`（`_RAG_DOCS` 默认 `/mnt/c/Users/hp/Desktop/自研/rag-docs/`）

### JSON 格式

```json
{
  "id": "L2-011",           // L1/L2/L3 + 3位编号
  "level": "L2",            // L1=单实体, L2=跨文档, L3=高难度
  "tag": "弧焊",            // 分类标签
  "query": "CO2 焊接和 MAG 焊接在起弧参数设定上有什么区别？",
  "expect": {
    "must_contain_any": ["CO2", "MAG", "起弧", "参数"],  // top-N 结果必须包含至少一个
    "min_top_score": 0.5     // top_score 最低阈值
  }
}
```

### 分层抽样规则（daily_audit.py）

- 每天 7 题：L2 抽 2-3 题，L3 抽 4-5 题
- 30 天内不重复抽同一题
- 题库耗尽时自动轮换
- 候选题（badcase_pending.jsonl）也会被合并进抽样池

## 题库更新流程

### 1. 从 MD 提取题目

```python
import re
def parse_md_table(content):
    questions = []
    for line in content.split('\n'):
        if not line.startswith('|'): continue
        cells = [c.strip() for c in line.split('|')[1:-1]]
        if len(cells) < 5: continue
        qid = cells[0].strip()
        if not re.match(r'^L[23]-\d+$', qid): continue
        must_contain = [k.strip() for k in cells[3].split(',') if k.strip()]
        questions.append({
            "id": qid, "level": "L2" if qid.startswith("L2-") else "L3",
            "tag": cells[1].strip(), "query": cells[2].strip(),
            "expect": {"must_contain_any": must_contain, "min_top_score": float(cells[4])}
        })
    return questions
```

### 2. 去重策略

- **ID 去重**：合并后按 level 重新编号（L3 从 041 开始）
- **Query 去重**：前 40 字符相同视为重复，保留先出现的
- **相似度去重**：word overlap > 60% 视为重复（注意：此阈值可能过于激进，会误删语义不同但用词相似的题目）

### 3. Tag 合并映射

```python
TAG_MERGE = {
    "弧焊调试": "弧焊",
    "弧焊故障": "弧焊",
    "选型推荐": "选型",
    "IO通信": "IO故障",
    "操作步骤": "操作",
}
```

### 4. 关键词自动补充

候选题的 `must_contain_any` 可能为空。自动提取规则：
1. 优先提取型号名（正则 `[A-Z]{1,5}[- ]?\d{2,4}`）
2. 报警代码（`SRVO-\d{3}` 等）
3. 中文技术词（2-4字，排除停用词）
4. 英文技术词（排除 FANUC/TP/TCP 等通用词）

## ⚠️ 测试用例设计陷阱

### 陷阱 1：关键词必须在知识库中存在

**案例**：V2-044 "FANUC机器人高惯量模式V7.30P"，期望关键词含 `V7.30P`。
**问题**：`V7.30P` 是固件版本号，知识库所有 20 万 chunks 中不存在此字符串。
**结果**：测试永远失败，但实际"高惯量模式"检索分数 0.968。

**规则**：设置 `must_contain_any` 前，先用 `rag_core.retrieve()` 验证关键词确实存在于 top-3 结果中。版本号、固件号等极细粒度信息不适合做关键词。

### 陷阱 2：对比型问题检索效果差

**现象**：`"CC-Link 和 EtherNet/IP 各有什么优缺点"` → 分数 0.50
**原因**：每个 chunk 只含单一协议信息，无法同时召回两个协议的对比内容。
**处理**：对比型问题的 `min_top_score` 应设低（0.45），或改为单侧查询。

### 陷阱 3：知识库空白领域的题目无意义

CNC 加工（ROBODRILL/ROBOCUT）、激光切割、协作机器人等领域知识库文档极少，相关题目永远 bad case。不应加入题库。

## QA Case 分析（rag_query_log.db）

### 数据库结构

```sql
-- 主表
query_log(id, ts, query_type, query, top_score, avg_score, num_chunks,
          channel_id, channel_name, latency_ms, tokens_prompt, tokens_completion,
          status, error_msg, category)

-- 反馈表
feedback(id, ts, query_id, query, feedback_type, feedback_text, category, sender)
```

### 分类标准

| 等级 | top_score | 含义 |
|------|-----------|------|
| Good | ≥ 0.8 | 检索命中，答案可靠 |
| Medium | 0.6~0.8 | 部分命中，可能需要补充 |
| Bad | < 0.6 | 未命中或严重偏题 |

### Bad Case 根因分类

| 类型 | 占比 | 改进方向 |
|------|------|----------|
| 知识库无对应内容 | ~40% | 补充文档 |
| 对比/综合型问题 | ~20% | 需要对比总结类文档 |
| 无效/重复测试 | ~30% | svgn-382 等非 FANUC 代码，忽略 |
| 模糊/口语化查询 | ~10% | 查询规范化 |

### 飞书 Bot 查询日志

飞书来源的查询 `latency_ms` 全部为 0（记录不准），`channel_name` 为 "feishu"。
API 来源的查询有准确的延迟和通道信息。
