# Badcase 巡检分类与处理手册

> 从 `badcase_pending.jsonl` 中区分环境噪声 vs 真正质量问题，分类处理

## 文件位置

| 文件 | 路径 | 说明 |
|------|------|------|
| 待审核队列 | `/home/hp/audit_reports/badcase_pending.jsonl` | daily_audit.py 自动追加 |
| 环境异常存档 | `/home/hp/audit_reports/badcase_env_errors.jsonl` | 清理时备份 |
| 原始备份 | `/home/hp/audit_reports/badcase_pending.jsonl.bak` | 清理前自动备份 |
| 分类报告 | `/home/hp/audit_reports/badcase_report_YYYYMMDD.md` | 手动整理输出 |
| 题库审核脚本 | `/home/hp/badcase_review.py` | 交互式审核（a/r/e/s） |

## 分类标准（6 类）

### P0 — 知识库缺口（立即处理）

**报警代码缺失**: 知识库中完全没有该报警代码的内容。
- 判断方法: `collection.get(where_document={'$contains': 'MATE-001'})` 返回空
- 处理: 从 FANUC 官方手册提取报警说明，补充到报警代码文档

**知识库未覆盖**: 查询主题在知识库中完全没有对应文档。
- 特征: `fail_reason` 含 `知识库未覆盖`，`top_score` 通常 < 0.5
- 处理: 标记为待补充内容（对比文档、选型指南等）

### P1 — 排序/过滤问题（优化逻辑）

**报警代码召回弱**: 知识库有内容，但语义检索返回其他相似报警，精确匹配被挤下去。
- 根因: RRF 融合降低精确匹配分数（排名第 3 → 分数从 0.716 降到 0.500）
- 根因: `FANUC_ALARM_PREFIXES` 缺少前缀导致 `entity_alarms` 为空
- 特征: `top_score` 不低（0.6-0.9），但 `fail_reason` 含 `未命中关键词`
- 处理: 检查前缀是否完整 → 重新运行实体提取 → 验证精确匹配加分是否生效
- 详见: `references/alarm-code-entity-extraction-fix.md`

**品牌污染**: 检索结果混入竞品品牌（KUKA/ABB/Yaskawa 等）。
- 特征: `fail_reason` 含 `品牌污染`
- 处理: 检查品牌过滤逻辑 (`rag_core.py` 约 line 1330)

### P2 — 验证后调整

**低分检索**: `top_score` 低于题库阈值。
- **关键陷阱**: `badcase_pending.jsonl` 中的 `top_score` 是题库的 `min_top_score` 阈值，**不是实际检索分数**！
  - 代码: `daily_audit.py` line 435: `"top_score": bq.get("min_score", 0)`
  - 实际检索分数需要重新调用 `retrieve()` 才能获得
- 特征: 大量查询卡在 0.500 分（题库默认阈值）
- 处理: 逐一验证实际检索结果，如果结果可用则降低阈值

**关键词未命中**: 检索结果分数不低，但核心关键词未出现在答案中。
- 特征: `fail_reason` 含 `未命中关键词`，`top_score` 通常 > 0.6
- 处理: 添加同义词映射或检查文档覆盖

## 环境异常识别与清理

### 识别规则

`fail_reason` 包含以下任一关键词 → 环境异常，非真正 badcase:

| 关键词 | 含义 | 典型数量 |
|--------|------|---------|
| `retrieve异常` | 检索函数抛异常 | - |
| `No module named 'chromadb'` | Python 环境错误 | 18 条 |
| `Cannot send a request, as the client has been closed` | HF Hub 不可达或 API 重启 | 39 条 |
| `libcublasLt.so.* not found` | CUDA 库缺失（该用 CPU） | 9 条 |
| `No module named 'torch'` | venv 缺少 torch | 3 条 |

### 批量清理脚本

```python
import json, shutil

with open('/home/hp/audit_reports/badcase_pending.jsonl') as f:
    items = [json.loads(l) for l in f if l.strip()]

env_errors = []
real_badcases = []

for item in items:
    reason = item.get('fail_reason', item.get('reason', ''))
    if any(kw in reason for kw in ['retrieve异常', 'No module', 'Cannot send', 'libcublas']):
        env_errors.append(item)
    else:
        real_badcases.append(item)

# 备份
shutil.copy('/home/hp/audit_reports/badcase_pending.jsonl',
            '/home/hp/audit_reports/badcase_pending.jsonl.bak')

# 写回
with open('/home/hp/audit_reports/badcase_pending.jsonl', 'w') as f:
    for item in real_badcases:
        f.write(json.dumps(item, ensure_ascii=False) + '\n')

# 存档环境异常
with open('/home/hp/audit_reports/badcase_env_errors.jsonl', 'w') as f:
    for item in env_errors:
        f.write(json.dumps(item, ensure_ascii=False) + '\n')

print(f'清理: {len(env_errors)} 环境异常, 保留: {len(real_badcases)} 真正 badcase')
```

## 报警代码检索验证

测试报警代码是否被正确召回:

```python
import sys
sys.path.insert(0, '/home/hp')
from rag_core import retrieve, get_collection

code = 'SRVO-228'

# 1. 检查知识库是否有该报警代码
collection = get_collection()
has_content = collection.get(where_document={'$contains': code}, limit=3)
print(f'{code} 在知识库中: {len(has_content.get("documents", []))} 条')

# 2. 检查 entity_alarms 元数据
results = collection.get(where_document={'$contains': code}, limit=3, include=['metadatas'])
for meta in results['metadatas']:
    alarms = meta.get('entity_alarms', '[]')
    print(f'  entity_alarms: {alarms}')

# 3. 测试实际检索结果
results = retrieve(f'FANUC机器人{code}报警处理', top_k=5, log_channel='test')
if results:
    print(f'检索返回 {len(results)} 条:')
    for r in results[:3]:
        print(f'  score={r["score"]:.3f} file={r.get("filename","?")}')
        if code in r['text']:
            print(f'  ✅ 命中 {code}')
        else:
            print(f'  ❌ 未命中 {code}')
```

## 分类报告模板

整理 badcase 时输出格式:

```markdown
# RAG 知识库 Badcase 巡检报告
生成时间: YYYY-MM-DD HH:MM
待审核总数: N 条（已清理 M 条环境异常）

## 分类概览
| 类型 | 数量 | 处理优先级 |
|------|------|-----------|
| 报警代码缺失 | X | P0 |
| 报警代码召回弱 | X | P1 |
| 低分检索 | X | P2 |
| 关键词未命中 | X | P2 |
| 知识库缺口 | X | P0 |
| 品牌污染 | X | P1 |

## 详细分析
（每类列出具体查询、分数、问题、处理建议）

## 处理优先级
P0 → P1 → P2
```

## 常见陷阱

1. **top_score 字段误解**: `badcase_pending.jsonl` 中的 `top_score` 是题库阈值，不是实际检索分数
2. **环境异常堆积**: 长期不清理会导致 pending 队列膨胀（曾达 91 条，其中 69 条是环境噪声）
3. **报警代码排序**: 精确匹配分数 0.85-0.95 可能被语义检索 0.97+ 挤下去，需部署精确匹配加分（+0.30，已修复）
4. **报警代码实体提取**: `FANUC_ALARM_PREFIXES` 缺少前缀会导致该系列报警不被索引。新增前缀后必须重新运行 `rag_phase1_entity_extract.py`。详见 `references/alarm-code-entity-extraction-fix.md`
5. **文件多样性限制**: `max_per_file=3` 可能导致精确匹配结果被截断
