# BM25 索引重建 + Markdown 文档增量导入

## 触发条件

以下操作后 BM25 缓存失效，必须手动重建：
1. 向量库新增 chunks（PDF 导入、md 文档导入）
2. 向量库删除 chunks
3. `bm25_index.pkl` 被删除或损坏

**症状**：新文档在纯向量检索中命中（score > 0.8），但 retrieve() 返回 score=0.500。
根因：BM25 缓存不含新 chunks，RRF 融合中新文档只出现在一个通道，归一化后恰好 0.500。

## BM25 索引重建

```bash
cd /home/hp && source mkdocs-env/bin/activate && HF_HUB_OFFLINE=1 python3 << 'EOF'
import os; os.environ["HF_HUB_OFFLINE"] = "1"
from rag_core import _bm25_index, BM25_INDEX_PATH
BM25_INDEX_PATH.unlink(missing_ok=True)
print('缓存已清除，开始重建...')
_bm25_index._ensure_index()
print(f'完成: {len(_bm25_index.docs)} chunks')
EOF
```

**耗时**：~5 分钟（200k chunks，主要耗时在 jieba 分词 ~120s + ChromaDB 加载 ~30s）
**缓存路径**：`/home/hp/rag_chromadb/bm25_index.pkl`（~597 MB）
**验证**：重建后 `len(_bm25_index.docs)` 应等于 `coll.count()`

## Markdown 文档增量导入

新写的技术文档（.md）需要手动导入向量库才能被 RAG 检索。

```python
import os; os.environ["HF_HUB_OFFLINE"] = "1"
import chromadb, hashlib, re
from pathlib import Path
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

ef = SentenceTransformerEmbeddingFunction(
    model_name="BAAI/bge-base-zh-v1.5", device="cpu",
    trust_remote_code=False, local_files_only=True
)
coll = chromadb.PersistentClient(path="/home/hp/rag_chromadb") \
       .get_collection("wiki_docs", embedding_function=ef)

def chunk_md(text, size=800):
    """按二级标题分块"""
    chunks, cur = [], ""
    for sec in re.split(r'\n(?=#{1,3} )', text):
        if len(cur) + len(sec) > size and cur:
            chunks.append(cur.strip()); cur = sec
        else:
            cur += "\n" + sec if cur else sec
    if cur.strip(): chunks.append(cur.strip())
    return chunks

# 导入单个文件
md_path = "/mnt/d/知识库wiki/07_机器人/FANUC安全信号体系.md"
path = Path(md_path)
text = path.read_text("utf-8")
src = path.name
h = hashlib.md5(src.encode()).hexdigest()
chunks = chunk_md(text)
ids = [f"md_{h}_{i:03d}" for i in range(len(chunks))]
metas = [{"source": src, "filename": src, "brand": "fanuc",
          "category": "安全功能", "subcategory": "DCS",
          "content_type": "技术文档"} for _ in chunks]

# 删除旧的同名文档（幂等）
try:
    old = coll.get(where={"source": src})
    if old["ids"]: coll.delete(ids=old["ids"])
except: pass

coll.add(ids=ids, documents=chunks, metadatas=metas)
print(f"{src}: {len(chunks)} chunks, collection: {coll.count()}")
```

**导入后必须**：重建 BM25 索引（见上文）

## ⚠️ Pattern.sub() flags 陷阱

```python
# ❌ 错误：Pattern.sub() 不接受 flags 参数
re_compiled = re.compile(r'...', re.I)
re_compiled.sub(lambda m: ..., text, flags=re.I)  # TypeError!

# ✅ 正确：flags 在编译时设置
re_compiled = re.compile(r'...', re.I)
re_compiled.sub(lambda m: ..., text)  # OK

# re.sub() 模块级函数可以接受 flags
re.sub(r'...', replacement, text, flags=re.I)  # OK
```

这个陷阱在 `_CHINESE_ALIAS_RE.sub()` 中踩过（2026-06-15）。
