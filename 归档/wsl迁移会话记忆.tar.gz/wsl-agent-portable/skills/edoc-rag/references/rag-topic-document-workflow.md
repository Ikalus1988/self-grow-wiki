# RAG 专题文档创建工作流（2026-06-15 建立）

## 适用场景
为 FANUC 知识库补充专题文档（安全功能、焊接工艺、坐标系、通信协议等）。

## 工作流

### 1. 需求分析
- 从查询日志找出低分查询（score < 0.6）
- 按领域分类，确定需要补充的专题
- 优先级：查询频率 × (1 - 当前分数)

### 2. 内容提取
- 用 `pdftotext -f <start> -l <end> <PDF> -` 提取关键章节
- 用 `rag_core.retrieve()` 检查现有内容覆盖度
- 从多个 PDF 交叉提取，避免单一来源偏差

### 3. 文档撰写
- 写入 `/mnt/d/知识库wiki/07_机器人/` 目录
- 命名规则：`FANUC<主题>.md`
- 每个技术声明必须标注出处 PDF + 章节
- 使用 markdown 表格做对比
- 安全相关内容加 ⚠️ 警告

### 4. 跨文档一致性审查（多文档时必做）
- 委托子代理做一致性审查
- 检查项：安全等级、信号名称、恢复方式、交叉引用
- 输出 PASS/WARN/FAIL 分级报告
- WARN 和 FAIL 必须修复后再入库

### 5. 入库
- 分块：按二级标题分块，chunk_size=800
- 导入：ChromaDB wiki_docs collection
- 必须设 `HF_HUB_OFFLINE=1`
- 删除旧同名 chunks（幂等操作）

### 6. BM25 重建
- 删除旧缓存 → `_bm25_index._ensure_index()`
- 200k chunks 耗时 3-5 分钟
- 验证：`_bm25_index.N == coll.count()`

### 7. Smoke Test
- 用之前低分查询重测
- 单实体查询应立即见效（score > 0.6）
- 对比型查询可能仍为 0.500（RRF 融合限制，见 edoc-rag skill）

## 已产出文档（2026-06-15）
| 文档 | chunks | 覆盖查询类型 |
|------|--------|-------------|
| FANUC安全信号体系.md | 7 | FENCE/SAFE/DCS/E-Stop 对比 |
| FANUC碰撞检测功能.md | 6 | Collision Guard 灵敏度/配置 |
| FANUC_DCS安全功能配置.md | 8 | DCS 密码/安全领域/速度检查 |
| FANUC协同作业机器人CR系列.md | 3 | CR 碰触停止/退避/负载切换 |
| FANUC焊接参数与缺陷关系.md | 3 | 参数-缺陷矩阵 |
| FANUC坐标系对比与应用.md | 4 | 五种坐标系对比 |
| FANUC工业通信协议对比.md | 6 | CC-Link/EtherNet-IP/PROFINET |
