# 每日巡检故障排查手册

> daily_audit.py 运行异常时的完整诊断流程

## 架构概览

```
daily_audit.py
  └─ urllib.request → http://localhost:8002/query
                       └─ rag_api.py (FastAPI, port 8002)
                            ├─ rag_core.retrieve() → ChromaDB PersistentClient
                            │   └─ /home/hp/rag_chromadb/ (200,715 vectors)
                            ├─ BM25 rerank → bm25_index.pkl
                            └─ LLM channels: MiMo-Flash, MiMo-Pro, DeepSeek, Qwen
```

## 故障模式速查

| 错误信息 | 根因 | 影响范围 | 修复 |
|---------|------|---------|------|
| `Cannot send a request, as the client has been closed` | **HF Hub 网络不可达**（模型加载时 httpx 崩溃，进程无法启动）或 API 重启期间瞬态错误 | 全部题目 | 见下文"根因 A vs 根因 B 区分" |
| `No module named 'chromadb'` | Python 环境错误（用了系统 python 而非 venv） | 全部题目 | `source mkdocs-env/bin/activate` |
| `libcublasLt.so.* not found` | CUDA 库缺失，嵌入模型无法加载 | 全部题目 | `CUDA_VISIBLE_DEVICES=""` 强制 CPU |
| `No module named 'torch'` | venv 缺少 torch 依赖 | 全部题目 | `pip install torch` |
| `top_score=0.500 < 0.6` | 检索正常但相关度不足 | 个别题目 | 优化查询词或调低阈值 |
| `未命中关键词 [...]` | 检索正常但关键词验证失败，**或测试用例期望了知识库中不存在的关键词** | 个别题目 | 见下文"测试用例设计 vs 检索退化" |
| 所有 LLM 通道 401 | MiMo API Key 过期 | 降级为纯检索 | 更新 `.bashrc` 中的 key |

## 详细诊断流程

### Step 0: 区分 "client has been closed" 的根因 A vs B

同一错误信息 `Cannot send a request, as the client has been closed.` 有两个完全不同的根因：

| 特征 | 根因 A: HF Hub 不可达 | 根因 B: API 重启瞬态 |
|------|---------------------|---------------------|
| 进程是否存活 | **否**（启动即崩溃） | 是（正常运行） |
| `/tmp/rag_api.log` 最后几行 | RuntimeError + httpx traceback | Application startup complete |
| `curl localhost:8002/health` | 连接拒绝 | 200 OK |
| `curl https://huggingface.co` | 000/超时/Connection reset | 200 |
| 重跑巡检 | **同样失败**（每次重启都崩） | 可能恢复 |
| **修复** | `local_files_only=True` + `HF_HUB_OFFLINE=1` | 等 API 稳定后重跑 |

**快速判断**：
```bash
# 进程存活？
ps aux | grep rag_api | grep -v grep
# 无输出 → 根因 A（HF Hub 不可达）
# 有输出 → 根因 B（重启瞬态）
```

### Step 1: API 进程健康检查

```bash
# 存活检查
curl -s http://localhost:8002/health
# {"status":"ok"} + HTTP 200 = 正常
# 连接拒绝 = 进程未启动

# 进程信息
ps aux | grep rag_api | grep -v grep
cat /tmp/rag_api.pid 2>/dev/null
```

### Step 2: API 启动日志

```bash
# 看最近启动时间和预加载状态
tail -30 /tmp/rag_api.log

# 关键信息：
# - "已加载向量库: N vectors" — 向量库加载成功
# - "BM25 索引已从缓存加载" — BM25 就绪
# - "[MiMo-V2-Flash] 不可用" — LLM 通道状态
```

### Step 3: 端到端查询测试

```bash
# 测试完整查询链路
curl -s -X POST http://localhost:8002/query \
  -H "Content-Type: application/json" \
  -d '{"query":"SRVO-023 停止时误差过大","top_k":3,"session_id":"diag"}' \
  --max-time 30 | python3 -m json.tool | head -30

# 关注：
# - elapsed < 30s = 正常
# - sources 非空 = 检索正常
# - answer 包含"降级" = LLM 不可用但检索 OK
```

### Step 4: 检查巡检报告

```bash
# 读取最新报告
cat /home/hp/audit_reports/audit_$(date +%Y-%m-%d).json | python3 -m json.tool

# 判断：
# total_queries=0 → 全部基础设施异常，无法评估
# total_queries>0, failed=0 → 真正通过
# total_queries>0, failed>0 → 有检索质量问题
```

### Step 5: Badcase 队列健康

```bash
# 统计 pending 条数
wc -l /home/hp/audit_reports/badcase_pending.jsonl

# 统计基础设施异常占比
grep -c "client closed\|No module\|libcublas" /home/hp/audit_reports/badcase_pending.jsonl

# 如果基础设施异常 > 50%，应该批量清理而非逐条审查
```

## overall_pass 逻辑修复

`daily_audit.py` 中的判定逻辑有已知缺陷（2026-06-05 发现）：

```python
# 当前代码（约 line 350）：
overall_pass = (failed == 0)

# 问题：total_queries=0 时，failed=0，误判为通过
# 修复：
overall_pass = (total_queries > 0 and failed == 0)
```

## 飞书推送内容检查

巡检结果通过飞书 webhook 推送。当全部异常时，推送内容应明确标注"基础设施异常"而非显示"0/0 (0%)"让人误以为系统正常。

## 已知的周期性问题

| 时间 | 问题 | 持续 | 修复 |
|------|------|------|------|
| 2026-05-13 | chromadb 模块缺失 | 数天 | 修复 venv |
| 2026-05-21 | httpx client closed | 单次 | API 重启后恢复 |
| 2026-05-23 | libcublasLt 缺失 | 数天 | CUDA_VISIBLE_DEVICES="" |
| 2026-06-05 | httpx client closed + MiMo 401 | 单次 | HF Hub 不可达导致进程崩溃，设 `local_files_only=True` + `HF_HUB_OFFLINE=1` 修复 |

## 测试用例设计 vs 检索退化

巡检失败不一定是检索质量问题。**先区分是测试用例设计问题还是真实检索退化。**

### 诊断流程

1. **复现检索**：用失败的查询文本跑 `rag_core.retrieve()`，看 top-8 结果
2. **检查关键词命中**：逐条检查 top-8 的 text 是否包含测试期望的关键词
3. **拆分查询**：把组合查询拆成独立关键词分别检索，判断哪个词是瓶颈
4. **搜索知识库**：用 `search_files` 在 `chunks_filtered.json` 或 `rag_data/extracted/*.json` 中搜索缺失关键词

### 判定标准

| 情况 | 判定 | 处理 |
|------|------|------|
| 关键词在 top-8 中命中但测试仍报失败 | 测试用例逻辑问题（检查范围或匹配方式） | 修正测试用例的 expect 定义 |
| 关键词单独搜高分（>0.90），组合查询低分 | 查询被无关词稀释 | 检查是否有噪声词（固件版本号等） |
| 关键词全库不存在（search_files 0 命中） | 知识库缺失 或 测试用例期望了不存在的内容 | 确认是否有对应手册未导入；若无，则修正测试用例 |
| 关键词存在但检索分数低（<0.60） | 真实检索退化 | 检查 BM25 索引、实体提取、RRF 融合逻辑 |

### 典型案例：V2-044 "FANUC机器人高惯量模式V7.30P"

- 组合查询 top_score = 0.500，测试期望关键词 `['高惯量', 'V7.30P', '惯量']`
- 单搜 `"高惯量模式"` → 0.968（优秀），命中 5+ 文档
- 单搜 `"V7.30P"` → 全库 0 命中（`chunks_filtered.json` 也没有）
- result [1]（B-82234CM_13.PDF）text 中实际包含 `高惯量` + `惯量`，但不含 `V7.30P`
- **判定**: 测试用例设计问题。V7.30P 是固件版本号，知识库无此字符串。"高惯量模式"检索本身没问题。
- **修复**: 从 expect.must_contain_any 中去掉 `V7.30P`
