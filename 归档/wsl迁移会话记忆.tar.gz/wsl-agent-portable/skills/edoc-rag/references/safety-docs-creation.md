# 安全功能专题文档（2026-06-15 创建）

## 已创建文档

| 文件 | 路径 | 内容 | chunks |
|------|------|------|--------|
| FANUC安全信号体系 | `/mnt/d/知识库wiki/07_机器人/FANUC安全信号体系.md` | FENCE/EAS/DCS/E-Stop/Collision Guard 对比 | 7 |
| FANUC碰撞检测功能 | `/mnt/d/知识库wiki/07_机器人/FANUC碰撞检测功能.md` | Collision Guard 灵敏度/COL GUARD ADJUST | 6 |
| FANUC_DCS安全功能配置 | `/mnt/d/知识库wiki/07_机器人/FANUC_DCS安全功能配置.md` | DCS密码/安全领域/速度检查/恢复操作 | 8 |

## 跨文档一致性审查结果

审查发现并修复的问题：
- FENCE/EAS 是同一安全回路在不同控制器型号上的命名（R-30iA叫FENCE，R-30iB叫EAS）
- SFDO 脉冲检查禁用时安全等级从 PL e 降为 PL d — 仅文档1有，需在文档3补充
- DCS状态表（8种状态）需在文档3中完整列出

## 向量库导入方法

```bash
cd /home/hp && source mkdocs-env/bin/activate && HF_HUB_OFFLINE=1 python3 << 'EOF'
import os; os.environ["HF_HUB_OFFLINE"] = "1"
import chromadb, hashlib, re
from pathlib import Path
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

ef = SentenceTransformerEmbeddingFunction(model_name="BAAI/bge-base-zh-v1.5", device="cpu", trust_remote_code=False)
client = chromadb.PersistentClient(path="/home/hp/rag_chromadb")
coll = client.get_collection("wiki_docs", embedding_function=ef)

# 按二级标题分块，chunk_size=800
# metadata: brand=fanuc, category=安全功能, content_type=技术文档
# ID格式: md_{hash}_{序号}
EOF
```

## 增量导入注意事项

1. 必须设 `HF_HUB_OFFLINE=1`，否则 ChromaDB add() 会因 HF Hub 网络问题崩溃
2. 导入后需重启 rag_api 进程使 BM25 索引重建
3. 向量库 collection 名是 `wiki_docs`（非 `rag_docs`）
