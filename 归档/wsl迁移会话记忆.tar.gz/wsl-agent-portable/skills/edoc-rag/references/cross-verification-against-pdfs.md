# 新文档 vs PDF 原文交叉验证流程

> 场景：向知识库添加专题文档（.md）后，验证文档中的技术断言是否与 PDF 原文一致，防止 AI 生成噪音污染知识库。

## 流程

1. **提取断言**：每篇文档取 3-5 个关键断言（安全等级、信号名称、报警代码、配置路径、力限值等）
2. **RAG 检索验证**：用 `retrieve()` 搜索 PDF 知识库中的对应内容
3. **逐条比对**：断言 vs PDF 证据，标记 PASS/WARN/FAIL
4. **修复 FAIL 项**：CONTRADICTED 的断言必须立即修正
5. **记录待查项**：NEEDS REVIEW 的断言标注为人工待确认

## 输出格式

```markdown
## [文档名]
### Claim: [具体断言]
- PDF evidence: [PDF 中的内容]
- Verdict: ✅ CONFIRMED / ⚠️ NEEDS REVIEW / ❌ CONTRADICTED
- Detail: [说明]
```

## 优先验证的内容

- 安全等级（类别/PL/SIL）— 错误会导致安全误判
- 报警代码含义 — 错误会导致误诊
- 配置路径/菜单 — 错误会导致用户找不到
- 力限值/速度限制 — 错误会导致安全风险
- 信号名称（SIR/SPO/FENCE/EAS）— 错误会导致接线错误

## 案例（2026-06-15）

28 项断言验证结果：
- 19 CONFIRMED (68%) — PDF 直接支持
- 8 NEEDS REVIEW (29%) — PDF 未直接命中
- 1 CONTRADICTED (4%) — SRVO-002 标注为"安全门打开"，PDF 确认为"示教器紧急停止"，已修复

安全报警码标错是最危险的噪音类型，必须立即修正。
