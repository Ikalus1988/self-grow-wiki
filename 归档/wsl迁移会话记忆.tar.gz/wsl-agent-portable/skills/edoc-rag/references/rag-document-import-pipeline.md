# RAG 文档增量导入管线

## 新增 Markdown 文档到向量库

当为知识库补充专题文档（如安全功能、焊接参数等）时，需将 md 文件导入 ChromaDB。

### 导入脚本模板

```python
import os; os.environ["HF_HUB_OFFLINE"] = "1"
import chromadb, hashlib, re
from pathlib import Path
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

ef = SentenceTransformerEmbeddingFunction(
    model_name="BAAI/bge-base-zh-v1.5", device="cpu", trust_remote_code=False
)
coll = chromadb.PersistentClient(path="/home/hp/rag_chromadb").get_collection(
    "wiki_docs", embedding_function=ef
)

MD_FILES = ["/mnt/d/知识库wiki/07_机器人/新文档.md"]

def chunk_md(text, size=800):
    """按二级标题分块，每块 ≤800 字符"""
    chunks, cur = [], ""
    for sec in re.split(r'\n(?=#{1,3} )', text):
        if len(cur) + len(sec) > size and cur:
            chunks.append(cur.strip()); cur = sec
        else:
            cur += "\n" + sec if cur else sec
    if cur.strip(): chunks.append(cur.strip())
    return chunks

for p in MD_FILES:
    path = Path(p)
    text = path.read_text("utf-8")
    src = path.name
    h = hashlib.md5(src.encode()).hexdigest()
    chunks = chunk_md(text)
    ids = [f"md_{h}_{i:03d}" for i in range(len(chunks))]
    metas = [{"source": src, "filename": src, "brand": "fanuc",
              "category": "...", "subcategory": "...", "content_type": "技术文档"}
             for _ in chunks]
    # 删除旧同名文档
    try:
        old = coll.get(where={"source": src})
        if old["ids"]: coll.delete(ids=old["ids"])
    except: pass
    coll.add(ids=ids, documents=chunks, metadatas=metas)
    print(f"{src}: {len(chunks)} chunks")
```

### ⚠️ 导入后必做

1. **BM25 缓存失效**：新增 chunks 不在旧 BM25 pickle 缓存中。删除缓存触发重建：
   ```bash
   rm -f /home/hp/rag_chromadb/bm25_index.pkl
   ```
   重建耗时：~5 分钟（200k chunks，ChromaDB 加载 65s + jieba 分词 200s + BM25 构建 9s + 缓存写入 15s）

2. **或手动触发重建**：
   ```python
   from rag_core import _bm25_index, BM25_INDEX_PATH
   BM25_INDEX_PATH.unlink(missing_ok=True)  # 删缓存
   _bm25_index._loaded = False
   _bm25_index._ensure_index()  # 重建
   ```

3. **rag_api 无需重启**：向量库是进程内加载的，下次查询自动包含新文档。但 BM25 需要重建。

## 跨文档一致性审查

为同一领域创建多篇文档时，必须做跨文档一致性审查：

1. **安全等级声明**（类别/PL/SIL）必须完全一致
2. **信号名称**（SIR/SPO/SPI/SFDO/EAS/FENCE）必须一致
3. **交叉引用**必须指向正确的文档名（全名，非别名）
4. **对比表**中恢复方式/配置方式等维度必须一致
5. **发现矛盾时标注，交用户确认**，不要自行决定哪边正确

审查工具：delegate_task 给子 agent 读取全部文档做对比，输出 PASS/WARN/FAIL 分类报告。
