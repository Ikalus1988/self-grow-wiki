# RAG 巡检题库维护

## 题库位置

| 文件 | 路径 | 用途 |
|------|------|------|
| JSON | `/mnt/c/Users/hp/Desktop/自研/rag-docs/RAG巡检题库_200题_20260508.json` | daily_audit.py 直接加载 |
| JSON 备份 | `/home/hp/audit_reports/questions_200.json` | daily_audit 备选路径 |
| MD 文档 | `/mnt/c/Users/hp/Desktop/自研/rag-docs/RAG巡检题库_263题_20260614.md` | 人工查看 |

⚠️ 修改 JSON 后必须同步复制到 `questions_200.json`。

## JSON 格式

```json
{
  "id": "L3-041",
  "level": "L3",
  "tag": "弧焊",
  "query": "焊接过程中焊缝出现气孔，气体流量和焊丝干伸长度该怎么排查？",
  "expect": {
    "must_contain_any": ["气孔", "气体", "流量", "干伸", "焊缝"],
    "min_top_score": 0.35
  }
}
```

## 难度层级

| Level | 说明 | daily_audit 抽样权重 |
|-------|------|---------------------|
| L1 | 单实体精确查询（报警代码、型号） | 每天 2 题 |
| L2 | 跨文档对比查询 | 每天 2-3 题 |
| L3 | 高难度综合查询 | 每天 3-4 题 |

## 分类 Tag（2026-06-14 确认）

弧焊(50) | 报警诊断(15) | IO故障(17) | 安全配置(17) | 负载惯量(15) | TCP设定(15) | 调试(15) | 选型(17) | 语义鸿沟(11) | 变位机(10) | 编码器(10) | 维护(10) | 型号对比(8) | 系统参数(8) | 坐标系(7) | 点焊(6) | 搬运(6) | 故障排查(5) | 操作(5) | 通信(2) | 工具(3) | 焊接工艺(2)

## 新增题目流程

1. 用 `rag_core.retrieve(query)` 验证题目在知识库中有内容（top_score ≥ 0.6）
2. 提取关键词填入 `must_contain_any`（4-5 个，含型号/报警代码/技术术语）
3. 设定 `min_top_score`（L2: 0.45-0.5, L3: 0.35-0.45）
4. 按 query 前 40 字符去重（已有类似题则跳过）
5. 写入 JSON + 同步 `questions_200.json`
6. 验证 `daily_audit.load_question_bank()` 能正确加载

## 去重规则

- 按 query 前 40 字符去重
- 60% 词重叠视为重复（`len(w1 & w2) / len(w1 | w2) > 0.6`）
- 保留 L2 版本，删除重复的 L3

## Bad Case → 题目转化

从 `rag_query_log.db` 中提取 bad case（top_score < 0.6）：
1. 排除无效查询（svgn-xxx、测试查询）
2. 排除知识库无内容的查询（如 CNC/激光切割）
3. 将有效 bad case 转化为 L3 题目，补充关键词

## Feishu 云文档同步

Bot 缺少 `docx:document` 权限时无法自动创建。用户授权后：
1. 创建文档 → 写入 blocks（每批 10 个）→ 设置权限 → 发卡片到群
2. 域名：`mi.feishu.cn`
3. 详见 feishu skill

## daily_audit.py 采样逻辑

- 每天 7-8 题，分层抽样（L1:2, L2:2-3, L3:3-4）
- 30 天内不重复，题库耗尽时自动轮换
- badcase_pending 队列中的题目也会被抽到
- 采样 seed 基于时间戳
