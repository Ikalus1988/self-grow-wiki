---
title: "飞书 Bot 401 错误排查 — RAG API vs Gateway auxiliary 区分"
domain: devops
created: 2026-05-27
source: session
---

## 症状

飞书 bot `@正义` 查询返回：
```
❌ Non-retryable error (HTTP 401): HTTP 401: Invalid API Key
⚠️ Non-retryable error (HTTP 401) — trying fallback...
```

但直接 curl 测试 RAG API 正常：
```bash
curl -s http://localhost:8002/query \
  -H "Content-Type: application/json" \
  -d '{"query":"test","session_id":"test"}'
# 返回正常 JSON
```

## 根因区分

| 来源 | 现象 | 日志关键词 |
|------|------|-----------|
| **RAG API 本身** | curl 测试也 401 | rag_api.py 输出 |
| **Gateway auxiliary** | curl 正常，bot 报 401 | `agent.auxiliary_client`, `compression`, `no resolvable api_key` |

## 诊断步骤

### Step 1: 确认 RAG API 本身正常

```bash
# 直接测试 RAG API
curl -s -X POST http://localhost:8002/query \
  -H "Content-Type: application/json" \
  -d '{"query":"FANUC机器人型号","session_id":"test"}'

# 正常应返回 JSON 含 answer/sources/status
# 状态应为 "通道: MiMo-V2-Flash"
```

### Step 2: 检查 Gateway 日志

```bash
hermes logs --lines 50 | grep -E "auxiliary|compression|401|api_key"
```

如发现：
```
WARNING agent.auxiliary_client: resolve_provider_client: named custom provider 'mify' has no resolvable api_key
WARNING agent.context_compressor: Failed to generate context summary: Error code: 401...
```

**确认**：问题是 `auxiliary.compression` 缺少 `api_key_env`，不是 RAG API 故障。

## 修复

### 检查配置

```bash
# 确认 config.yaml 有 api_key_env
grep -A10 "compression:" ~/.hermes/config.yaml
```

应有：
```yaml
auxiliary:
  compression:
    provider: mify
    model: xiaomi/mimo-v2-flash
    base_url: https://api.llm.mioffice.cn/v1
    api_key_env: MIFY_API_KEY  # <-- 必须存在
    timeout: 120
```

### 重启 Gateway

```bash
hermes gateway restart
```

### 验证 RAG API 进程仍在

Gateway 重启不会自动重启 RAG API（独立进程）：

```bash
# 检查 RAG API 状态
curl -s http://localhost:8002/health

# 如返回空，需重启 RAG API
bash ~/start_rag_api.sh
```

### 最终验证

```bash
# 测试完整链路
curl -s -X POST http://localhost:8002/query \
  -H "Content-Type: application/json" \
  -d '{"query":"JD17端口定义","session_id":"verify"}' | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print(f'{d.get(\"status\")}: {len(d.get(\"answer\",\"\"))} chars')"

# 期望输出: 通道: MiMo-V2-Flash: XXX chars
```

## 关键知识点

- `auxiliary.*` 子任务（compression/session_search等）需独立配 `model + api_key_env`
- Gateway 重启后，检查 RAG API 是否仍在运行（独立进程，不随 Gateway 重启）
- 401 错误优先区分来源：RAG API 自身 vs Gateway 辅助服务

## 相关文件

| 文件 | 作用 |
|------|------|
| `~/rag_api.py` | RAG FastAPI 服务 |
| `~/start_rag_api.sh` | RAG API 启动脚本 |
| `~/rag_core.py` | 通道配置（MODEL_CHANNELS） |
| `~/.hermes/config.yaml` | Gateway auxiliary 配置 |
