# FANUC 报警代码 → PDF 手册映射

当 RAG API 超时或向量库未命中时，可直接用 `pdftotext` 从 PDF 中提取报警代码定义。

## 核心报警代码手册

| 手册编号 | 语言 | 文件名（知识库中） | 包含的报警系列 | 示例 |
|---------|------|-------------------|---------------|------|
| **B-83284EN-1/08** | EN | `B-83284EN-1_08_01.PDF` | SRVO, SSPC, **SVGN**, SYST, TAST 等 | **SVGN-450** Pressure profile by DI time out |
| **B-83284CM-1/08** | CN | `B-83284CM-1_08.PDF` | 同上（中文版） | SVGN-450（中文描述） |
| **B-83184CM/09** | CN | `B-83184CM_09.PDF` | **DCS 双检安全**（密码/位置检查/安全参数）+ **SYST-347** | SYST-212 需要应用DCS参数, SYST-347 DCS参数错误 |
| **B-83184EN/10** | EN | `B-83184EN_10.PDF` | 同上（英文版）+ SYST-347 | SYST-347: DCS parameter error (SSI[13] / CSC DSBL signal) |
| B-83284EN-2~5 | EN | `B-83284EN-2_10.PDF` 等 | 可选功能手册（非报警码） | 弧焊、点焊、涂胶等 |
| B-83284CM-2~4 | CN | `B-83284CM-2_10.PDF` 等 | 同上中文版 | — |

> B-83284 系列全称：*FANUC Robot series R-30iB/R-30iB Mate/R-30iB Plus/R-30iB Mate Plus/R-30iB Compact Plus/R-30iB Mini Plus CONTROLLER OPERATOR'S MANUAL*
> B-83184 系列全称：*FANUC Robot series Dual Check Safety (DCS) 功能说明书*
> ⚠️ **B-83184 未被 RAG 向量库索引**。DCS 相关查询必须用 pymupdf 直接从 PDF 提取。

## 快速提取命令

### 搜索特定报警码

```bash
cd "/mnt/d/知识库wiki/07_机器人/FANUC PLUS 最新/PDF/"
pdftotext B-83284EN-1_08_01.PDF - -l 900 | grep -A 5 "SVGN-450"
```

### 列出所有 SVGN 报警码

```bash
pdftotext B-83284EN-1_08_01.PDF - -l 900 | grep -P "SVGN-\d{3}\s"
```

### 提取完整报警码段落

```bash
pdftotext B-83284EN-1_08_01.PDF - -f 758 -l 830
```

SVGN 系列从 **第 758 页**（"4.17.11 SVGN Alarm Code"）开始。

## 报警系列家族

| 前缀 | 含义 | 页码范围 |
|------|------|---------|
| **SRVO** | Servo 报警（伺服驱动/电机） | ~680-755 |
| **SSPC** | Spot Specific 报警（点焊专用） | ~750-758 |
| **SVGN** | Servo Gun 报警（伺服焊枪） | **~758-830+** |
| **SYST** | System 报警（系统） | ~830+ |
| **TAST** | Track/Arc Seam Tracking 报警 | 后续章节 |
| **MHND** | Material Handling 报警（物料搬运/抓手） | 报警代码章节内 |

## MHND 系列（物料搬运/抓手）— B-83284EN-1 验证原文

> 2026-06-22 从 `B-83284EN-1_08_01.PDF` 全文 grep 核验。物料搬运功能说明书编号常被引用为 **B-83124CM-6/01**（本地 wiki 未收录,无法本地核验,引用合理性见 SKILL.md「答案引用审查纪律」章节）。

| 报警码 | 原文（已本地验证） |
|--------|------------------|
| **MHND-233** | TP hardkey macros are in use（信息提示）|
| **MHND-234** | Valve %s: Manual grip part. Cause: Information message only. Remedy: N/A |
| **MHND-235** | Valve %s: Manual release. Cause: Information message only. Remedy: N/A |
| **MHND-236** | Error: Valve is not setup. Cause: **The valve signal number (S#) can not be zero.** Remedy: **Select MENU, I/O, MH Valves to setup the gripper signals.** |
| **MHND-237** | Error: Clamp is not setup. Cause: **The clamp signal number (S#) can not be zero.** Remedy: **Select MENU, I/O, MH Valves to setup the gripper signals.** |

**关联 UI 画面**：`MENU → I/O → MH Valves`,配置 `S#`（阀门号/抓手号） + `Clamp Inputs` + `Part Present Inputs` 字段。

**应用上下文**：小米《FANUC机器人小米标准软件使用手册_v19.pdf》第 61 页 8.3 节。MI03_GRP 通过 MH Valves 配的 PartPresent / CylinderOpen/Close DI 信号映射给 DO 发给 PLC。

## 典型搜索模式

```python
import subprocess, os, re

pdf_dir = "/mnt/d/知识库wiki/07_机器人/FANUC PLUS 最新/PDF/"
text = subprocess.run(
    ["pdftotext", os.path.join(pdf_dir, "B-83284EN-1_08_01.PDF"), "-",
     "-f", "750", "-l", "900"],
    capture_output=True, text=True, timeout=120
).stdout

# 搜索报警码
for line in text.split("\n"):
    if "SVGN-450" in line:
        print(line)
```

## 注意事项

- SVGN 报警码编号不连续（如跳过了 SVGN-003, 006, 007, 014 等）
- 部分报警码附带辅助信息码（如 SVGN-467 是 SVGN-450 的辅助信息）
- 中文版 B-83284CM-1_08.PDF 结构相同，页码偏移可能 ±2 页
- `pdftotext` 对扫描版 PDF 效果差，先检查是否为文本版 PDF

## 主板七段 LED 报警码（book.pdf / B-82285EN-2/02）

⚠️ **与 TP 报警码是不同体系**：SRVO/SYST 等是示教器显示的软件报警码，七段 LED 是主板硬件级诊断码（0-7），在 TP 无法启动时尤为重要。

| LED 代码 | 含义 | 处理步骤 |
|---------|------|---------|
| **0** | CPU 卡 DRAM 奇偶校验报警 | ①更换 CPU 卡 ②更换主板 |
| **1** | FROM/SRAM 模块 SRAM 奇偶校验报警 | ①更换 FROM/SRAM 模块 ②更换主板 |
| **2** | 通信控制器总线错误 | ①更换主板 |
| **3** | 通信控制器 DRAM 奇偶校验报警 | ①更换主板 |
| **4** | 伺服报警（主板上） | ①更换轴控制卡 ②更换主板 |
| **5** | **SYSEMG（系统紧急停止）** | ①更换轴控制卡 ②更换 CPU 卡 ③更换主板 |
| **6** | **SYSFAIL（系统故障）** | ①更换轴控制卡 ②更换 CPU 卡 ③更换主板 |
| **7** | 5V 供电正常 / 无报警 | 正常状态 |

**排查场景**：用户说"主板报警代码 X"时，通常是七段 LED 显示的数字，而非 TP 上的 SRVO/SYST 码。此时应检索 book.pdf (B-82285EN-2/02) 的 "7-SEGMENT LED INDICATOR" 章节。

**检索技巧**：用英文关键词 "seven segment LED main board alarm" 检索效果远好于中文 "主板报警代码 X"（英文命中 book.pdf score=0.980，中文仅 0.580）。

```bash
# 直查 book.pdf
pdftotext "/mnt/d/知识库wiki/07_机器人/FANUC手册/book.pdf" - 2>/dev/null | grep -A 10 -B 2 "seven segment\|7-segment\|SYSEMG\|SYSFAIL"
```

## 报警码查询格式陷阱

RAG 规范化 `_normalize_query` 会自动给报警码补零（SRVO023 → SRVO-023），但**七段 LED 数字码不含前缀**，不受此规范化影响。

**报警码查询最佳实践**：
- SYST 系列：用 "SYST-347"（不带前导零）效果最好（score=0.950），"SYST-0347" 反而降到 0.526
- 七段 LED：用英文 "seven segment LED main board alarm 5" 效果远好于中文 "主板报警代码 5"
- SRVO 系列：用 "SRVO-023" 格式（规范化后自动匹配）