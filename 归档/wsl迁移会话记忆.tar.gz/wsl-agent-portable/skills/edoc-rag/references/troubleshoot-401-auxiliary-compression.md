# Troubleshooting: RAG 401 Error via Feishu Bot

## Symptom
- Feishu bot @正义 returns: `❌ Non-retryable error (HTTP 401): Invalid API Key`
- Direct RAG API test (`curl localhost:8002/query`) works fine
- Bot worked previously but started failing

## Root Cause
Gateway's `auxiliary.compression` client lacks `api_key_env` configuration.

When context compression triggers (long conversations), it uses a separate model client from the main chat. If this auxiliary client isn't configured with the API key environment variable, it returns 401.

## Log Signature
```
WARNING agent.auxiliary_client: resolve_provider_client: named custom provider 'mify' has no resolvable api_key
...
WARNING agent.context_compressor: Failed to generate context summary: Error code: 401
```

## Fix
Ensure `config.yaml` has `api_key_env` under `auxiliary.compression`:

```yaml
auxiliary:
  compression:
    provider: mify
    model: xiaomi/mimo-v2-flash
    base_url: https://api.llm.mioffice.cn/v1
    api_key_env: MIFY_API_KEY  # <-- Must be present
    timeout: 120
```

## Verification Steps

1. **Test RAG API directly** (bypass Gateway):
   ```bash
   curl -s http://localhost:8002/status
   curl -s -X POST http://localhost:8002/query \
     -H "Content-Type: application/json" \
     -d '{"query":"test","session_id":"test"}'
   ```

2. **Check Gateway logs** for auxiliary client errors:
   ```bash
   hermes logs --lines 50 | grep -E "auxiliary|compression|401"
   ```

3. **Verify config** has `api_key_env`:
   ```bash
   grep -A5 "compression:" ~/.hermes/config.yaml
   ```

4. **If config is correct but error persists**: Gateway was started before config change. Restart:
   ```bash
   hermes gateway restart
   ```

## Related Config Pattern
Other auxiliary tasks need the same pattern:
- `auxiliary.vision` → needs `SILICONFLOW_API_KEY` for Qwen-VL
- `auxiliary.web_extract` → needs `MIFY_API_KEY` for text extraction
- `auxiliary.compression` → needs `MIFY_API_KEY` for context summarization

All auxiliary.* subtasks require independent `model` + `api_key_env` configuration.
