# 专题文档交叉验证模式

> 用途：AI 生成的技术文档入库前，与 PDF 原文逐条比对，防止噪音污染知识库。

## 触发条件

- 新增专题文档（安全功能/焊接参数/坐标系对比等）
- 修改已有文档中的技术断言
- 用户明确要求验证

## 验证流程

1. **提取断言**：从文档中提取 3-5 个关键技术断言
   - 安全等级（类别/PL/SIL）
   - 信号名（SIR/SPO/SPI/SFDO/EAS/FENCE）
   - 报警代码（SRVO/PRIO/SYST）
   - 配置路径（MENU → x → y）
   - 数值参数（力限值/速度/数量上限）

2. **RAG 检索**：对每个断言，用 `retrieve()` 搜索 PDF 原文
   ```python
   from rag_core import retrieve
   results = retrieve("断言关键词", top_k=3)
   ```

3. **逐条比对**：将断言与 PDF 证据对比
   - ✅ CONFIRMED — PDF 直接支持
   - ⚠️ NEEDS REVIEW — PDF 未命中，不一定错
   - ❌ CONTRADICTED — PDF 明确矛盾，必须修复

4. **修复矛盾项**：CONTRADICTED 的断言必须立即修正

5. **输出报告**：结构化验证报告（每个断言的 verdict + evidence）

## 已知陷阱

- **PDF 检索范围 > ripgrep 覆盖范围**：ripgrep 搜不到不代表知识库没有
- **对比型查询分数偏低**：RRF 融合中 PDF 碎片占满向量 top-8，新文档被挤出
- **安全等级必须精确**：类别3/4, PL d/e 是不同等级，不能笼统写"类别3/4"

## 实际案例（2026-06-15）

- SRVO-002 原标注"安全门打开"，PDF 确认为"示教器紧急停止" → 已修复
- DCS 关节位置检查最大数 40 → PDF 未直接命中 → NEEDS REVIEW
- CR 系列退避力限值 300N → PDF 未直接命中 → NEEDS REVIEW
