# RAG 质量分析与 Bad Case 诊断

## QA Case 收集流程

从 `rag_query_log.db` 的 `query_log` 表提取真实查询，按 top_score 分三档：

| 等级 | top_score 范围 | 含义 |
|------|---------------|------|
| Good | ≥ 0.80 | 检索命中，答案可靠 |
| Medium | 0.60 ~ 0.80 | 部分命中，可能需要补充文档 |
| Bad | < 0.60 | 未命中或严重偏题 |

查询来源区分：`channel_name` 含 "feishu" = 飞书群聊，"mimo" = API 测试，"" = 空（测试/未标记）。

## Bad Case 根因分类

| 类别 | 典型特征 | 例子 | 改进方向 |
|------|---------|------|---------|
| A. 知识库无对应内容 | 多次查询同类问题都 <0.50 | 协作机器人、激光切割、CNC加工 | 补充文档 |
| B. 对比/综合型问题 | 单品牌文档有，跨品牌/跨协议对比无 | "FANUC vs KUKA"、"CC-Link vs EtherNet/IP 优缺点" | 需要「对比总结」专题文档 |
| C. 无效/重复测试 | 非 FANUC 代码反复查询 | svgn-382、svgn-381 | 标记为无效，不计入质量指标 |
| D. 模糊/口语化查询 | 用词与手册术语不同 | "法那科M900-330L" → 应为 "M-900IB/330L" | 查询规范化层（别名映射） |
| E. 软件版本/固件号 | 知识库不含具体版本号 | "V7.30P" — 全库 0 命中 | 检查是否有对应手册未导入，或修正测试用例 |

## 审计测试用例诊断流程

当日巡检报告出现失败项时，按以下步骤定位：

### Step 1: 复现检索

```bash
cd /home/hp && source /home/hp/mkdocs-env/bin/activate
CUDA_VISIBLE_DEVICES="" python3 -c "
import rag_core
results = rag_core.retrieve('<失败的查询文本>')
for i, r in enumerate(results[:8]):
    print(f'  [{i}] score={r[\"score\"]:.3f} src={r.get(\"source\",\"\")}')
" 2>/dev/null | grep -v "Warning\|Loading\|嵌入\|已加载\|huggingface\|tokenizer"
```

### Step 2: 检查关键词命中

在 Step 1 基础上，逐条检查 top-8 结果是否包含测试期望的关键词：

```python
for i, r in enumerate(results[:8]):
    text = r['text']
    hits = [kw for kw in expected_keywords if kw in text]
    print(f'  [{i}] score={r["score"]:.3f} hits={hits}')
```

### Step 3: 拆分查询验证

把组合查询拆成独立关键词分别检索，判断哪个词是瓶颈：

- 高分关键词（>0.90）：知识库有丰富内容，不是问题
- 低分/零命中关键词：在知识库中搜索是否存在

```bash
# 在提取的文本中搜索
search_files(pattern="缺失关键词", path="/mnt/d/知识库wiki", file_glob="*.json", limit=5)
```

### Step 4: 判定根因

| 情况 | 判定 | 处理 |
|------|------|------|
| 关键词在 top-8 中命中但测试仍报失败 | 测试用例逻辑问题 | 检查测试的 top-N 检查范围 |
| 关键词全库不存在 | 知识库缺失或测试用例设计问题 | 确认是否有对应手册未导入 |
| 单独搜关键词高分，组合查询低分 | 查询被稀释 | 考虑优化查询拆分策略 |

### 典型案例：V2-044 高惯量模式

- 查询: `"FANUC机器人高惯量模式V7.30P"`
- 单搜 `"高惯量模式"` → 0.968，命中 5+ 文档
- 单搜 `"V7.30P"` → 全库 0 命中（chunks_filtered.json 也没有）
- 组合查询 → 0.500（被 V7.30P 稀释）
- **判定**: 测试用例设计问题，V7.30P 是固件版本号不在知识库中，"高惯量模式"检索本身没问题

## 输出格式

分析报告用 `.md` 格式，包含：
1. 总览表（总查询数、Good/Medium/Bad 占比）
2. Good Case 规律总结（哪些类型查询稳定高分）
3. Bad Case 分类表（根因、改进方向）
4. 改进优先级（P0/P1/P2）
5. 统计摘要（ASCII bar chart）

路径建议: 放在 `C:\Users\hp\Desktop\自研\rag-docs\` 下，方便维护。
