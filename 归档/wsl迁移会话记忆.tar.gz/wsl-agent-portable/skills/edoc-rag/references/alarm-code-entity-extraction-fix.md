# Alarm Code Entity Extraction & Retrieval Fix (2026-06-13)

## 问题

MEMO-001 报警代码在知识库中有 2 条文档（B-83284CM-1_04_01.PDF、FANUC_spot+说明书.pdf），但检索时：
- 向量检索返回其他 MEMO 报警（MEMO-093/016/148）分数 0.976
- MEMO-001 精确匹配排在第 5 条，分数只有 0.500

## 根因分析

### 1. 实体提取缺失

`rag_phase1_entity_extract.py` 的 `FANUC_ALARM_PREFIXES` 不含 `'MEMO'`。

导致：
- `entity_alarms` 元数据为空 `[]`
- `_entity_alarm_index` 不包含 MEMO-001
- `_entity_alarm_search()` 找不到精确匹配

验证方法：
```python
# 检查元数据
collection.get(where_document={'$contains': 'MEMO-001'}, limit=3, include=['metadatas'])
# 返回 entity_alarms: []（修复前）
# 返回 entity_alarms: ["MEMO-001", ...]（修复后）
```

### 2. RRF 融合降低精确匹配分数

RRF 分数 = sum(1/(k+rank_i))，基于排名而非原始相似度。

| 来源 | 排名 | 原始分数 | RRF 分数 |
|------|------|---------|---------|
| 向量检索 MEMO-093 | #1 | 0.729→0.976 | 高 |
| 向量检索 MEMO-001 | #3 | 0.716 | 0.500 |

即使精确匹配在向量检索中排第 3，RRF 融合后分数也会大幅下降。

## 修复

### 代码修改

1. **`rag_phase1_entity_extract.py`** — 添加 `'MEMO'` 到 `FANUC_ALARM_PREFIXES`
2. **`rag_core.py`** — 排序后增加报警代码精确匹配加分（+0.30，上限 0.95）

### 元数据更新

运行实体提取脚本更新所有 chunks：
```bash
cd /home/hp/self-grow-wiki
source /home/hp/mkdocs-env/bin/activate
CUDA_VISIBLE_DEVICES="" python3 rag_phase1_entity_extract.py
# 处理 ~200,715 chunks，约 30-50 分钟
```

### 效果

| 指标 | 修复前 | 修复后 |
|------|--------|--------|
| MEMO-001 排名 | #5 (0.500) | #4 (0.950), #5 (0.800) |
| entity_alarms | `[]` | `["MEMO-001", ...]` |
| 实体索引 | 不含 MEMO-001 | 含 MEMO-001 |

## 验证

```python
import rag_core
rag_core._entity_index_built = False  # 强制重建缓存
result = rag_core.retrieve('MEMO-001 系统软件内部错误', top_k=5)
# 第 4-5 条应包含 MEMO-001，score >= 0.80
```

## 已知完整前缀列表

见 `edoc-rag` SKILL.md 的「报警代码实体提取陷阱」章节。

## MATE-001 特殊情况

MATE-001 在整个知识库和原始 PDF 中都不存在。`MATE` 前缀已在列表中，但没有文档包含 MATE-001 报警代码。这可能是：
- 应用层报警（HandlingTool/ArcTool 等）
- 非标准 FANUC 报警
- 需要从其他来源补充
