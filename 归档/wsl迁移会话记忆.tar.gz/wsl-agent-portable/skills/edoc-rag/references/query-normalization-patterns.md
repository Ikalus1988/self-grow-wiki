# 查询规范化模式 (2026-06-15)

## 架构

`_normalize_query()` → `expand_query()` 两级处理：
1. **规范化**（确定性变换）：中文别名→标准术语，型号补连字符，报警码大写
2. **扩展**（同义词追加）：从 synonyms.json 加载同义词，追加到查询末尾

## 已实现的规范化规则

| 规则 | 正则/逻辑 | 示例 |
|------|----------|------|
| 中文别名 | `_CHINESE_ALIASES` dict + 预编译 re.I | 法那科→FANUC |
| 别名后补空格 | `re.sub(r'(FANUC)([A-Z0-9])', r'\1 \2')` | FANUCM-900→FANUC M-900 |
| CR系列 | `re.sub(r'CR(\d{1,2})(i[A-Z]?)')` | CR35iA→CR-35iA |
| 型号连字符 | `re.sub(r'([A-Z]{1,2})(\d{2,4})')` | M900→M-900 |
| 报警码 | `re.sub(r'([a-zA-Z]{2,6})(\d{3,6})')` | SRVO023→SRVO-023 |
| CC-Link | `re.sub(r'CC\s*-?\s*Link')` | CCLink→CC-Link |
| R-30iB | `re.sub(r'R\s*30i([AB])')` | R30iB→R-30iB |
| 英中粘连 | `re.sub(r'([A-Za-z/]{4,})([\u4e00-\u9fff])')` | blown排查→blown 排查 |
| FANUC+中文 | `re.sub(r'(FANUC)\s+(机器人)')` | 保持紧凑 |
| 负载→型号 | `_expand_load_to_model()` | 360→M-900iB/360L |

## synonyms.json 条目（截至 2026-06-15）

共 49 条目，关键新增：
- 协作机器人(cobot/CR系列/协同作业)
- DCS(双检安全/safety speed/安全区域)
- 工具坐标系(TCP/UTOOL/tool frame)
- 干伸长度(stick-out/焊丝伸出量)
- 起弧(arc start/引弧) / 收弧(arc end/熄弧)
- 法那科→FANUC / 法兰克→FANUC

## 编码陷阱

### Pattern.sub() 不接受 flags
```python
# ❌ 编译后再传 flags → TypeError
re_compiled = re.compile(pattern)
re_compiled.sub(repl, string, flags=re.I)

# ✅ 编译时加 flags
re_compiled = re.compile(pattern, re.I)
re_compiled.sub(repl, string)
```

### 中文别名替换后补空格
中文3字符"法那科"替换为英文5字符"FANUC"后，如果后面紧跟英文/数字（如M900），会产生粘连"FANUCM-900"。需要额外一条正则补空格。
