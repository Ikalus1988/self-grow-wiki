# FANUC MH Valves 物料搬运阀配置界面 + S# 变量

> 抓手物料搬运阀的输入信号配置界面，对应的变量 **S#（阀门号/抓手号）** 的完整参考资料。
> 案例来源：用户问"抓手物料搬运阀里边的输入信号配置界面，有无对应的变量"（2026-06-22 检索）。

## 1. MH Valves 画面的位置

```
MENU（菜单）→ I/O（输入/输出）→ MH Valves（MH 阀门）
```

来源：FANUC 报警代码手册 + Material Handling 功能说明书。
- B-83284EN-1/07（报警代码手册，英文）
- B-83124CM-6/01（物料搬运功能说明书，中文）
- 小米《FANUC机器人小米标准软件使用手册_v19.pdf》第 61 页 8.3 节

## 2. MH Valves 界面要配置的输入信号

每个阀（每个抓手）配置两类 DI 信号：

| 字段 | 含义 | 典型用途 |
|------|------|---------|
| **Clamp Inputs** | 夹紧输入 | 抓手夹紧/松开到位检测（气缸伸出/缩回反馈） |
| **Part Present Inputs** | 零件存在输入 | 抓手上是否有零件检测（接近开关/光电） |

具体画面字段：
- **S#**：阀门号（抓手号），1~N，每个阀对应一行
- **DI[x]**：该阀配置的输入信号编号（在画面"IN PT"列）

## 3. S# 变量的语义

**S# = 阀门号 / 抓手号**，范围 1~N，每个抓手对应一个 S#。

S# 在以下场景出现：
- MH Valves 画面行号
- 报警代码中的 `%s` 占位符实际值（MHND-234/235 中的 `Valve %s: Manual grip part`）
- 程序中引用抓手时作为索引

**关键报警（确认 S# 语义）：**

| 报警 | 含义 | 对策 |
|------|------|------|
| **MHND-233** | TP hardkey macros are in use | 等待当前宏完成 |
| **MHND-234** | Valve %s: Manual grip part | 信息提示（手动抓零件） |
| **MHND-235** | Valve %s: Manual release | 信息提示（手动释放） |
| **MHND-236** | Error: Valve is not setup. 原因：**阀门信号数（S#）不能为零** | 去 `MENU → I/O → MH Valves` 配置夹具信号 |
| **MHND-237** | Error: Clamp is not setup. 原因：**钳位信号数（S#）不能为零** | 配置 Clamp Inputs |

## 4. MH Valves 配置的信号如何被消费

小米《FANUC机器人小米标准软件使用手册_v19.pdf》MI03_GRP 概述：

> "MI03_GRP 是搬运应用，用户通过 CALL 来实现该程序运行，实现的功能是获取系统 **MH Valves 界面中的 PartPresent 和 CylinderOpen/Close 的 DI 信号**，来映射给 DO 信号，发给 PLC。"

数据流：
```
MH Valves 配的 DI (PartPresent / CylinderOpen/Close)
    ↓ 后台监控程序
DO 信号（按小米《车身机器人组态标准》映射，无需手动配）
    ↓
发给 PLC
```

TP 程序调用 `CALL MI03_GRP(ActiveGrip, GripNum=1)` 即可激活。`GripNum` 变化时 DI→DO 映射地址自动切换。

## 5. 检索策略复盘（如何找到这个界面）

用户口语："抓手物料搬运阀里边的输入信号配置界面，有无对应的变量"。

**第一轮语义检索失败**：top-1 score=0.5，返回的是 TS-0002936 Robot Specifications（特斯拉规范文档）和 Operation Manual（施胶机），与 FANUC MH Valves 完全无关。

**桥接策略**：
1. 改用 FANUC 报警前缀 + "not setup" 模式查询：`MHND-236 valve not setup`
2. 直接命中 FANUC 报警代码手册 → 报警对策明确给出 `MENU → I/O → MH Valves` 路径 + `S#` 变量名
3. 用 "MH Valves" + "Clamp Inputs" 二次验证，召回 B-83124CM-6 / B-83284EN-1-07

**关键经验**：
- 用户口语（"抓手物料搬运阀"）≠ FANUC 术语（"MH Valves"）
- **报警代码"对策"段 = UI 路径 + 变量名** 的稳定模式
- 关键参考文档可能在 `/mnt/c/Users/hp/Downloads/待入库/` 而非 `/mnt/d/知识库wiki/`，但 RAG 已索引

## 6. 相关 PDF 路径

| 文档 | 路径 | 关键章节 |
|------|------|---------|
| FANUC 报警代码手册（中文） | `/mnt/d/知识库wiki/.../FANUC报警代码.pdf` | MHND-233~237 |
| FANUC 报警代码手册（英文） | `/mnt/d/知识库wiki/07_机器人/FANUC PLUS 最新/PDF/B-83284EN-1_08_01.PDF` | **MHND-233~237 完整定义（已 grep 验证）。注意：本地实际版本是 `_08_01`,不是答案中曾误用的 `_07_01`** |
| 物料搬运功能说明书 | `/mnt/d/知识库wiki/.../B-83124CM-6/01` ⚠️ **本地未收录**（FANUC 合法编号,但 wiki 目录里无此文件,引用合理性无法本地核验） | MH Valves 章节 |
| 小米标准软件使用手册 v19 | `/mnt/c/Users/hp/Downloads/待入库/FANUC机器人小米标准软件使用手册_v19.pdf` | **第 61 页 8.3 节**(印刷页号,非 PDF 物理页号 — 详见下方 §9) |
| Jaguar Land Rover MH 编程标准 | `/mnt/d/知识库wiki/...[4] FANUC's Standard Manual Handling Programming(Version 5.0).pdf` | Appendix 3-5（GR_1_60_REST / WORK 程序示例） |
| **FANUC 系统变量字典(中文)** | `/mnt/c/Users/hp/Downloads/待入库/发那科机器人系统变量清单 V1.0.docx` | 28158 行,全 FANUC `$xxx` 变量说明 |
| **FANUC 系统变量字典(英文)** | `/mnt/c/Users/hp/Downloads/待入库/系统变量表.pdf` | 20626 行,英文原版 |

## 7. ⚠️ S# 不是系统变量,别在系统变量字典里找

**用户曾尝试把"变量"锁定到 FANUC 系统变量字典,结果发现匹配不上**。根因是 **S# 是 TP 教学画面的列名(UI 字段),不是 `$xxx` 系统变量**。

| 概念 | 实际位置 | 在系统变量字典中？ |
|------|---------|------------------|
| **S#**（阀门号/抓手号） | TP 画面 `MENU → I/O → MH Valves` 的行号 | ❌ **不在任何系统变量字典中** |
| **DI[x]** / **DO[x]**（输入/输出信号） | TP 程序里直接引用,后台绑定到 `$DIN[...]` / `$DOUT[...]` | ✅ 字典有 `$DIN[x]` / `$DOUT[x]` 等基础变量,但和"阀门号"无命名对应 |
| 假设的 `$MH_VALVE[1..N].$xxx` | （不存在） | ❌ FANUC 没把 MH Valves 配置暴露成系统变量 |

**为什么 S# 不在系统变量字典里**：MHND-236 的 Cause 字段说 "The valve signal number (S#) can not be zero" — "valve signal number" 是个 **用户界面概念**,运行时由 FANUC 内部专用 I/O 流程使用,不通过 `$xxx` 系统变量访问。FANUC 中这类"画面字段 ≠ 系统变量"的情况很常见（碰撞检测灵敏度 `$COLGUARD_LIM` 是系统变量,但 DCS 密码、UI 阈值等都是画面字段）。

**如果用户问"这个变量在系统变量表里怎么查"**：
1. **先识别是不是系统变量**：FANUC 手册原文里变量名前是否带 `$`,且在 TP 程序中可写/读。带 `$` 才是系统变量。
2. **系统变量字典查不到 ≠ 手册错**：UI 列名 / 画面字段 / 报警占位符 都不会出现在 `$xxx` 字典中。
3. **正确的引用源**：报警代码 → B-83284EN-1；UI 画面字段 → B-83124CM-6（功能说明）；系统变量 → V1.0.docx / 系统变量表.pdf。

**系统变量字典中真正和"夹具/抓手"相关的少量条目**（2026-06-22 grep 验证,可作为延伸阅读）：
- `发那科机器人系统变量清单 V1.0.docx` 行 16860-16867：`$PARAM_GROUP[1].$master_pos` — "母版夹具确定的机器人母版位置"（mastering 校准,非 MH Valves 用）
- `发那科机器人系统变量清单 V1.0.docx` 行 26809：`$TORQCTRL.$grp_stt[1]` — "扭矩关闭(用于夹具掌握)"（扭矩控制功能,非 MH Valves 用）
- `系统变量表.pdf` 行 4596：`$FQINT_SETUP[1].$fast_on` 描述中提到 "flow enable valve or an applicator trigger"（流体/喷涂阀,**非物料搬运阀**）

**反模式（严禁）**：
- ❌ 在答案里把 S# 写成 `$S#` 或 `$MH_VALVE` — 没有这个变量,会被群里的熟练技术员抓出来
- ❌ 强行引用最近的 `$master_pos` chunk 当 MH Valves 变量出处 — 内容是 mastering 校准,答非所问
- ❌ 告诉用户"系统变量字典里有这个变量" — 实际没有

## 8. 引用页码验证陷阱：FANUC 手册"第 X 页" ≠ `pdftotext -f X`

**陷阱**：用户/答案引用"小米手册第 61 页 8.3 节",**不能直接用 `pdftotext -f 61 -l 65`**。FANUC 手册普遍存在 5-15 页封面/目录偏移,文档第 61 页 = PDF 物理页 ~71。

**正确做法**（2026-06-22 验证）：
```bash
# 1. 全文提取后 grep 章节标题
pdftotext '/path/to/manual.pdf' - | grep -nE "8\.3 MH Valves 配置"

# 2. 看 grep 输出里的"61 / 165"印刷页号（不是 PDF 物理页号）
# 3. 如需精确提取该页内容,再计算偏移 -f N
```

**反模式**：
- ❌ 用户说"第 X 页" → 直接 `pdftotext -f X -l X+5` — 大概率抓到上一章/下一章
- ❌ 不验证就引用"出处:第 61 页" — 群里会有人翻 PDF 抓包

## 9. 报警码引用纪律：MHND-xxx 在 B-83284EN-1,不在 B-83124CM-6

**坑**：2026-06-22 答案中同时引用 B-83284EN-1/07 + B-83124CM-6/01 作为 MHND-234/235/236/237 的出处。**B-83124CM-6/01 是物料搬运编程手册,不含报警码定义**。报警码完整定义只在 B-83284EN-1 系列。

**正确分类**：
| 引用类型 | 来源手册 |
|---------|---------|
| 报警码定义（MHND-/SRVO-/SYST- 等） | **B-83284EN-1** 报警代码手册 |
| 报警码对策里的 UI 路径（"Select MENU → I/O → MH Valves"） | **B-83284EN-1** 报警代码手册的 Remedy 字段 |
| 画面字段详细说明 / 信号连接示例 | **B-83124CM-6** Material Handling 编程手册 |
| MI03_GRP 等标准应用功能 | 小米《FANUC机器人小米标准软件使用手册_v19.pdf》第 59 页起 |

**引用写法模板**：
- ✅ "MHND-236 出处：B-83284EN-1_08_01.PDF, Cause: 'The valve signal number (S#) can not be zero', Remedy: 'Select MENU, I/O, MH Valves to setup the gripper signals'"
- ✅ "MH Valves 画面字段说明：B-83124CM-6（本地未收录,引用合理性无法本地核验）"
- ❌ "MHND-236 出处：B-83124CM-6" — 错,这个手册里没这个报警

## 10. 类似应用信号前缀（待扩展）

未来遇到其他 UI 画面查询时，按此模式桥接：

| 主题 | 报警前缀 | 预期 UI 路径 |
|------|---------|------------|
| 物料搬运 / 抓手 | MHND- | `MENU → I/O → MH Valves` |
| 点焊 | SPOT- | `MENU → I/O → Spot Equip` |
| 弧焊 | ARC- | `MENU → I/O → Arc Tool` |
| 伺服 / 安全 | SRVO- / PRIO- | `MENU → SYSTEM → DCS` 等 |
| 系统 | SYST- | `MENU → SYSTEM` |