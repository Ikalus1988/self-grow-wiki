# 跨语言 RAG 检索：双语 summary chunk 模式

> 解决"入库了英文/日文 FANUC 官方手册，但用户中文口语查询召不回"的问题。2026-06-22 由 RAG 助手测试群 MH Valves / 物料搬运阀问题触发，是 BM25 关键词召回 + 向量召回结构性缺陷的工程化补丁。

## 痛点

用户问"抓手物料搬运阀 输入信号 配置"，但新导入的 FANUC 官方手册 `MAROBHT8203131E REV C Material Handling Option` 是英文。三路验证全失败：

| 通道 | "抓手" | "物料搬运" | "MHND-236" | "Tooling Valve Signals" |
|------|--------|----------|------------|------------------------|
| BM25 单独 top-200 | **0 命中** | **0 命中** | **0 命中** | 命中 |
| 向量单独 top-20 | 0 | 0 | 0 | sim 0.631 命中 |
| 内容 grep（OCR 后 markdown） | 0 | 0 | 0 | 命中 |

**根因**：
- BM25 用 jieba 切词，文档是英文 → "抓手" 这类中文 token 在 BM25 索引里 0 词频
- 向量空间里"抓手"和"Tooling/gripper"虽然在 bge-base-zh-v1.5 多语言空间上有距离，但不是 0
- 唯一被召回到的查询是英文术语 (`Tooling Valve Signals`, `S# valve signal number`)，但用户的真实查询是中文口语

## 解法：双语 summary chunk（锚定 chunk）

**核心思路**：除常规 recursive chunking 外，**额外插入一个合成的双语术语对照 summary chunk**，作为该文档的"语义锚点"。这个 chunk 长度 800-1500 字符，包含：

1. 文档标题（中英双语）
2. 中英术语对照表（关键技术名词）
3. 用户高频中文问题的可能表述（按这个手册能回答什么）
4. 文档章节结构（章节标题中英并列）
5. 关联的 FANUC 报警代码前缀

**为什么有效**：
- BM25 切词后，中文 token 全部命中 summary chunk → BM25 召回成功
- 向量空间里 summary 含完整文档语义概要 → 向量召回分数高
- summary chunk 的 `chunk_index = -1` 加 `is_summary = True` metadata 标记，UI 显示时可识别为锚定 chunk

## 真实案例（2026-06-22 验证）

### 入库前（仅 recursive chunk）

| 查询 | BM25 top-200 | 向量 top-20 | retrieve() |
|------|------------|-------------|-----------|
| `抓手物料搬运阀 输入信号 配置` | 0 | 0 | ❌ NOT IN TOP-15 |
| `抓手 物料搬运 输入信号 变量` | 0 | 1（低 sim） | ❌ NOT IN TOP-15 |
| `MH Valves 阀门 配置` | 0 | 0 | ❌ NOT IN TOP-15 |

### 入库双语 summary chunk 后

| 查询 | retrieve() 排名 | 分数 |
|------|----------------|------|
| `抓手物料搬运阀 输入信号 配置` | **#3** | 0.500 |
| `抓手 物料搬运 输入信号 变量` | **#1** | **0.980** |
| `MH Valves 阀门 配置` | **#4** | 0.492 |
| `Tooling Valve Signals` | **#1** | 0.980 |
| `S# valve signal number` | **#1** | 0.939 |
| `Clamp Input Part Present Input` | **#1** | 0.980 |

中文短 query 从 ❌ NOT IN TOP-15 跳到 #1 0.980 — 这是结构性解锁。

## 工作脚本（参考，可直接复用）

```python
#!/usr/bin/env python3
"""Add a new PDF/MD to RAG vector DB with bilingual summary chunk."""
import os, hashlib, re, shutil
import chromadb
from langchain_text_splitters import RecursiveCharacterTextSplitter
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

CHROMA_DIR = "/home/hp/rag_chromadb"
COLLECTION_NAME = "wiki_docs"
CHUNK_SIZE = 800
CHUNK_OVERLAP = 100

# === 配置 ===
SOURCE = "/path/to/source.pdf"  # 实际源文件路径（影响 metadata.source）
FILENAME = "..."  # 用于显示的友好文件名
CATEGORY = "07_机器人/FANUC PLUS 最新"  # 一级分类
SUBCATEGORY = "..."  # 二级分类

# === 双语 summary chunk（核心：手工写，不要自动化）===
SUMMARY = (
    "FANUC Material Handling Option Manual 物料搬运阀官方手册 "
    "(FANUC 官方手册 MAROBHT8203131E REV C)\n\n"
    "适用控制器:FANUC R-30iA / R-30iB / R-30iB Plus 系列\n"
    "中文术语对照(用于跨语言检索):\n"
    "- 抓手 = gripper / Tooling\n"
    "- 物料搬运阀 = Material Handling Valve / Tooling Valve / MH Valve\n"
    "- 输入信号 = Input Signal / DI signal\n"
    "- 夹紧输入 = Clamp Input\n"
    "- 零件存在输入 = Part Present Input / Part On Board\n"
    "- 阀门号 / 阀门信号号 = S# = Valve Signal Number = Tooling Valve Number\n"
    "- 抓零件 = Grip Part / Pick\n"
    "- 放零件 = Release Part\n"
    "- 真空开/关 = Vacuum ON / Vacuum OFF\n"
    "- 吹净 = BlowOff\n"
    "- MH Valves 画面 / Tooling Valves 画面 = 配置界面\n"
    "- 报警代码前缀 = MHND\n\n"
    "用户常见提问(命中本手册):\n"
    "- 抓手物料搬运阀里边的输入信号配置界面,有无对应的变量\n"
    "- MH Valves 画面在哪里\n"
    "- MHND 报警 S# 不能为零怎么解决\n"
    "- Clamp Input 和 Part Present Input 怎么配\n"
    "- Tooling Valve Signals 设置\n\n"
    "章节结构:\n"
    "- Chapter 15 MATERIAL HANDLING OPTION\n"
    "- 15.1 OVERVIEW\n"
    "- 15.2 SETTING UP THE MATERIAL HANDLING TOOLS\n"
    "  - 15.2.3 Setting Up Tooling Valves\n"
    "  - 15.2.4 Setting Up Tooling Valve Signals\n"
    "- 15.4 MATERIAL HANDLING VALVE MACRO PROGRAMS\n"
    "  - 15.4.4 Part Present\n"
    "- 对应报警手册: B-83284EN-1/07 (MHND-234 / 235 / 236 / 237)"
)

# === 主流程 ===
# 1. 读源（如果 PDF 是扫描版，先用 pymupdf4llm 提取 markdown）
#    pymupdf4llm.to_markdown() 在文本层为空时自动回退到 Tesseract OCR
import pymupdf4llm
text = pymupdf4llm.to_markdown(SOURCE)
# 可选：清理 OCR 噪音（picture text dumps）
text = re.sub(r"\*\*==> picture \[[^\]]+\] intentionally omitted <==\*\*\s*", "", text)
text = re.sub(r"\*\*----- Start of picture text -----\*\*<br>.*?\*\*----- End of picture text -----\*\*<br>\s*",
              "", text, flags=re.DOTALL)
text = re.sub(r"\n{3,}", "\n\n", text)

# 2. 切块
splitter = RecursiveCharacterTextSplitter(
    chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP,
    separators=["\n\n", "\n", "。", "；", " ", ""],
)
src_hash = hashlib.md5(SOURCE.encode()).hexdigest()
body_chunks = splitter.split_text(text)

# 3. 构造 chunk 列表（summary 在前）
final = [{"id": f"{src_hash}_summary", "text": SUMMARY,
          "metadata": {"source": SOURCE, "filename": FILENAME,
                       "category": CATEGORY, "subcategory": SUBCATEGORY,
                       "file_type": "pdf", "chunk_index": -1, "is_summary": True,
                       "total_chunks": len(body_chunks) + 1}}]
for j, c in enumerate(body_chunks):
    final.append({"id": f"{src_hash}_{j}", "text": c,
                  "metadata": {"source": SOURCE, "filename": FILENAME,
                               "category": CATEGORY, "subcategory": SUBCATEGORY,
                               "file_type": "pdf", "chunk_index": j,
                               "is_summary": False, "total_chunks": len(body_chunks) + 1}})

# 4. 入库
os.environ["HF_HUB_OFFLINE"] = "1"
client = chromadb.PersistentClient(path=CHROMA_DIR)
ef = SentenceTransformerEmbeddingFunction(
    model_name="BAAI/bge-base-zh-v1.5", device="cpu", trust_remote_code=False)
coll = client.get_collection(name=COLLECTION_NAME, embedding_function=ef)

# 幂等：先删旧 chunks
existing = set(coll.get(include=[]).get("ids", []))
stale = [c["id"] for c in final if c["id"] in existing]
if stale:
    coll.delete(ids=stale)
    print(f"Removed {len(stale)} stale chunks")
remaining = set(coll.get(include=[]).get("ids", []))
to_add = [c for c in final if c["id"] not in remaining]

# 批量插入
for start in range(0, len(to_add), 32):
    batch = to_add[start:start + 32]
    coll.add(ids=[c["id"] for c in batch],
             documents=[c["text"] for c in batch],
             metadatas=[c["metadata"] for c in batch])
    print(f"  [{min(start + 32, len(to_add))}/{len(to_add)}]")

# 5. **关键**：必须删除 BM25 缓存让新 chunk 被索引
#    不删的话新文档在 retrieve() 里 BM25 通道为 0，RRF 融合压到 0.500
from rag_core import BM25_INDEX_PATH
if BM25_INDEX_PATH.exists():
    BM25_INDEX_PATH.unlink()
    print(f"BM25 cache invalidated: {BM25_INDEX_PATH}")

# 6. 验证（手动触发 BM25 重建，约 2-5 分钟）
# from rag_core import _bm25_index
# _bm25_index._ensure_index()  # 可选，下次 retrieve() 自动重建
```

## 何时需要这个补丁

| 场景 | 是否需要双语 summary chunk |
|------|---------------------------|
| 英文 FANUC 官方手册（MAROBHTxxxxE, B-83xxxEN 等）入库 | **必须** |
| 日文 FANUC 手册（B-83xxxJA）入库 | **必须** |
| 中文 FANUC 手册（小米/标准）入库 | 不必须（已是中文） |
| 第三方英文文档（JLR/GM 标准）入库 | **必须** |
| 用户专题 md 文档入库 | 不必须（已用中文写） |

**判断规则**：源文档主体语言 ≠ 用户查询主流语言 → 必须双语 summary。

## 维护成本

写一个双语 summary chunk 的人工成本：
- 中英术语对照：~5 分钟（视文档复杂度）
- 用户常见提问列表：~5 分钟（看群里历史问题或询问用户）
- 章节结构中英并列：~5 分钟

总计 ~15 分钟/文档。考虑到它能解锁整本手册的可检索性，性价比极高。

## 与其他规则的协同

| 已有规则 | 协同方式 |
|---------|---------|
| BM25 缓存必须重建（新文档入库后） | 双语 summary chunk 也必须走这个流程 |
| HF_HUB_OFFLINE=1（避免 httpx 崩溃） | 同样适用 |
| 库内文件名带 "FANUC" 不等于 FANUC 官方（标签污染陷阱） | summary 里应**主动标注**真实来源（如 "JLR PAN Projects 内部标准"）防止被误读为 FANUC 官方 |
| 召回失败 3 路归因法 | 双语 summary chunk 是"3 路全 0 命中"场景下的标准对策之一 |

## 反模式

- ❌ **自动化生成 summary**：用 LLM 翻译/扩写 summary 会引入幻觉，丢失原文档的精确表述。手工写最安全。
- ❌ **summary 只写中文**：如果用户用英文查询（如内部技术员的英文搜索），仍会召不回。必须双语。
- ❌ **summary 过长（>2000 字）**：会稀释关键术语密度，反而不利于 BM25 命中。控制在 800-1500 字。
- ❌ **多个文档共用一个 summary**：每个文档的 summary 必须手工写，因为它包含该文档的**专属术语映射和章节结构**。
- ❌ **忘删 BM25 缓存**：新文档入库后必须 `BM25_INDEX_PATH.unlink()`，否则 BM25 通道 0 命中，summary chunk 也救不了你。

## 关联参考

- `new-doc-import-workflow.md` — 通用导入流程（本参考是其跨语言特化版本）
- `bm25-rebuild-and-md-import.md` — BM25 缓存重建细节
- `references/honest-citation-taxonomy.md` — 答案引用写法（配合本参考使用）