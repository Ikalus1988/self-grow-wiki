---
name: wxauto-bot-feature-add
description: >
  给 wxauto 微信机器人新增功能特性：添加关键词触发器、新增 API 端点、
  加群聊@回复、异步线程池任务。当用户要求给微信机器人加新功能时使用。
license: MIT
---

# WxAuto 微信机器人功能扩展

## 项目路径
- bot 主代码 v7 (WSL): `/home/hp/self-grow-wiki/wxauto_bot/bot.py`（当前主力，GetListenMessage + 窗口激活）
- bot 旧版 (WSL): `/home/hp/self-grow-wiki/wxauto_bot.py`（GetAllNewMessage，已弃用）
- bot 部署 (Windows): `C:\Users\hp\Desktop\自研\RAG助手测试记录\bot.py`
- RAG API (WSL): `/home/hp/self-grow-wiki/rag_api.py`
- 测试日志: `C:\Users\hp\Desktop\自研\RAG助手测试记录\wxauto_bot.log`
- 测试问题: `C:\Users\hp\Desktop\自研\RAG助手测试记录\test_issues.md`

## 架构模式

### 三层调用链
```
微信群消息 → wxauto (wxauto_bot.py) → REST API (rag_api.py) → RAG 核心 (rag_core.py)
```

### 新增功能的标准步骤

#### 1. 消息层 (wxauto_bot.py)

**A. 定义触发词**
在文件顶部 `_INTRO_KEYWORDS` 位置附近添加：
```python
_CATALOG_KEYWORDS = {"关键词1", "关键词2"}
```

**B. 调用 API 函数**
在 `call_feedback()` 附近添加：
```python
def call_kb_stats():
    """获取知识库统计."""
    try:
        r = requests.get(f"{RAG_API}/kb/stats", timeout=30)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.error("知识库统计失败: %s", e)
        return None
```

**C. 格式化函数**
```python
def format_kb_catalog(stats):
    """格式化知识库目录."""
```

**D. 线程池任务**
在 `_do_query` / `_do_feedback` 附近添加异步任务：
```python
def _do_catalog(wx, chat_name):
    """在线程池中执行."""
    try:
        stats = call_kb_stats()
        reply = format_kb_catalog(stats)
        wx.SendMsg(reply, who=chat_name)
    except Exception as e:
        log.error("异常: %s", e)
        wx.SendMsg("失败，请稍后重试", who=chat_name)
```

**E. 主循环处理**
在主循环中加触发判断，调用 `_executor.submit(...)`：
```python
if content in _CATALOG_KEYWORDS:
    _executor.submit(_do_catalog, wx, chat_name)
    continue
```

#### 2. API 层 (rag_api.py)

新增端点：
```python
@app.get("/kb/stats")
async def kb_stats():
    try:
        from rag_core import get_kb_stats
        return get_kb_stats()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

### 群聊 @ 消息处理（核心坑点）

**wxauto @消息格式是 `内容@机器人`（@在末尾）**，不是 `@机器人 内容`。
提取内容时取@前面的部分：

```python
has_at = f"@{BOT_NAME}" in content
if has_at:
    before_at = content.split(f"@{BOT_NAME}", 1)[0].strip()
    after_at = content.split(f"@{BOT_NAME}", 1)[-1].strip()
    content = before_at if before_at else after_at
```

**监控群@消息优先级问题**: @消息必须先于监控群判断，否则监控群里的@消息会被当作普通查询，跳过自我介绍/目录等快捷路由：

```python
# 正确顺序：先检测@，再判断监控群
if has_at:
    # 提取内容，走完整路由
elif chat_name in MONITOR_GROUPS:
    # 直接查询
else:
    continue
```

### 群聊 @ 回复模式

- `_do_query()` 新增 `sender` 参数（默认 None）
- 群聊时回复开头加 `f"@{sender}\n{reply}"`
- 主循环中群聊消息传 `sender_name`，私聊不传

```python
if is_group:
    _executor.submit(_do_query, wx, chat_name, content, sender_name)
else:
    _executor.submit(_do_query, wx, chat_name, content)
```

## 关键 API 端点清单

| 端点 | 用途 | 响应 |
|------|------|------|
| `POST /query` | RAG 查询 | `{answer, query_id, ...}` |
| `POST /feedback` | 反馈 | `{status}` |
| `GET /health` | 健康检查 | `{status: "ok"}` |
| `GET /status` | 系统状态 | `{channels, vectors}` |
| `GET /kb/stats` | 知识库统计 | `{total_vectors, total_files, categories, subcategories}` |

## 文件结构

```
/home/hp/
├── wxauto_bot.py    # 主机器人逻辑 — 触发词 / 线程池任务 / 消息循环
├── rag_api.py       # FastAPI — 新增端点在这里加
└── rag_core.py      # 核心逻辑 — 数据库/LLM 调用
```

## 高级用户通道（LLM 自修改）

### 概念
指定单聊用户为"高级用户"，所有消息走 LLM 意图识别通道，支持自然语言修改机器人功能。

### 配置
```python
ADMIN_USERS = ["海关约我去喝茶"]  # 文件顶部
```

### 核心函数 `_do_admin_cmd(wx, chat_name, content)`
1. 读取 `wxauto_bot.py` 前 3000 字符作为上下文
2. 调用 DeepSeek API 解析意图，返回 JSON：
   - `action`: `query` | `modify_config` | `restart` | `help`
   - `code_patch`: unified diff 内容（非空时自动 patch）
   - `reply`: 给用户的回复
3. `action=query` → 转 `_do_query()` 走 RAG
4. `code_patch` 非空 → 写 `/tmp/bot_patch.diff` + `patch` 命令 → 自动重启
5. `action=restart` → 直接重启

### 主循环路由
```python
# 在自我介绍、目录查询、反馈检测之后，普通查询之前
if not is_group and chat_name in ADMIN_USERS:
    _executor.submit(_do_admin_cmd, wx, chat_name, content)
    continue
```

### 跨平台自重启 `_restart_bot()`
```python
def _restart_bot():
    import subprocess
    script = os.path.abspath(__file__)
    python_exe = sys.executable
    if sys.platform == "win32":
        subprocess.Popen(["cmd", "/c", "start", "", python_exe, script],
                         creationflags=subprocess.DETACHED_PROCESS, close_fds=True)
    else:
        subprocess.Popen([python_exe, script],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    os._exit(0)
```
**关键**: `os._exit(0)` 而非 `sys.exit(0)` — 确保进程立即终止不被 wxauto 线程阻塞。

### DeepSeek API 调用
```python
import openai
client = openai.OpenAI(
    api_key=os.environ.get("DEEPSEEK_API_KEY", "sk-0717809a2c05436293af71f7fc0035ea"),
    base_url="https://api.deepseek.com/v1"
)
resp = client.chat.completions.create(model="deepseek-chat", messages=[...], max_tokens=2000, temperature=0)
```

## 踩过的坑

### 窗口名带未读数 (2026-04-28)
群聊窗口名会变成 "群名 (7)" 带未读数，wxauto 找不到 EditControl 控件，报 `Find Control Timeout`。
**解决**: `_normalize_chat_name()` 正则去掉末尾 `(数字)`，所有发消息统一用 `_send_safe(wx, msg, who)` 代替 `wx.SendMsg()`。
反馈匹配也要 normalized：`_last_queries[_normalize_chat_name(chat_name)] = ...`

```python
def _normalize_chat_name(name):
    import re
    return re.sub(r'\s*\(\d+\)\s*$', '', name).strip()

def _send_safe(wx, msg, who):
    clean = _normalize_chat_name(who)
    try:
        wx.SendMsg(msg, who=clean)
    except Exception as e:
        log.warning("发消息失败: %s", e)
        time.sleep(2)
        try:
            wx.SendMsg(msg, who=clean)
        except Exception as e2:
            log.error("发消息重试失败: %s", e2)
```

### 关键词匹配用模糊匹配
`content in _KEYWORDS` 精确匹配会被隐藏字符（如 `\u2005`）干扰导致匹配失败。
**必须**: `any(kw in content for kw in _KEYWORDS)`

### Windows GBK 编码 (2026-04-28)
`open(file, "r")` 在 Windows 默认 GBK，读含中文注释的 .py 文件会报 `UnicodeDecodeError`。
**必须**: `open(file, "r", encoding="utf-8")`

### LLM 返回 markdown 包裹的 JSON
DeepSeek 常返回 ` ```json\n{...}\n``` ` 而非纯 JSON。
- prompt 里要写"只返回 JSON，不要加 markdown 代码块包裹"
- `json.loads()` 失败时做兜底：去掉 ``` 包裹提取纯文本

### admin prompt 应含 `chat` action
闲聊/打招呼不应走 RAG 也不应走代码修改，需要单独的 `action=chat` 直接回复 reply 文本。

### 自我介绍触发词必须覆盖自然表达
"介绍下你自己" 走了 admin 通道（因为不是精确匹配），触发词要加完整：
```python
_INTRO_KEYWORDS |= {"介绍下你自己", "介绍一下自己", "介绍你自己"}
```
且 **自我介绍判断必须在 admin 通道之前**（主循环中的顺序很重要）。

### Windows 部署同步流程
WSL 里改代码后，每次都要手动复制到 Windows：
```powershell
copy \\wsl$\Ubuntu\home\hp\wxauto_bot.py "C:\Users\hp\Desktop\自研\RAG助手测试记录\wxauto_bot.py"
```
启动：`python "C:\Users\hp\Desktop\自研\RAG助手测试记录\wxauto_bot.py"`

## AddListenChat — 私聊消息必须主动监听

wxauto 的 `GetAllNewMessage()` **只能收到当前微信窗口可见的聊天**。如果私聊窗口没打开（或被其他聊天遮挡），消息就收不到。

**必须**在启动时调用 `AddListenChat` 注册要监听的聊天：

```python
for user in ADMIN_USERS:
    try:
        wx.AddListenChat(who=user)
        log.info("已监听高级用户: %s", user)
    except Exception as e:
        log.warning("监听高级用户失败 %s: %s", user, e)
for group in MONITOR_GROUPS:
    try:
        wx.AddListenChat(who=group)
        log.info("已监听监控群: %s", group)
    except Exception as e:
        log.warning("监听群失败 %s: %s", group, e)
```

放在 `main()` 中 `wx = WeChat()` 之后、主循环之前。

## 日志写文件 — 用绝对路径

`logging.FileHandler("wxauto_bot.log")` 用相对路径，文件写到启动目录而非代码目录。
**必须**用绝对路径：

```python
logging.FileHandler(r"C:\Users\hp\Desktop\自研\RAG助手测试记录\wxauto_bot.log", encoding="utf-8")
```

## 注意事项

⚠️ **非阻塞**: 所有耗时操作（查询/反馈/目录）必须用 `_executor.submit()` 提交到线程池，不要阻塞主循环
⚠️ **JSON 序列化**: `wx.SendMsg()` 只支持文本，不支持富文本/卡片
⚠️ **定期检查** `rag_api.py` 的 FastAPI 端点清单，避免端点重复
⚠️ **API 地址**：`RAG_API = "http://localhost:8002"`，主循环前有 `check_health()` 验证连通性
⚠️ **重启安全**: `_restart_bot()` 必须在发送回复消息之后调用，否则用户看不到结果
⚠️ **代码修改**: patch 内容由 LLM 生成，存在风险。只在高级用户通道使用，且 prompt 中明确限制只允许修改配置和功能逻辑
⚠️ **import os**: wxauto_bot.py 最初没有 `import os`，`_do_admin_cmd` 和 `_restart_bot` 都需要它
⚠️ **主循环分支顺序**: 聪明模式 → 自我介绍/目录查询 → 反馈 → admin通道 → 普通查询。聪明模式必须在最前面（它的 answer 设置后跳过后续路由）

## 聪明模式（Smart Mode）— 高级用户专属 LLM 直调

### 概念
高级用户发送特定触发词后，bot 切换到"聪明模式"：后续 N 个问题跳过 RAG，直接调用 DeepSeek API 作答，带对话历史。N 次后自动回落标准 RAG 模式。

### 配置（bot.py 顶部）
```python
_SMART_TRIGGERS = {"使出全力", "整个活", "机灵点"}
_SMART_USER = "海关约我去喝茶"
_smart_remaining = 0  # 剩余聪明模式次数
DEEPSEEK_KEY = os.environ.get("DEEPSEEK_API_KEY", "sk-xxx")  # 优先读环境变量
DEEPSEEK_API = "https://api.deepseek.com/v1/chat/completions"
_smart_history = []  # 聪明模式对话历史
```

### DeepSeek 直调函数
```python
def deepseek_chat(question, history=None):
    messages = [{"role": "system", "content": "你是FANUC机器人技术专家..."}]
    if history:
        messages.extend(history[-6:])  # 最近3轮
    messages.append({"role": "user", "content": question})
    resp = requests.post(DEEPSEEK_API,
        headers={"Authorization": f"Bearer {DEEPSEEK_KEY}"},
        json={"model": "deepseek-chat", "messages": messages,
              "temperature": 0.7, "max_tokens": 2000}, timeout=45)
    return resp.json()["choices"][0]["message"]["content"]
```

### 主循环插入点
在 `question` 提取后、本地关键词处理**之前**：

```python
answer = None  # 初始化

# ── 聪明模式触发/消费 ──
sender_is_admin = (not is_group and chat_name == _SMART_USER) or \
                  (is_group and sender == _SMART_USER)
if sender_is_admin:
    if question in _SMART_TRIGGERS:
        _smart_remaining = 10
        _smart_history.clear()
        answer = f"🔥 聪明模式已开启！后续 {_smart_remaining} 个问题将调用 DeepSeek 直答。"
    elif _smart_remaining > 0:
        _smart_remaining -= 1
        answer = deepseek_chat(question, _smart_history)
        _smart_history.append({"role": "user", "content": question})
        _smart_history.append({"role": "assistant", "content": answer})
        if _smart_remaining == 0:
            answer += "\n\n🔋 聪明模式已耗尽，恢复标准 RAG 模式。"

# 后续 if answer is None: ... 本地关键词/RAG 只在没被聪明模式处理时走
```

### 关键细节
- `answer = None` 初始化必须在聪明模式块**之前**
- 聪明模式**不覆盖** `answer = None` — 后续本地关键词/RAG 检查 `if answer is None` 自动跳过
- 触发词也在 `_SMART_TRIGGERS` 里，不会路由到 RAG
- 群聊中也要判断 `sender == _SMART_USER`（不只是 chat_name）
- `_smart_history` 记录完整对话轮次，传给 DeepSeek 保持上下文

## 测试问题自动记录

`_log_test_issue(category, detail, chat_name, query)` — 写入 `test_issues.md`（与 bot 同目录）。
在查询异常和消息处理异常处调用，格式：带时间戳的 markdown heading + 来源/查询/详情。

```python
TEST_LOG_DIR = r"C:\Users\hp\Desktop\自研\RAG助手测试记录"
```
