# cc-haha Hook Context Injection (2026-05-06 探查记录)

## 背景

当需要"代码级强制知识检索"而非"建议文本"时，cc-haha 的 hook 系统提供了可选的注入点。
本参考记录了 hook 系统的关键类型和模式，供未来实现方案一（pre-turn hook）时使用。

## Hook 事件类型

| 事件 | 触发时机 | 支持 additionalContext? |
|------|---------|----------------------|
| `UserPromptSubmit` | 用户提交提示词后、LLM 推理前 | ✅ z.string().optional() |
| `SessionStart` | 会话开始时 | ✅ z.string().optional() |
| `PreToolUse` | 工具执行前 | ✅ z.string().optional()（via hookSpecificOutput） |
| `PostToolUse` | 工具执行后 | ✅ z.string().optional()（via hookSpecificOutput） |
| `PostToolUseFailure` | 工具执行失败 | ✅ z.string().optional()（via hookSpecificOutput） |
| `SubagentStart` | subagent 开始 | ✅ z.string().optional() |

## Key 类型定义（`src/types/hooks.ts`）

### Hook 响应 schema（`hookSpecificOutput`）

```typescript
// PostToolUse 响应（部分）
z.object({
  hookEventName: z.literal('PostToolUse'),
  additionalContext: z.string().optional(),
  updatedMCPToolOutput: z.unknown().optional(),
})

// UserPromptSubmit 响应
z.object({
  hookEventName: z.literal('UserPromptSubmit'),
  additionalContext: z.string().optional(),
})

// SessionStart 响应
z.object({
  hookEventName: z.literal('SessionStart'),
  additionalContext: z.string().optional(),
  initialUserMessage: z.string().optional(),
  watchPaths: z.array(z.string()).optional(),
})
```

**注意**：`additionalContext` 是 **string**，不是你之前假设的 `{type: 'text', text: ...}` 数组格式（那是 claude-code 的格式）。字符串内容会被直接注入到 LLM 的下一次调用的上下文中。

### HookCallback 注册

```typescript
// 文件: src/services/tools/toolHooks.ts (line 133+)
// additionalContexts（字符串数组）在处理 hook 结果时被收集，
// 并以 'additionalContext' 类型附加到 tool 执行结果中。

// 注册方式:
import { registerHookCallbacks } from '../bootstrap/state.js'

const hook: HookCallback = {
  type: 'callback',
  callback: handleMyHook,
  timeout: 5,
  internal: true, // true = 不在 UI 显示
}

registerHookCallbacks({
  PostToolUse: [
    { matcher: 'Bash', hooks: [hook] },
  ],
  UserPromptSubmit: [
    { matcher: 'Bash', hooks: [hook] },  
  ],
})
```

### 现有 Hook 示例（`src/utils/sessionFileAccessHooks.ts`）

```typescript
async function handleSessionFileAccess(
  input: HookInput,
  _toolUseID: string | null,
  _signal: AbortSignal | undefined,
): Promise<HookJSONOutput> {
  if (input.hook_event_name !== 'PostToolUse') return {}
  // ... analytics logging ...
  return {}
}

export function registerSessionFileAccessHooks(): void {
  const hook: HookCallback = {
    type: 'callback',
    callback: handleSessionFileAccess,
    timeout: 1,
    internal: true,
  }
  registerHookCallbacks({
    PostToolUse: [
      { matcher: FILE_READ_TOOL_NAME, hooks: [hook] },
      { matcher: FILE_EDIT_TOOL_NAME, hooks: [hook] },
      // ... etc
    ],
  })
}
```

### Hook 注册文件

Hook 注册通常在 `src/bootstrap/state.ts` 中被调用。

## 实现方案一的注意事项

如果要实现 pre-turn 自动检索 + 注入：

1. **首选 `UserPromptSubmit` 事件** — 在 LLM 看到用户消息前触发，最干净的注入点
2. **`PostToolUse` 的 `additionalContext` 注入到的是 tool 执行结果** — 不是 LLM 的下一轮输入，需确认行为是否符合预期
3. **searchLessons() 需要 JavaScript 实现** — 不能在 hook 中直接调 Python。选项：
   - (a) `exec(`python3 search_knowledge.py ...`)` — 简单但每次 hook 调用都启动 Python 进程
   - (b) 维护一个本地的 lessons 缓存（git clone + 本地 grep）
   - (c) 通过 HTTP 请求 Hub 的索引
4. **Token 预算** — `additionalContext` 没有长度限制，但注入长文本会影响 LLM 推理质量。建议 top-K=3 加截断
5. **验证需要重启** — skill 文件热更新不需要重启，但 TypeScript 钩子修改需要重新编译/运行
