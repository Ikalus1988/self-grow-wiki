---
name: agentic-context-engineering
description: >
  Agent 上下文工程：SKILL.md 编写规范、渐进式加载、描述触发关键词写法、指令文件分层组织（AGENTS.md/CLAUDE.md风格）、项目上下文最佳实践。当需要创建新 skill、整理项目规则、写 SKILL.md frontmatter、或理解何时用 SOUL vs skill vs memory 时使用。
version: 1.0.0
license: MIT
metadata:
  author: Hermes Agent
  hermes_tags: [context-engineering, skills, agentic, workflow]
  related_skills: [subagent-driven-development, writing-plans, systematic-debugging]
---

# Agentic Context Engineering

## Overview

让 Agent 真正理解项目、可靠执行任务的系统性方法。核心挑战：Agent 不缺能力，缺的是**知道你想要什么**。上下文工程就是解决这个问题的。

**5层架构（低→高优先级）：**
1. 指令系统（SOUL/USER/CLAUDE.md）— 始终加载
2. Skills — 按需渐进加载
3. Hooks — 事件驱动自动触发
4. Subagents — 隔离独立执行
5. MCP — 外部系统工具

---

## 1. Skills 渐进式加载机制

### 三阶段加载

```
1. Discover  (~100 tokens): 仅加载 name + description → 判断是否触发
2. Activate  (<5000 tokens): 加载完整 SKILL.md
3. Execute   (按需): 加载 scripts/、references/、assets/
```

### SKILL.md Frontmatter 规范

```yaml
---
name: skill-name           # 必需：小写+连字符，最多64字符
description: >             # 必需：1024字符内，含触发关键词
  一句话说明用途和触发场景。
  当做XXX时使用此 skill。
license: MIT               # 可选
compatibility: "Requires Node.js 18+"  # 可选
metadata:                  # 可选
  author: team-name
  version: "1.0"
  hermes_tags: [tag1, tag2]
  related_skills: [other-skill]
# Claude Code 扩展字段：
disable-model-invocation: true  # 有副作用的手动触发技能
context: fork                  # 在独立 subagent 中运行
agent: Explore                 # subagent 类型
allowed-tools: Read Grep       # 预批准工具
hooks:                         # Skill 生命周期 Hooks
  PreToolUse:
    - matcher: "Bash"
      hooks:
        - type: command
          command: "./scripts/validate.sh"
---
```

### 触发关键词写法

description 是 Agent 判断是否加载的唯一依据。必须包含：
- **任务类型词**："代码审查"、"部署"、"bug 修复"
- **场景词**："需要创建新 skill"、"编写 SKILL.md"、"按需加载"
- **不要**：写得太泛（"编程相关"）或太窄（只有缩写）

```yaml
# 差：太泛
description: "编程相关任务"

# 差：触发词不够
description: "代码审查"

# 好：触发词明确
description: >
  代码审查专家 skill。当用户要求 review、审查、检视代码变更，
  或需要检查安全/性能/可维护性问题时使用。
  不适用于简单的文本修改。
```

### 渐进式加载示例

```
SKILL.md (主指令，<5000 tokens)
├── references/
│   ├── api.md      # 按需加载
│   └── security-checklist.md
├── scripts/
│   └── validate.sh
└── assets/
    └── template.md
```

**规则：**
- 主 SKILL.md < 500 行（否则 Agent 遵循度下降）
- 详细内容放 references/
- scripts/ 中的脚本需注明用途和调用方式

### 目录结构规范

```
~/.hermes/skills/<name>/      # 用户级（所有项目）
.claude/skills/<name>/        # 项目级

my-skill/
├── SKILL.md           # 必需
├── scripts/           # 可选
├── references/        # 可选
└── assets/            # 可选
```

---

## 2. 项目上下文文件

### 与 Claude Code CLAUDE.md 的对应关系

Hermes Agent 的 SOUL.md/USER.md 对应 Claude Code 的 CLAUDE.md（项目级指令）：

| Claude Code | Hermes Agent | 作用域 |
|-------------|--------------|--------|
| `~/.claude/CLAUDE.md` | `~/.hermes/SOUL.md` | 全局身份 |
| `./CLAUDE.md` | `./SOUL.md` | 项目级 |
| `.claude/rules/` | Skills | 按需加载 |
| Auto Memory | `memory` tool | 跨会话事实 |
| `.claude/agents/` | `delegate_task` | 独立子 Agent |

### AGENTS.md 格式（跨平台通用）

Cursor / Claude Code / VS Code Copilot 均支持 AGENTS.md，是最便携的格式：

```markdown
# AGENTS.md

## Project Overview
项目简介，使用什么技术栈。

## Build & Test
- `npm install` 安装依赖
- `npm run dev` 启动开发
- `npm test` 运行测试

## Key Conventions
- 错误处理：统一用 AppError 类
- API 响应格式：{ data, error, meta }
- 分支命名：feat/xxx, fix/xxx

## Architecture
- 源码在 src/
- 路由按模块拆分：src/routes/{auth,tasks}/
```

### 导入外部文件

```markdown
# CLAUDE.md

项目概览请参考 @README.md
API 文档请参考 @docs/api-spec.md
个人偏好参考 @~/.claude/my-preferences.md
```

### 条件规则（Claude Code 风格，对应 Skills globs）

```markdown
# .claude/rules/api-testing.md
---
paths:
  - "src/routes/**/*.ts"
  - "tests/**/*.test.ts"
---

# API 测试规则
- 每个路由文件必须有对应的 .test.ts
- 使用 supertest 做集成测试
```

---

## 3. 指令文件最佳实践

| 实践 | 说明 |
|------|------|
| 控制在 200 行以内 | 过长降低遵循度 |
| 写具体可验证的指令 | "2空格缩进" ✅ "格式化好" ❌ |
| 分层组织 | 通用规则顶层，特定规则用 paths/globs |
| 避免冲突 | 定期审查，删除过时规则 |
| 用 AGENTS.md 跨平台 | 同一文件多工具通用 |
| 先 spec 再执行 | spec驱动工作流（见下节） |

---

## 4. Spec 驱动开发工作流

```
想法 → spec.md → prompt_plan.md → todo.md → 迭代执行
```

### spec.md 模板

```markdown
# spec.md

## 项目概述
构建什么，支持什么功能。

## 功能需求
- 用户认证（JWT）
- 任务 CRUD
- 状态流转

## 技术栈约束
- 后端: Node.js + TypeScript
- 数据库: PostgreSQL + Prisma
- 测试: Vitest

## 非功能需求
- API 响应 < 200ms
- 测试覆盖率 > 80%

## 排除项
- 不做前端 UI
- 不做 WebSocket
```

### prompt_plan.md 模板

```markdown
# prompt_plan.md

## Phase 1: 项目脚手架
提示: "初始化项目结构，配置 TypeScript、ESLint、Vitest..."

## Phase 2: 认证模块
提示: "实现 JWT 认证中间件，注册/登录端点..."

## Phase 3: 任务 CRUD
提示: "实现任务模型和 CRUD 端点..."
```

### todo.md 模板

```markdown
# todo.md

- [ ] 初始化 npm 项目 + TypeScript 配置
- [ ] 配置 ESLint + Prettier
- [ ] 实现注册端点 POST /auth/register
- [ ] ...
```

### 关键原则

- 一次只做 todo.md 中的一项
- 先写测试，再实现（TDD）
- 每步完成都运行测试验证
- 每完成一个功能就 commit

---

## 5. Hooks（事件驱动自动化）

### 生命周期

```
SessionStart → [用户提示] → UserPromptSubmit
  → [Agent 循环]
    → PreToolUse → [工具执行] → PostToolUse / PostToolUseFailure
    → SubagentStart → [Subagent工作] → SubagentStop
    → TeammateIdle / TaskCompleted
  → [Agent 循环结束]
  → Stop
→ PreCompact → [压缩] → PostCompact
→ SessionEnd
```

### 关键 Hook 类型

| 类型 | 说明 | 场景 |
|------|------|------|
| `command` | 执行 Shell | lint、测试、安全检查 |
| `http` | HTTP POST | 外部服务集成 |
| `prompt` | LLM 单轮评估 | AI 判断是否允许操作 |
| `agent` | subagent 验证 | 多步骤验证 |

### 阻止危险命令示例

```bash
#!/bin/bash
# .claude/hooks/block-dangerous.sh
INPUT=$(cat)
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // empty')

if echo "$COMMAND" | grep -qE 'rm -rf|drop table|DROP DATABASE'; then
  echo "已阻止危险命令: $COMMAND" >&2
  exit 2  # exit 2 = 阻止工具调用
fi
exit 0
```

---

## 6. 常见错误排查

| 问题 | 原因 | 解决 |
|------|------|------|
| Agent 不遵循规则 | 指令太模糊 | 写具体可验证的指令 |
| Skills 未触发 | description 缺少触发关键词 | 改善 description |
| MCP 工具超时 | Server 未启动 | 先手动测试 MCP 连接 |
| Hooks 不生效 | 在会话中修改了配置 | 重启会话让配置快照生效 |
| Subagent 上下文不足 | 未传递充分信息 | 在 goal 中包含完整上下文 |
| 多 Agent 文件冲突 | 两个 agent 编辑同一文件 | 拆分工作让每个 agent 负责不同文件 |

---

## 8. Phase 0 Output Gate 模式 — 让预检不可跳过

### 问题：Skill 里的"前置步骤"经常被跳过

Skill 的 Phase 0 通常写："执行前，先搜知识库 / 检查文件 / 验证依赖"。
但 agent 的默认行为是**直接执行任务**，Phase 0 的文字指令会被忽略。

**根因链条（2026-05-06 实证）：**

```
Phase 0 写"搜 lessons/" → 在 context 里是纯文本 → 和周围指令无区别
→ agent 优先级是"完成用户任务"→ 跳过 Phase 0 → 没有可见后果
→ 用户不知道 agent 跳过了 → 飞轮断裂在复用层
```

### Output Gate 模式：用"必须输出的内容"替代"建议性文字"

**核心原则：** 不是告诉 agent "去做X"，而是说"输出X的结果"。
agent 不执行 Phase 0 = agent 的输出中缺少 Step 1/2/3 的产出 = 用户立刻能看到。

**为什么这比文本指令更可靠：**

| 机制 | 效果 |
|------|------|
| 文本指令("先搜再写") | agent 可跳过，无可见后果 |
| Output gate("输出检索摘要") | agent 跳过 → 输出缺失 → 用户立刻发现 |
| 关键在于**创造可见遗漏** | 遗漏本身是用户可观察的信号，比"相信 agent 会遵守指令"更可靠 |

本模式在 2026-05-06 session 中通过曳光弹验证有效：patent-disclosure-writing skill 启用 Output gate 后，首次使用就触发了 reference 检索，发现了 V1→V2 修改漏掉的 Letta URL 死链、git 能力夸大、自动重试不存在三个问题。

### 模板

```markdown
### Phase 0: 预检（硬性门禁 — 必须输出以下内容才能进入 Phase 1）

#### Step 0.1: 列出相关资源

```bash
ls -la path/to/resources/
```

**Output gate：** 列出全部文件及其用途。至少读第一行。

#### Step 0.2: 搜索已有知识

```bash
python3 search_knowledge.py "<关键词1>"
```

**Output gate：** 输出命中结果的实际内容摘要。空结果时显式输出"空结果"。

#### Step 0.3: 输出检索结论

```
📋 检索结论
  - 可复用的资源: [文件名列表]
  - 核心风险（不检索可能犯的错）: [一句话]
```

**Output gate：** 必须输出此结论块。不输出 = 不允许进入 Phase 1。
```

### 典型对比

| 写法 | 效果 |
|------|------|
| "在执行前先搜索 reference 目录" | ❌ 被跳过，无后果 |
| "**必须**先搜再写" | ❌ 加粗也没用，仍是文本 |
| "Step 0.1: ls reference/ 并输出清单" | ✅ 跳过会被发现 |
| "Step 0.2: 对搜索结果输出实际摘要" | ✅ 跳过意味着摘要不存在 |

### 适用范围

- 需要在任务开始前检索知识库的 skill（patent、review、architecture-design）
- 需要检查环境状态再动手的 skill（deploy、debug、migration）

### 陷阱

- **Output gate 不宜超过 4 步** — 太多步骤本身的 token 成本会消耗上下文
- **不要要求输出不需要的内容** — 如果搜索空结果，gate 应允许"空结果"为合法输出
- **Output gate 不能替代代码级的强制** — 对关键任务（如数据删除），仍需代码级的确认（hooks、subagent）
- **验证门禁是否有效** — 第一次由 agent 执行后检查输出是否符合预期。如果 agent 仍然"绕过"输出要求（如输出"已检索完成"但不提取实际内容），升级为 subagent 执行
- **代码级强制的备用方案** — 如果 Output gate 仍不可靠（比如 agent 跳过输出检查），cc-haha 的 UserPromptSubmit hook 提供了 `additionalContext` 注入点。参见 `references/cc-haha-hook-injection.md`

### 实战案例

**patent-disclosure-writing skill** (2026-05-06, 第一个启用 Output gate 的 skill)：

```
### Phase 0: 知识检索（硬性门禁 — 必须输出检索报告才能进入 Phase 1）

Step 0.1: ls reference/ → Output gate: 全部文件名 + 用途
Step 0.2: search_knowledge + read_file → Output gate: top-3 文件摘要 + 相关性
Step 0.3: search_knowledge + grep lessons → Output gate: 匹配数 + top-3 标题
Step 0.4: 检索结论块 → Output gate: 可复用文件 + 核心风险
```

首次执行验证：此 session 的专利交底书审查正是通过此门禁触发，检索到 reference/patent-fto-and-filing-matrix.md 和 reference/node6-patent-iteration-review.md，避免了 Letta URL 过期、git 能力夸大等 V1 版已有的坑。

---

## 7. 工具对照速查

| 功能 | Claude Code | Hermes Agent |
|------|-------------|--------------|
| 项目级指令 | CLAUDE.md | SOUL.md + USER.md |
| Skills | `.claude/skills/` | `~/.hermes/skills/` |
| 条件加载 | `paths:` frontmatter | frontmatter `name` + `description` |
| Subagents | `.claude/agents/` | `delegate_task` |
| Hooks | `.claude/settings.json` | skills `hooks:` frontmatter |
| MCP | `.claude/mcp.json` | config.yaml `mcpServers` |
| Auto Memory | Auto Memory | `memory` tool |

---

## 参考资料

- Agent Skills 规范: https://agentskills.io
- MCP 协议: https://modelcontextprotocol.io
- Harper Reed LLM Codegen 工作流: https://harper.blog/2025/02/16/my-llm-codegen-workflow-atm/
- Anthropic Skills 仓库: https://github.com/anthropics/skills
