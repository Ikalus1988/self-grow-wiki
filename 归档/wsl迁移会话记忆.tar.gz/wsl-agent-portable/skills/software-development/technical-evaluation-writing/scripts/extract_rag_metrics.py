#!/usr/bin/env python3
"""Extract real operational metrics from RAG system for evaluation documents.

Usage: python3 extract_rag_metrics.py [--db PATH] [--audit-dir PATH] [--chromadb PATH]

Outputs a structured JSON report with all metrics needed for evaluation documents.
"""

import sqlite3
import json
import sys
from pathlib import Path
from datetime import datetime

def extract_query_metrics(db_path: str) -> dict:
    """Extract all query metrics from SQLite database."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # Basic counts
    cur.execute('SELECT COUNT(*) FROM query_log')
    total = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM query_log WHERE ts >= datetime('now', '-7 days')")
    last_7d = cur.fetchone()[0]

    cur.execute('SELECT COUNT(DISTINCT channel_name) FROM query_log WHERE channel_name IS NOT NULL AND channel_name != ""')
    channels = cur.fetchone()[0]

    # Latency
    cur.execute('SELECT AVG(latency_ms), MIN(latency_ms), MAX(latency_ms) FROM query_log WHERE latency_ms IS NOT NULL AND latency_ms > 0')
    lat = cur.fetchone()
    avg_lat, min_lat, max_lat = lat[0] or 0, lat[1] or 0, lat[2] or 0

    # Scores
    cur.execute('SELECT AVG(top_score), MIN(top_score), MAX(top_score) FROM query_log WHERE top_score IS NOT NULL AND top_score > 0')
    sc = cur.fetchone()
    avg_score, min_score, max_score = sc[0] or 0, sc[1] or 0, sc[2] or 0

    cur.execute('SELECT COUNT(*) FROM query_log WHERE top_score > 0.85')
    high_score = cur.fetchone()[0]

    cur.execute('SELECT COUNT(*) FROM query_log WHERE top_score > 0 AND top_score <= 0.5')
    low_score = cur.fetchone()[0]

    cur.execute('SELECT AVG(num_chunks) FROM query_log WHERE num_chunks IS NOT NULL')
    avg_chunks = cur.fetchone()[0] or 0

    # Success rate
    cur.execute("SELECT COUNT(*) FROM query_log WHERE status = 'success'")
    success = cur.fetchone()[0]

    # Time range
    cur.execute('SELECT MIN(ts), MAX(ts) FROM query_log')
    time_range = cur.fetchone()

    # Daily trend
    cur.execute('''
        SELECT date(ts) as d, COUNT(*) 
        FROM query_log 
        GROUP BY date(ts) 
        ORDER BY d DESC LIMIT 14
    ''')
    daily = cur.fetchall()

    # Top channels
    cur.execute('''
        SELECT channel_name, COUNT(*) 
        FROM query_log 
        WHERE channel_name IS NOT NULL AND channel_name != "" 
        GROUP BY channel_name ORDER BY COUNT(*) DESC LIMIT 10
    ''')
    top_channels = cur.fetchall()

    # Best/worst cases
    cur.execute('''
        SELECT query, top_score, latency_ms, date(ts) 
        FROM query_log WHERE top_score > 0.85 
        ORDER BY top_score DESC LIMIT 10
    ''')
    best_cases = cur.fetchall()

    cur.execute('''
        SELECT query, top_score, latency_ms, date(ts) 
        FROM query_log WHERE top_score > 0 AND top_score <= 0.55 
        ORDER BY top_score ASC LIMIT 10
    ''')
    improvement_cases = cur.fetchall()

    # Feedback
    cur.execute('SELECT * FROM feedback')
    feedback = cur.fetchall()

    conn.close()

    return {
        'total_queries': total,
        'last_7d_queries': last_7d,
        'unique_channels': channels,
        'avg_latency_ms': round(avg_lat),
        'min_latency_ms': min_lat,
        'max_latency_ms': max_lat,
        'avg_top_score': round(float(avg_score), 3),
        'min_top_score': round(float(min_score), 3),
        'max_top_score': round(float(max_score), 3),
        'high_score_count': high_score,
        'high_score_pct': round(high_score / total * 100, 1) if total else 0,
        'low_score_count': low_score,
        'low_score_pct': round(low_score / total * 100, 1) if total else 0,
        'avg_chunks': round(float(avg_chunks), 1),
        'success_rate': round(success / total * 100, 1) if total else 0,
        'time_range': {'first': time_range[0], 'last': time_range[1]} if time_range[0] else None,
        'daily_trend': [{'date': d, 'count': c} for d, c in daily],
        'top_channels': [{'name': n, 'count': c} for n, c in top_channels],
        'best_cases': [{'query': q, 'score': s, 'latency_ms': l, 'date': d} for q, s, l, d in best_cases],
        'improvement_cases': [{'query': q, 'score': s, 'latency_ms': l, 'date': d} for q, s, l, d in improvement_cases],
        'feedback_count': len(feedback),
    }


def extract_audit_trends(audit_dir: str) -> dict:
    """Extract audit trend data from JSON reports."""
    reports = sorted(Path(audit_dir).glob('audit_*.json'))
    trends = []
    for r in reports:
        try:
            with open(r) as f:
                d = json.load(f)
            trends.append({
                'date': d.get('date', '?')[:10],
                'passed': d.get('passed'),
                'total': d.get('total_queries'),
                'pass_rate': d.get('pass_rate'),
                'failures': len(d.get('failures', [])),
            })
        except (json.JSONDecodeError, KeyError):
            continue

    # Compute summary
    valid = [t for t in trends if t['passed'] is not None]
    avg_pass = sum(t['passed'] for t in valid) / len(valid) if valid else 0
    avg_total = sum(t['total'] for t in valid) / len(valid) if valid else 0

    return {
        'total_reports': len(reports),
        'trends': trends,
        'avg_pass_rate': round(avg_pass / avg_total * 100, 1) if avg_total else 0,
    }


def extract_kb_stats(chromadb_path: str, collection_name: str = 'wiki_docs') -> dict:
    """Extract knowledge base statistics."""
    try:
        import chromadb
        client = chromadb.PersistentClient(path=chromadb_path)
        col = client.get_collection(collection_name)
        return {'collection': collection_name, 'total_vectors': col.count()}
    except Exception as e:
        return {'collection': collection_name, 'error': str(e)}


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Extract RAG metrics for evaluation')
    parser.add_argument('--db', default='/home/hp/rag_query_log.db', help='SQLite query log path')
    parser.add_argument('--audit-dir', default='/home/hp/audit_reports', help='Audit reports directory')
    parser.add_argument('--chromadb', default='/home/hp/rag_chromadb', help='ChromaDB path')
    parser.add_argument('--collection', default='wiki_docs', help='ChromaDB collection name')
    parser.add_argument('--output', default=None, help='Output JSON path (default: stdout)')
    args = parser.parse_args()

    report = {
        'generated_at': datetime.now().isoformat(),
        'query_metrics': extract_query_metrics(args.db) if Path(args.db).exists() else None,
        'audit_trends': extract_audit_trends(args.audit_dir) if Path(args.audit_dir).exists() else None,
        'kb_stats': extract_kb_stats(args.chromadb, args.collection),
    }

    output = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(output, encoding='utf-8')
        print(f'Report saved to {args.output}')
    else:
        print(output)


if __name__ == '__main__':
    main()
