---
name: technical-evaluation-writing
description: "Write promotion/competition evaluation documents for technical projects: extract real operational metrics from system logs, gather evidence from session history, structure narratives for evaluators, prepare for Q&A defense. Use when user says 晋级/评审/评比/答辩/案例介绍/提效案例/竞品分析报告."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [evaluation, promotion, documentation, metrics, evidence, narrative]
    related_skills: [rag-systems, patent-disclosure-writing, project-completeness-assessment]
---

# Technical Evaluation Document Writing

## Overview

Write evaluation/promotion documents that prove a technical project's real-world impact. Distinguish from patent disclosure (legal claims) or code review (technical quality) — this is about **business impact + technical depth + evidence**.

## When to Use

- User says: 晋级/评审/评比/答辩/案例介绍/提效案例
- User has a working system and needs to prove it's good enough for promotion/competition
- User needs "real data" to back up theoretical claims

## Core Philosophy

> 把作品从"一个技术上很强的系统"，包装成"一个已经在一线场景中跑起来、能显著降低成本的智能助手"。

The #1 risk is never "not technical enough" — it's **"looks impressive but no proof it's actually used."**

## Narrative Structure (推荐顺序)

1. **一线痛点** — 场景化开场故事（停机/损失/紧急），让评委秒懂为什么需要这个系统
2. **解决方案** — 入口简单（@机器人/一行命令），效果直观（表格对比 Before/After）
3. **技术壁垒** — 不是简单套壳，有 X 项领域增强（用表格，每项有问题→方案→效果）
4. **真实效果** — 硬数据（查询量、用户数、响应时间、通过率），全部标注数据来源
5. **质量飞轮** — 系统越用越好的闭环证据（趋势数据 + 完整闭环案例）
6. **推广价值** — 可迁移到哪些场景（换品牌/换行业/换文档类型）
7. **未来规划** — 多层 Agent 架构演进路线（不需全实现，展示视野）

### Title Formula

❌ `案例介绍_RAG工业知识库` (技术说明型)
✅ `产线停机，工程师翻3本手册找答案——现在@机器人3秒定位故障` (场景冲击型)

Pattern: **[痛点场景] + [量化对比] + [解决方案一句话]**

### Opening Story Template

> 某天夜班，[设备]报出[具体报警代码]，[产线]停机。
> 过去，[角色]需要[具体繁琐动作]，花[时间范围]。
> 现在，他只需要[简单动作]，系统在[时间]内返回[结果]。
> 这套系统不只是[表面功能]，而是把[规模数据]变成[价值描述]。

## Data Extraction Methodology

### Step 1: System Metrics (from SQLite logs)

```python
import sqlite3
conn = sqlite3.connect('path/to/query_log.db')
cur = conn.cursor()

# Core metrics
cur.execute('SELECT COUNT(*) FROM query_log')  # 总查询量
cur.execute('SELECT COUNT(*) FROM query_log WHERE ts >= datetime("now", "-7 days")')  # 近7天
cur.execute('SELECT COUNT(DISTINCT channel_name) FROM query_log WHERE channel_name != ""')  # 独立入口
cur.execute('SELECT AVG(latency_ms), MIN(latency_ms), MAX(latency_ms) FROM query_log WHERE latency_ms > 0')  # 响应时间
cur.execute('SELECT AVG(top_score) FROM query_log')  # 平均分数

# High/low score distribution
cur.execute('SELECT COUNT(*) FROM query_log WHERE top_score > 0.85')  # 高分命中
cur.execute('SELECT COUNT(*) FROM query_log WHERE top_score > 0 AND top_score <= 0.5')  # 低分查询

# Daily trend (for charts)
cur.execute('SELECT date(ts), COUNT(*) FROM query_log GROUP BY date(ts) ORDER BY ts DESC LIMIT 14')

# Before/After case samples
cur.execute('SELECT query, top_score, latency_ms, date(ts) FROM query_log ORDER BY top_score DESC LIMIT 10')  # best cases
cur.execute('SELECT query, top_score, latency_ms, date(ts) FROM query_log WHERE top_score > 0 AND top_score <= 0.55 ORDER BY top_score ASC LIMIT 10')  # improvement cases
```

### Step 2: Audit Trend Data (from JSON reports)

```python
import json
from pathlib import Path

audit_dir = Path('path/to/audit_reports')
reports = sorted(audit_dir.glob('audit_*.json'))
for r in reports:
    with open(r) as f:
        d = json.load(f)
    print(f"{d['date'][:10]}: {d['passed']}/{d['total_queries']} ({d['pass_rate']})")
```

### Step 3: Knowledge Base Stats

```python
import chromadb
client = chromadb.PersistentClient(path='path/to/chromadb')
col = client.get_collection('collection_name')
print(f'Total vectors: {col.count()}')
```

### Step 4: Evidence from Session History

Use `session_search` to find real user interactions:

```
session_search(query="关键词 用户反馈 好用 准确 不准", limit=5)
session_search(query="飞书 群 问答回答", limit=5)
```

This finds actual Q&A exchanges that prove the system is being used in production.

### Step 5: File/Document Counts

```bash
ls path/to/extracted/ | wc -l  # 提取文档数
```

## Evidence Hierarchy (from strongest to weakest)

1. **系统日志数据** — SQLite/JSON，可追溯可复现（最强）
2. **真实交互记录** — session_search 找到的飞书群/微信问答（很强）
3. **自动巡检报告** — cron 产出的 JSON 审计报告（强）
4. **截图** — 需要用户手动提供（中）
5. **访谈/口述** — "5名工程师表示..."（弱，但可接受）

## Metrics Table Template

| 指标 | 数值 | 数据来源 |
|------|------|---------|
| 运行时间 | X 天 | SQLite 首次/末次查询时间 |
| 总查询量 | N 次 | SQLite COUNT |
| 近7天查询 | M 次 | SQLite WHERE ts >= -7d |
| 独立用户/入口 | K 个 | SQLite DISTINCT channel |
| 平均响应时间 | Xms | SQLite AVG(latency_ms) |
| 高分命中率 | X% | SQLite top_score > 0.85 |
| 知识库规模 | X vectors / Y docs | ChromaDB count() |
| 每日巡检通过率 | X% | audit_reports JSON |

## Quality Flywheel Evidence

Evaluators love "越用越好" — prove it with:

1. **Trend data**: audit pass rate over time (show recovery after dips)
2. **Growth metrics**: synonym rules count, badcase queue size, approved fixes
3. **Complete closure case**: problem → auto-detect → diagnose → fix → verify → prevents recurrence

### Closure Case Template

| 阶段 | 内容 |
|------|------|
| 发现问题 | [具体查询] 得分仅 [X]，远低于阈值 |
| 自动发现 | top_score < [阈值]，自动进入待审队列 |
| 根因分析 | [具体原因：缺同义词/文档未导入/分块截断] |
| 修复动作 | [具体修复：添加同义词规则/补充文档/调整分块] |
| 验证结果 | 同类查询得分提升到 [Y] |
| 持续监控 | [后续保障机制] |

## Multi-Agent Evolution Architecture

Even if not fully implemented, show a layered roadmap:

```
Layer 3: Action Agent (future) — auto-generate work orders, push SOPs
Layer 2: Diagnosis Agent (partial) — combine alarms + history + device state
Layer 1: Retrieval Agent (done) — semantic search + domain enhancements
```

This shows evaluators you're thinking beyond "just a chatbot."

## Evaluator Q&A Preparation

Always include a "预备回答" section with 5-10 likely evaluator questions:

1. 实际跑了多少次？多少人用过？→ 引用 SQLite 数据
2. 精度怎么测的？样本量？→ 引用评估集 + 巡检机制
3. 回答错了怎么办？→ 引用兜底机制
4. 换场景要改多少？→ 引用可迁移性分析
5. 相比直接用大模型的核心优势？→ 引用领域增强 + 飞轮
6. 扩大10倍的瓶颈？→ 引用扩展路径
7. 未来怎么升级？→ 引用多层 Agent 架构

## Common Pitfalls

1. **指标自相矛盾** — "4通道容灾"但表格只有3个通道，评委会抓细节
2. **数据无来源** — 写"精度85-92%"但不说明怎么测的、样本量多少
3. **措辞过满** — "品牌污染0%"应改为"当前评估样本中未发现"
4. **只讲机制不讲效果** — 描述了质量飞轮但没有趋势数据证明它在转
5. **标题太技术** — 评委第一眼看标题，技术说明型标题不抓人
6. **缺少 Before/After** — 有提效数字但没有具体案例，看起来像理论估算
7. **通道数不一致** — 文档各处提到的 LLM 通道数必须统一
8. **章节编号冲突** — 多个"三、"章节，显得不专业
