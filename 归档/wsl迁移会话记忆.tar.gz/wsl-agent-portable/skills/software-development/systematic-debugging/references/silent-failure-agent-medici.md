# Silent Failure Worked Example: Agent-Medici

> Part of `systematic-debugging` Phase 0 (Silent Failure Probe)
> Date: 2026-05-04
> System: Agent-Medici / MisakaNet — multi-node AI agent swarm

## The Problem

User asked: "好久没在飞书群看到推送 lesson 通知了。"

The system appeared to be running:
- All cron jobs executing every 5 minutes
- Git authentication passing
- No error messages in logs
- Feishu webhook URL configured and working

**Trap:** Everything "works" but nothing useful happens.

## Methodology Applied

### Step 0.1: Define Success

What is this system supposed to produce?
- **Output contract:** Lessons (`lessons/*.md`) that document agent experiences, committed to GitHub
- **Unit of value:** One lesson file with real content (not template, not bootstrap import)
- **Expected frequency:** Several per week from automatic hooks

### Step 0.2: Measure Actual Output

```bash
# Total lessons: 136 (looks good!)
ls lessons/*.md | wc -l

# But break down by source:
grep "^source:" lessons/*.md | sort | uniq -c | sort -rn
# 126 source: bootstrap  ← bulk import, not organic growth
#   6 source: hermes_wsl ← real contributions
#   2 source: hermes_wsl2

# Only 8 real contributions out of 136 (6%)
# Recent 30 days: 17 commits to lessons/ — but most are tooling, not new lessons

# Check actual lesson content by git author:
git log --format="%an" -- lessons/ | sort | uniq -c | sort -rn
# 10 Ikalus1988 (manual)
#  5 魔术师 (cleanup)
#  2 cc-haha (templates only, no real lessons)
```

### Step 0.3: Trace Output Backwards

```
What user should see: Feishu notification when lesson created
  ↓
What's reaching them: Nothing — user reports "好久没看见"
  ↓
What produces notification: feishu_notifier.py (HTTP POST webhook)
  ↓
What triggers it: hub_poller.py (for hook_stats) + main.py (for feedback issues)
  ↓
But what about lessons?: queue_lesson.py does NOT call feishu_notifier at all!
  ↓
What about cc-haha hook?: Writes hook_stats.json but NEVER calls queue_lesson.py
  ↓
ROOT CAUSE: Two of three lesson-writing paths silently drop the notification
  AND the third (cc-haha) never writes lessons at all — only statistics
```

### Step 0.4: Distinguish "Running" from "Productive"

| Signal | Found | Verdict |
|--------|-------|---------|
| cron jobs executing | ✅ tail logs show periodic output | Cron runs, but produces nothing |
| git auth passing | ✅ "GitHub: @Ikalus1988 (token OK)" | Auth fine, no valid input to process |
| cc-haha hook triggering | ✅ 18+ hook_stats commits | Hook captures failures but only writes stats, never lessons |
| feedback_report running | ✅ Each tick shows "=== done ===" | Every run finishes, but `.feedback/pending/` is always empty |
| standby_poller running | ✅ "git pull OK" + "无新数据" | Poller works, but no new hook_stats data |
| lessons being written | ❌ 126/136 are bootstrap imports | Real organic growth: ~0.27/day from manual only |

### Step 0.5: Verify with Evidence

**Pitfall confirmed:** Initial LLM analysis said "cc-haha writes lessons but doesn't notify Feishu." This sounded plausible but was wrong.

**Actual verification:**
```bash
# Check: has cc-haha ever written a lesson?
git log --all --oneline --author="cc-haha" -- 'lessons/*.md'
# Only 2 commits: templates + config metadata — NOT real lessons

# Check: what does cc-haha actually write?
git log --all --oneline --author="cc-haha"
# 18+ commits of "hook_stats: cc_haha — 6 triggers"
# Zero lesson commits!

# Check: does queue_lesson.py call feishu_notifier?
grep -n "feishu\|notify\|webhook" misakanet/scripts/queue_lesson.py
# No output — confirmed, no notification

# Check: what happens when hook passes --hit "file"?
# queue_hook_stats.py line 209:
#   if hit: lesson_path = LESSONS_DIR / hit → LESSONS_DIR / "file" → doesn't exist
#   _is_template_lesson(filepath) → filepath.exists() == False → returns False
#   → function does NOTHING actionable (no draft, no fill, no output)
```

**Lesson:** Never trust an LLM's claim about a system without verifying the actual code path.

## Findings Summary

### What's Actually Broken

| Pipeline | Status | Real Output | Root Cause |
|----------|--------|-------------|------------|
| cc-haha hook | ✅ Running | ❌ Zero lessons | Hook writes `hook_stats.json` with `--hit "file"` (weak keyword), not real lesson filename. `queue_hook_stats.cmd_trigger()` falls into void: hit is truthy, but file doesn't exist so `_is_template_lesson()` returns False → nothing happens. |
| feedback_report | ✅ Running | ❌ Zero Issues | `.feedback/pending/` is permanently empty. No script ever calls `create_feedback_issue()`. |
| standby_poller | ✅ Running | ❌ Zero Feishu | `.hook_stats/cc_haha.json` hasn't changed since May 3 (`updated_at` same as `last_seen`). |
| Manual (user) | ⏳ On-demand | 8 real lessons | Only productive path. Depends on user remembering to run `queue_lesson.py`. |

### What's NOT the Problem

- ❌ "好久没推送" → Not a cron failure. Feishu webhook works (verified: manual test succeeded). No lessons are being produced, so there's nothing to push.
- ❌ "系统挂了" → All daemons, cron, auth, git operations work correctly.
- ❌ "通知链路断了" → The notification link was never connected for lessons.

### Diagnosis

**Core issue:** Three data pathways exist but none connect to value creation.

```
Input → Process → Output → User Perception
                        ↓
              THIS LINK IS MISSING FOR LESSONS
```

The system creates the illusion of productivity (git commits, cron output, auth passes) without actually producing the thing it was designed to produce (shared knowledge from agent experiences).

## Fix Applied

### Short-term (this session)

| Priority | Fix | File | Impact |
|----------|-----|------|--------|
| P1 | draft_reminder.py: scan both `~/.hermes/lessons/drafts/` AND repo `lessons/*.md` for stale `status: draft` | `misakanet/scripts/draft_reminder.py` | Feishu reminder for 57 un-reviewed bootstrap drafts |
| P2 | queue_hook_stats.py: weak `--hit` (file doesn't exist) → degrade to draft | `misakanet/scripts/queue_hook_stats.py` | Broken triggers now produce usable drafts |
| P3 | Cron: draft_reminder runs 9:00 + 14:00 daily | crontab | Regular draft reminders |

### Medium-term (user implementing on Node 3)

| Priority | Fix | Owner | Status |
|----------|-----|-------|--------|
| P0 | cc-haha hook: write lesson directly instead of just hook_stats | User (Node 3) | In progress |

## Key Takeaway

**Do not trust "system is running" as evidence of "system is working."**

Measure output, not processes. A pipeline that executes without error but produces nothing is more dangerous than a crashed one — because crashed pipelines get attention; silent ones waste resources indefinitely while creating the perception of functionality.
