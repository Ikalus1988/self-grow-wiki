# CI Debugging via Timestamp Correlation

A technique for diagnosing CI workflow failures where the job reports failure but the resource shows successful updates.

## Pattern

1. A CI job step reports failure (exit code 1, red ❌)
2. But the affected resource (counter.json, database, deployed artifact, API state) **was actually updated correctly** with the right timestamp
3. The run took suspiciously little time (e.g., 1 second for a step that has 2-second sleep intervals)

## Root Cause

The most likely cause is the `break` + unconditional `exit` after `done` anti-pattern (see the Phase 2 Pitfalls section in the main SKILL.md). The retry loop's `break` exits the while body, but execution continues to `exit 1` placed after `done` — so even a successful push triggers a failure.

## Diagnostic Protocol

### Step 1: Measure Run Duration

Check the CI job's timestamps:

```json
{
  "started_at": "2026-05-11T08:20:55",
  "completed_at": "2026-05-11T08:20:56"
}
```

Duration < 1 second for a step with retry sleep of 2+ seconds → the retry loop was entered but `break` fired on the first attempt (not exhaustion).

### Step 2: Verify Resource State Independently

Do NOT rely on the CI job output. Check the actual resource via its API:

```python
# For a GitHub repo counter.json
req = urllib.request.Request(
    'https://api.github.com/repos/OWNER/REPO/contents/counter.json',
    headers={'Authorization': f'Bearer {token}'})
data = json.loads(urllib.request.urlopen(req).read())
content = base64.b64decode(data['content']).decode()
```

Cross-reference the `updated` timestamp with the CI job's `started_at`. If they match, the push succeeded.

### Step 3: Check Dependent Outputs

If the failed step's outputs should feed into a downstream step (e.g., welcome comment on an issue), check whether those downstream effects exist:

```python
# Check if welcome comment was posted
comments = json.loads(urllib.request.urlopen(
    'https://api.github.com/repos/OWNER/REPO/issues/NUMBER/comments', headers=h).read())
```

If the upstream resource was updated but no downstream effect happened, the upstream step failed due to the `break`+`exit` anti-pattern and the downstream step never ran.

### Step 4: Read the Workflow Source

Once the pattern is identified, read the CI workflow file and look for this specific pattern:

```yaml
- name: Step with retry
  run: |
    while condition; do
      if command; then
        break     # success — exits loop
      fi
    done
    exit 1        # ← ALWAYS executes!
```

## Worked Example (this session)

**Situation:** GitHub Actions workflow "御坂网络注册" run #49
- Assign step ran from 08:20:55 to 08:20:56 (1 second)
- counter.json in repo was updated to 10026 with timestamp 08:20:55
- Step reported failure
- Welcome comment never posted to issue #65

**Diagnosis chain:**
1. < 1s duration with 2s retry sleep → loop exited on first attempt, NOT exhaustion
2. counter.json at 10026 with matching timestamp → push succeeded
3. No welcome comment → downstream step didn't run
4. Root cause: `break` + unconditional `exit 1` after `done`

**Fix:** Added `REGISTERED=false` flag before loop, set `REGISTERED=true` before `break`, conditional `exit 1` after `done`.

## When NOT to Use This Pattern

- If the run took multiple seconds (retries actually executed) → it's a genuine exhaustion failure
- If the resource wasn't updated → the push/operation genuinely failed
- If the error message explicitly states the failure reason → read the error first

This pattern is specifically for the case where "everything worked but the CI says it didn't."
