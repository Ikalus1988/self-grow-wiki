# Grouped Data Generation: Global vs Per-Group Index Bug

## Context

Generating fake data for an Excel template: 666 rows, 16 columns per row, each group of 16 rows shares a date. Rows 3 and 4 (columns 3-4) must be skipped (left blank).

## The Bug

### Initial (broken) code pattern:
```python
lines = []
row = 3  # global row counter
group_idx = 0

while row <= total_rows:
    day = dates[group_idx]
    times = [None] * 16
    # ... fill times[0..15] with datetime objects using `day` ...

    for i in range(16):
        current_row = row + i
        if current_row in (3, 4):  # BUG: only fires for first group
            continue
        lines.append(times[i].strftime("%Y-%m-%d %H:%M:%S"))

    row += 16
    group_idx += 1
```

### What went wrong:
- `current_row` is a global counter: 3, 4, 5, ..., 18, 19, 20, ..., 34, 35, ...
- `if current_row in (3, 4)` only matches the very first group (rows 3-18)
- For group 2 (rows 19-34), `current_row` is never 3 or 4, so NO rows are skipped
- Group 2 outputs 16 entries instead of 14
- The `times[0]` and `times[1]` from group 2 get appended, but the verification script assumes 14 entries per group and misaligns

### Symptoms:
- Group 1: all 14 entries correct (date 2026-03-30)
- Group 2: all 16 entries with correct date (2026-03-31), but 2 extra entries
- Group 3+: verification script reads wrong date for first 2 entries because the 14-entry grouping is off by 2

### Debugging path:
1. Ran isolated test for group 3 — dates were correct when tested alone
2. Verified `datetime.replace()` creates new objects (not mutation)
3. Printed `times` array for each group — all 16 values had correct dates
4. Printed final `lines` with group labels — discovered the grouping offset
5. **Root cause:** skip logic uses global row number, not per-group index

## The Fix

```python
SKIP_IDXS = {2, 3}  # per-group indices to skip

lines = []
group_idx = 0

while len(lines) < total_rows:
    day = dates[group_idx % len(dates)]
    times = []
    # ... fill times[0..15] ...

    for i in range(16):
        if i in SKIP_IDXS:  # per-group index, always fires
            continue
        lines.append(times[i].strftime("%Y-%m-%d %H:%M:%S"))

    group_idx += 1
```

## Key Lesson

When processing data in groups with skip/filter logic:
- **Global counter** → skip condition only fires for the first group, subsequent groups are unfiltered
- **Per-group index** → skip condition fires correctly for every group

This pattern applies to any grouped processing: CSV chunks, batched API calls, paginated data, time-series windows.

## Verification Pattern

Always add a consistency check after generating grouped data:
```python
gsize = 14  # expected entries per group
bad = 0
for g in range(len(lines) // gsize + 1):
    start = g * gsize
    end = min(start + gsize, len(lines))
    expected_date = dates[g].strftime("%Y-%m-%d")
    for i in range(start, end):
        if not lines[i].startswith(expected_date):
            bad += 1
print(f"Date errors: {bad} / {len(lines)}")
```
