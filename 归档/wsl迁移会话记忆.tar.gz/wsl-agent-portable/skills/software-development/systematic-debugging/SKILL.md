---
name: systematic-debugging
description: "4-phase root cause debugging: understand bugs before fixing."
version: 1.1.0
author: Hermes Agent (adapted from obra/superpowers)
license: MIT
metadata:
  hermes:
    tags: [debugging, troubleshooting, problem-solving, root-cause, investigation]
    related_skills: [test-driven-development, writing-plans, subagent-driven-development]
---

# Systematic Debugging

## Overview

Random fixes waste time and create new bugs. Quick patches mask underlying issues.

**Core principle:** ALWAYS find root cause before attempting fixes. Symptom fixes are failure.

**Violating the letter of this process is violating the spirit of debugging.**

## The Iron Law

```
NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST
```

If you haven't completed Phase 1, you cannot propose fixes.

## When to Use

Use for ANY technical issue:
- Test failures
- Bugs in production
- Unexpected behavior
- Performance problems
- Build failures
- Integration issues
- **Silent failures — systems that "run" but produce no value** (no errors, no crashes, just zero output)

**Use this ESPECIALLY when:**
- Under time pressure (emergencies make guessing tempting)
- "Just one quick fix" seems obvious
- You've already tried multiple fixes
- Previous fix didn't work
- You don't fully understand the issue
- **Everything "seems fine" but nothing is happening** — no errors, just no results (this is the most dangerous type of failure because it creates the illusion of a working system)

**Don't skip when:**
- Issue seems simple (simple bugs have root causes too)
- You're in a hurry (rushing guarantees rework)
- Someone wants it fixed NOW (systematic is faster than thrashing)

## The Four Phases

You MUST complete each phase before proceeding to the next.

---

## Phase -1: 知识检索（硬性门禁）

> 在开始根因分析之前，先确认现有知识库中是否已有同类问题的分析记录。
> 虫群 lessons/reference 中可能已有其他节点解决的类似问题。

### Step -1.1: 搜索 lessons 和 reference

用当前报错/异常的关键词检索知识库：

```bash
cd ~/Agent-Medici
python3 search_knowledge.py "<核心错误关键词>" --lessons
python3 search_knowledge.py "<组件名/工具名>" --ref
```

搜索词应包括：
- 核心错误信息（如 "connection refused"、"timeout"、"exit code 1"）
- 涉及组件名（Hermes、Gateway、ChromaDB、WSL、cc-haha 等）
- 项目名（Agent-Medici、MisakaNet、self-grow-wiki 等）

**Output gate：** 输出命中数量 + top-3 文件的实际摘要。如果 search_knowledge.py 返回空，输出 `"search_knowledge.py 空结果"` 并补充手动 `grep -r "关键词" lessons/`。

### Step -1.2: 输出检索结论

```
📋 检索结论
  - 可复用的 lessons: [标题列表]
  - 可复用的 reference: [文件名列表]
  - 与当前调试任务的关系: [这些知识能直接复用，还是只是背景参考]
  - 核心风险（如果不检索会犯什么错）: [一句话]
```

**Output gate：** 必须输出此结论块。不输出 = 不允许进入 Phase 0/1。

---

## Phase 0: Silent Failure Probe

**WHEN there are no errors but the system isn't producing value:**

This is the most insidious failure mode. Pipelines execute, logs rotate, `ps aux` shows processes — but nothing useful comes out. Users feel the system is "dead" but can't point to a specific error.

**Do NOT start fixing. Start measuring.**

### Step 0.1: Define "What Does Success Look Like?"

Before touching anything, define the system's **output contract**:
- What is the system supposed to produce? (lessons, reports, alerts, query results)
- What is "one unit of value"? (one written lesson, one notification sent)
- What is the minimum expected frequency? (per day, per hour, per cron tick)

### Step 0.2: Measure Actual Output

For each pipeline/product path, gather hard data:

```bash
# Example: how many lessons were actually created?
git log --oneline -- lessons/ | head -20
git log --oneline --since="30 days ago" -- lessons/ | wc -l

# Example: what's the distribution of sources?
grep -h "^source:" lessons/*.md | sort | uniq -c | sort -rn

# Example: are cron jobs actually producing output?
wc -l /tmp/pipeline_name.log
tail -20 /tmp/pipeline_name.log

# Example: what percentage is real vs. bootstrap/import?
grep -h "^source:" lessons/*.md | grep bootstrap | wc -l
ls lessons/*.md | grep -v bootstrap | grep -v index.md | wc -l
```

### Step 0.3: Trace Output Backwards

**Do NOT trace the pipeline forward** ("input → process → output") — that's the happy path that may not reflect reality.

Instead, **start at the output boundary and trace backwards**:

```
What the human should see
    ↓
What's actually reaching them? (check notification logs, webhook responses)
    ↓
What produces the notification? (which script, what trigger)
    ↓
What feeds into that script? (data files, cron input, sensor readings)
    ↓
Where does that data come from? (upstream scripts, user input)
    ↓
ROOT CAUSE (typically at the data source or trigger point)
```

**Why backwards?** Because the pipeline may be healthy right up to the final step, where output is silently dropped. Tracing forward from input would show "everything works." Tracing backwards from "nothing reaches the human" forces you to inspect each link with the right question.

### Step 0.4: Distinguish "Running" from "Productive"

| Signal | Means | Does NOT Mean |
|--------|-------|---------------|
| `ps aux | grep cron` | cron daemon is alive | pipelines fire correctly |
| `tail log` shows periodic output | script executes | script creates value |
| git log shows commits | data was staged | data was meaningful |
| token auth OK | credential works | pipeline has input to process |
| "no new data" message | script ran to completion | nothing is wrong |

**Pitfall: "The system is running" ≠ "the system is working."**
Every component can execute without error and still produce zero value because:
- The input queue is permanently empty (feedback_report: no pending/ input)
- Capture logic stores stats but never triggers production (cc-haha: writes hook_stats, never calls lesson writer)
- The output path is not connected to any consumer

### Step 0.5: Verify Your Own Conclusions with Evidence

**Pitfall: LLM-based analysis can sound convincing while being wrong.** This user prefers evidence over reasoning. Before presenting findings:

- **Do NOT say "probably X is broken"** — check the actual code/logs/git history.
- **For every claim, ask: "can I prove this with data?"**
- If the answer is no, run the terminal command first.
- **The most dangerous pattern: making a sound argument based on plausible-but-untested assumptions.** The user will independently verify every claim by reading the code themselves.

**Verification checklist:**

```bash
# Verify: "is this pipeline producing output?"
ls -la /tmp/pipeline_name.log
grep -i "error\|fail\|done\|created" /tmp/pipeline_name.log | tail -10

# Verify: "does this code path execute?"
grep -n "write\|notify\|push" target_script.py | head -10

# Verify: "is this data being written?"
git log --oneline -- affected_dir/ | head -5

# Verify: "is this cron job running?"
ps aux | grep script_name
crontab -l | grep script_name
```

### Step 0.6: Executive Summary Format

Structure findings as:

```
[Question] The user's actual question
  ↓
[Finding] What the data shows (with numbers, not adjectives)
  ↓
[Diagnosis] Why it's happening (root cause, not symptom)
  ↓
[What's NOT the issue] Ruled-out hypotheses
  ↓
[Options] Decision points with trade-offs
```

This forces evidence-first thinking and prevents jumping to a plausible-but-wrong diagnosis.

**Reference:** See `references/silent-failure-agent-medici.md` for a worked example — a multi-node agent system where all pipelines were "running" but no lessons were being produced.

**Reference (browser/JS):** See `references/browser-js-debugging.md` for client-side silent JS failures on static pages (GitHub Pages, etc.) — page loads with no errors shown but data never renders.

---

## Phase 1: Root Cause Investigation

**BEFORE attempting ANY fix:**

### 1. Read Error Messages Carefully

- Don't skip past errors or warnings
- They often contain the exact solution
- Read stack traces completely
- Note line numbers, file paths, error codes

**Action:** Use `read_file` on the relevant source files. Use `search_files` to find the error string in the codebase.

### 2. Reproduce Consistently

- Can you trigger it reliably?
- What are the exact steps?
- Does it happen every time?
- If not reproducible → gather more data, don't guess

**Action:** Use the `terminal` tool to run the failing test or trigger the bug:

```bash
# Run specific failing test
pytest tests/test_module.py::test_name -v

# Run with verbose output
pytest tests/test_module.py -v --tb=long
```

### 3. Check Recent Changes

- What changed that could cause this?
- Git diff, recent commits
- New dependencies, config changes

**Action:**

```bash
# Recent commits
git log --oneline -10

# Uncommitted changes
git diff

# Changes in specific file
git log -p --follow src/problematic_file.py | head -100
```

### 4. Gather Evidence in Multi-Component Systems

**WHEN system has multiple components (API → service → database, CI → build → deploy):**

**BEFORE proposing fixes, add diagnostic instrumentation:**

For EACH component boundary:
- Log what data enters the component
- Log what data exits the component
- Verify environment/config propagation
- Check state at each layer

Run once to gather evidence showing WHERE it breaks.
THEN analyze evidence to identify the failing component.
THEN investigate that specific component.

### 5. Trace Data Flow

**WHEN error is deep in the call stack:**

- Where does the bad value originate?
- What called this function with the bad value?
- Keep tracing upstream until you find the source
- Fix at the source, not at the symptom

**Pitfall: Global vs Per-Group Index in Grouped Data Generation**

When generating data in groups (e.g. 16 rows per group, skip some rows), using **global row numbers** for skip/filter logic causes cross-group data leakage. The skip condition `if row in (3, 4)` only fires for the absolute rows 3 and 4 (first group), but subsequent groups silently include the "should-be-skipped" indices, pulling stale values from the previous group's state.

**Symptom:** Each group's first N entries show the *previous* group's values. The error compounds — group 3 has 2 wrong entries, group 4 has 4, etc.

**Root cause:** The skip logic uses a global counter instead of per-group position. After the first group, `row` is never 3 or 4 again, so the skip never fires.

**Fix:** Use per-group index for skip/filter logic:
```python
# WRONG: global row number
for i in range(16):
    if current_row in (2, 3):  # only fires for first group!
        continue

# RIGHT: per-group index
SKIP_IDXS = {2, 3}  # indices within each 16-element group
for i in range(16):
    if i in SKIP_IDXS:
        continue
```

**Reference:** See `references/grouped-data-gen-global-vs-local-index.md` for a full worked example with debugging steps.

---

**Pitfall: `break` + unconditional `exit 1` after `done` in while loops**

When a while loop uses `break` on success, followed by an unconditional `exit 1` after `done`:

```bash
while condition; do
    if command; then
        break       # ← exits the while loop
    fi
done
exit 1  # ← ALWAYS executes, even after break!
```

**Symptom:** The command succeeds (visible in logs, API state, or resource timestamps), but the enclosing step/job always reports failure (exit code 1). Dependent steps never execute.

**Root cause:** `break` exits the while loop body but execution continues to the statement immediately *after* `done`. An unconditional `exit 1` placed after `done` fires regardless of whether `break` was called — it catches loop exhaustion AND successful exits alike.

This is the most common shell scripting anti-pattern in CI/CD workflow scripts. It manifests as "push succeeded but workflow failed."

**Fix:** Use a flag variable:

```bash
SUCCESS=false
while condition; do
    if command; then
        SUCCESS=true
        break
    fi
done
if [ "$SUCCESS" != "true" ]; then
    echo "FATAL: All attempts exhausted"
    exit 1
fi
# Execution continues here only on success
```

**Detection hint in logs:** If a retry loop completed successfully (verified via API state: resource was updated with the correct timestamp) but the step shows `exit code 1` and ran suspiciously fast (e.g., 1 second for a loop with 2-second retry intervals), the `break`+`exit` pattern is the most likely cause. The loop exited on the first attempt but immediately triggered the unconditional `exit 1`.

**Reference:** See `references/ci-debugging-timestamp-correlation.md` for a worked example with timestamps.

**Reference:** See `references/grouped-data-gen-global-vs-local-index.md` for a full worked example with debugging steps.

**Action:** Use `search_files` to trace references:

```python
# Find where the function is called
search_files("function_name(", path="src/", file_glob="*.py")

# Find where the variable is set
search_files("variable_name\\s*=", path="src/", file_glob="*.py")
```

### Phase 1 Completion Checklist

- [ ] Error messages fully read and understood
- [ ] Issue reproduced consistently
- [ ] Recent changes identified and reviewed
- [ ] Evidence gathered (logs, state, data flow)
- [ ] Problem isolated to specific component/code
- [ ] Root cause hypothesis formed

**STOP:** Do not proceed to Phase 2 until you understand WHY it's happening.

---

## Phase 2: Pattern Analysis

**Find the pattern before fixing:**

### 1. Find Working Examples

- Locate similar working code in the same codebase
- What works that's similar to what's broken?

**Action:** Use `search_files` to find comparable patterns:

```python
search_files("similar_pattern", path="src/", file_glob="*.py")
```

### 2. Compare Against References

- If implementing a pattern, read the reference implementation COMPLETELY
- Don't skim — read every line
- Understand the pattern fully before applying

### 3. Identify Differences

- What's different between working and broken?
- List every difference, however small
- Don't assume "that can't matter"

### 4. Understand Dependencies

- What other components does this need?
- What settings, config, environment?
- What assumptions does it make?

---

## Phase 3: Hypothesis and Testing

**Scientific method:**

### 1. Form a Single Hypothesis

- State clearly: "I think X is the root cause because Y"
- Write it down
- Be specific, not vague

### 2. Test Minimally

- Make the SMALLEST possible change to test the hypothesis
- One variable at a time
- Don't fix multiple things at once

### 3. Verify Before Continuing

- Did it work? → Phase 4
- Didn't work? → Form NEW hypothesis
- DON'T add more fixes on top

### 4. When You Don't Know

- Say "I don't understand X"
- Don't pretend to know
- Ask the user for help
- Research more

---

## Phase 4: Implementation

**Fix the root cause, not the symptom:**

### 1. Create Failing Test Case

- Simplest possible reproduction
- Automated test if possible
- MUST have before fixing
- Use the `test-driven-development` skill

### 2. Implement Single Fix

- Address the root cause identified
- ONE change at a time
- No "while I'm here" improvements
- No bundled refactoring

### 3. Verify Fix

```bash
# Run the specific regression test
pytest tests/test_module.py::test_regression -v

# Run full suite — no regressions
pytest tests/ -q
```

### 4. If Fix Doesn't Work — The Rule of Three

- **STOP.**
- Count: How many fixes have you tried?
- If < 3: Return to Phase 1, re-analyze with new information
- **If ≥ 3: STOP and question the architecture (step 5 below)**
- DON'T attempt Fix #4 without architectural discussion

### 5. If 3+ Fixes Failed: Question Architecture

**Pattern indicating an architectural problem:**
- Each fix reveals new shared state/coupling in a different place
- Fixes require "massive refactoring" to implement
- Each fix creates new symptoms elsewhere

**STOP and question fundamentals:**
- Is this pattern fundamentally sound?
- Are we "sticking with it through sheer inertia"?
- Should we refactor the architecture vs. continue fixing symptoms?

**Discuss with the user before attempting more fixes.**

This is NOT a failed hypothesis — this is a wrong architecture.

---

## Red Flags — STOP and Follow Process

If you catch yourself thinking:
- "Quick fix for now, investigate later"
- "Just try changing X and see if it works"
- "Add multiple changes, run tests"
- "Skip the test, I'll manually verify"
- "It's probably X, let me fix that"
- "I don't fully understand but this might work"
- "Pattern says X but I'll adapt it differently"
- "Here are the main problems: [lists fixes without investigation]"
- Proposing solutions before tracing data flow
- **"One more fix attempt" (when already tried 2+)**
- **Each fix reveals a new problem in a different place**

**ALL of these mean: STOP. Return to Phase 1.**

**If 3+ fixes failed:** Question the architecture (Phase 4 step 5).

## Common Rationalizations

| Excuse | Reality |
|--------|---------|
| "Issue is simple, don't need process" | Simple issues have root causes too. Process is fast for simple bugs. |
| "Emergency, no time for process" | Systematic debugging is FASTER than guess-and-check thrashing. |
| "Just try this first, then investigate" | First fix sets the pattern. Do it right from the start. |
| "I'll write test after confirming fix works" | Untested fixes don't stick. Test first proves it. |
| "Multiple fixes at once saves time" | Can't isolate what worked. Causes new bugs. |
| "Reference too long, I'll adapt the pattern" | Partial understanding guarantees bugs. Read it completely. |
| "I see the problem, let me fix it" | Seeing symptoms ≠ understanding root cause. |
| "One more fix attempt" (after 2+ failures) | 3+ failures = architectural problem. Question the pattern, don't fix again. |

## Quick Reference

| Phase | Key Activities | Success Criteria |
|-------|---------------|------------------|
| **1. Root Cause** | Read errors, reproduce, check changes, gather evidence, trace data flow | Understand WHAT and WHY |
| **2. Pattern** | Find working examples, compare, identify differences | Know what's different |
| **3. Hypothesis** | Form theory, test minimally, one variable at a time | Confirmed or new hypothesis |
| **4. Implementation** | Create regression test, fix root cause, verify | Bug resolved, all tests pass |

## Hermes Agent Integration

### Investigation Tools

Use these Hermes tools during Phase 1:

- **`search_files`** — Find error strings, trace function calls, locate patterns
- **`read_file`** — Read source code with line numbers for precise analysis
- **`terminal`** — Run tests, check git history, reproduce bugs
- **`web_search`/`web_extract`** — Research error messages, library docs

### With delegate_task

For complex multi-component debugging, dispatch investigation subagents:

```python
delegate_task(
    goal="Investigate why [specific test/behavior] fails",
    context="""
    Follow systematic-debugging skill:
    1. Read the error message carefully
    2. Reproduce the issue
    3. Trace the data flow to find root cause
    4. Report findings — do NOT fix yet

    Error: [paste full error]
    File: [path to failing code]
    Test command: [exact command]
    """,
    toolsets=['terminal', 'file']
)
```

### With test-driven-development

When fixing bugs:
1. Write a test that reproduces the bug (RED)
2. Debug systematically to find root cause
3. Fix the root cause (GREEN)
4. The test proves the fix and prevents regression

## Real-World Impact

From debugging sessions:
- Systematic approach: 15-30 minutes to fix
- Random fixes approach: 2-3 hours of thrashing
- First-time fix rate: 95% vs 40%
- New bugs introduced: Near zero vs common

**No shortcuts. No guessing. Systematic always wins.**
