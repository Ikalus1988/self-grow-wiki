---
name: claim-verification-audit
description: Given a list of claims/assertions (e.g. from a design doc, spec, or project task), verify each one against the actual codebase — code existence, integration completeness, and runtime state. Produces a structured per-claim verdict.
tags: [audit, verification, claims, forensic, code-review, design-review]
triggers:
  - "verify claims against codebase"
  - "audit claims"
  - "does this feature actually exist"
  - "verify that X is implemented"
  - "feature verification"
  - "design doc audit"
  - "MEDICI audit"
  - "is this actually implemented"
  - "cross-repo audit"
  - "multi-repo claim check"
  - "ground the proposal against reality"
  - "review AI co-pilot strategy"
---

# Claim Verification Audit

Given a set of claims or assertions (from a design doc, specification, project task, or user statement), verify each one against the actual codebase. This is a **forensic audit** — not a maturity assessment, but a truth-verification: does the claimed feature exist, is it integrated, and is it running?

## When to Use

- User provides a list of claimed features/design statements and asks "verify these"
- User asks "is X actually implemented?" about a whole feature set
- During a design review when evaluating whether stated capabilities match reality
- After reading a design/spec document, to check which parts are actually built

## Multi-Repo Audits (Cross-Repo Verification)

When claims reference files/features in one repo but the workspace contains multiple related repos, **do NOT limit verification to the named repo**. Common workspace patterns that trip this up:

| Workspace pattern | Concrete example | Confusion risk |
|-------------------|------------------|----------------|
| Engine layer + collaboration layer | `self-grow-wiki` (RAG engine, private) + `MisakaNet` (SKP network, public) | Strategy says "extract `log_db.py`" but `contribute.py --wizard` already exists in MisakaNet — the user forgot which repo owns the feature |
| Monorepo → multi-repo split | Main repo + sidecar repos per decoupling plan | Feature may have been moved; claim references pre-split path |
| Public mirror of private repo | `Ikalus1988/public` (mirror) + private repo (source) | Code verified in mirror may not reflect working-tree state |

### Pre-flight: discover sibling repos

Before Phase 1, list all related repos in the user's workspace. The named repo is rarely the only candidate:

```bash
# List candidate project roots
ls -la /home/hp/ ~/Projects/ /mnt/c/Users/*/ 2>/dev/null | grep -E "wiki|MisakaNet|rag|skill"

# For each candidate, record role via README/AGENTS.md
head -30 <candidate>/AGENTS.md <candidate>/README.md

# Check git remotes — names reveal engine-vs-public relationships
git -C <repo> remote -v
```

Document the role of each repo (engine layer? SKP layer? docs site? mirror?) so claim-to-repo mapping is explicit in the final report. Add a one-line legend like:

```
self-grow-wiki (private, engine layer) — RAG core, rag_core.py, lessons/
MisakaNet    (public, SKP layer)     — search, contribute, Quality Score, archive/
```

### Pitfalls specific to multi-repo audits

- **"Build X" claims often duplicate existing work in a sibling repo.** When `X.py` doesn't exist in repo A, search repo B before declaring it doesn't exist. The user often does not realize their strategy is a duplicate. Distinguish **VERDICT: DUPLICATE (exists in sibling repo)** from **VERDICT: FALSE (does not exist anywhere)** — they lead to different recommendations (link vs. create).

- **Same scheme name ≠ same implementation across repos.** Names like "A1 方案", "Quality Gate", "log_db 改造" mean different things in different repos. Always cite the **file path** alongside the scheme name when verifying. Example: `"A1 方案 (MisakaNet/docs/decoupling-plan.md = monorepo→3 repos)"` vs `"A1 方案 (self-grow-wiki/docs/engineering-roadmap.md §5 = SQLite WAL + async queue)"`.

- **Cross-repo data flows.** If repo A writes JSONL that repo B ingests, a "broken" claim about A may actually be a missing-file claim about B's expected input. Trace the actual producer/consumer link.

- **Working-tree vs remote divergence matters more in multi-repo.** The named repo may be at HEAD, but the sibling repo (where the strategy actually applies) may have stale clones or diverged branches. Pull each before claiming — and report pull failures (HTTPS without PAT, gh auth failures) honestly so the user knows which verdicts are confident.

- **Path aliases are common.** `~/MisakaNet`, `/mnt/c/Users/hp/MisakaNet`, and Windows paths may all point to the same repo. Confirm canonical location via `git rev-parse --show-toplevel` before citing paths.

## Distinction from Similar Skills

| Skill | Scope | Output |
|-------|-------|--------|
| `claim-verification-audit` (this) | **Specific claims** — does each claimed feature exist? | Per-claim verdict: TRUE/PARTIAL/FALSE + evidence |
| `project-completeness-assessment` | **Holistic maturity** — how complete/ready is the project? | Scored dimensions (retrieval, robustness, etc.) |
| `github-repo-architecture-review` | **Architectural quality** — design flaws, security, code quality | P0-P3 severity-graded issues |
| `systematic-debugging` | **Root cause** — why is something broken? | Root cause + fix |

Do NOT use this skill for holistic maturity scoring, architectural critique, or debugging — use the skills above for those.

## Procedure

### Phase 1: Parse and Categorize Claims

Take the user's input and decompose it into individual verifiable statements. Each claim should be a single atomic assertion.

Number them for the final report. Group related claims where they share evidence paths.

For each claim, determine **what type of verification it needs**:

| Type | What to Check | Example |
|------|---------------|---------|
| **Code existence** | Does the code exist in source files? | "There is a confidence score calculation" |
| **Integration** | Is it wired into the actual workflow? Does any code path actually call it? | "Multi-version parallel storage with pending arbitration" |
| **Runtime** | Is it actually running as a process? Listening on ports? Producing output? | "The arbitration module is running" |
| **Data** | Does the database/storage contain expected records? | "There are pending arbitration cases" |

### Phase 2: Evidence Gathering

For each claim, systematically gather evidence. Do NOT go claim-by-claim linearly — batch related searches to minimize round trips.

**2a. Keyword Search**

Start with broad keyword search across the codebase:

```
search_files(pattern="arbitrat|arbitrate|arbitration|pending_arb")  # expand for variants
```

Use multiple keyword variants:
- Exact feature names (e.g., `arbitration_queue`, `ConfidenceModel`)
- Status values (`pending`, `resolved`, `expired`)
- API endpoints (`/arbitration/cases`, `/arbitration/resolve`)
- Import statements (`from orchestrator.arbitration_queue import`)
- Config keys (`arbitration`, `confidence`)
- Claim-specific terms from the user's original phrasing

**2b. File Inventory**

List source files in relevant directories to understand what exists:

```
find ~/project/orchestrator/ -type f | sort
ls -la ~/project/storage/
```

Key artifacts to look for:
- Module files (`.py` for Python, `.ts` for TypeScript, etc.)
- Database files (`.db`, `.sqlite`)
- Data directories (knowledge_graph, vector_store)
- Test files
- Config files

**2c. Read Core Files**

Read the key source files for each claim. For each file, note:
- What the module/class does (from docstring)
- Whether it's marked as dead code
- Whether it's imported/instantiated in the main service
- Whether `.start()` or `.run()` is actually called

When a file has a comment like "DEAD CODE" or "marked as dead code", treat that as strong evidence the feature is NOT running.

**2d. Runtime Verification**

Check if the claimed module is actually executing:

```
# Processes
ps aux | grep -E "service_name|script_name|module_name"

# Listening ports
ss -tlnp | grep -E "8080|8081|configured_port"

# Systemd services (user level)
systemctl --user list-units --type=service | grep -i service_name

# Cron jobs
crontab -l | grep -i project_name

# Database state
sqlite3 storage/database.db ".tables"
sqlite3 storage/database.db "SELECT COUNT(*) FROM table_name;"
sqlite3 storage/database.db "SELECT status, COUNT(*) FROM table_name GROUP BY status;"
```

**Pitfall: Open files vs. running processes.** When checking if a system is alive, beware of editors/IDEs that may have open file handles to the same paths your services use. A `lsof` match on a `.db` file or a script path could be from `vim`, `nano`, or VS Code, not from a running service. Prefer `ps aux` for process existence, `ss -tlnp` for port listeners, and `systemctl` for service status. Use `lsof` only to confirm that a **confirmed running process** (found via `ps`) actually has the expected database open.

### Phase 3: Verdict Assignment

For each claim, assign one of:

| Verdict | Meaning | When |
|---------|---------|------|
| **TRUE** | Fully implemented, integrated, and working | Code exists, is wired into the workflow, and confirmed running (or can be confirmed by data) |
| **PARTIALLY TRUE** | Code exists but has gaps: not fully integrated, not yet running, incomplete workflow | Data model exists but no trigger path; engine exists but not started; claim is partially accurate |
| **FALSE** | Code does not exist, or exists only as dead code/placeholder | No source file, marked dead code, or claim says "running" but no process exists |

### Phase 4: Structure the Report

Format as terminal-friendly plain text:

**Header:** One-line summary of overall finding (e.g., "4/5 claims verified, 1 critical gap")

**Per-claim detail:**
```
### (N) Claim Title — VERDICT

[1-2 sentence summary of finding]

Evidence:
- Code: `/path/to/file.py` — lines X-Y, what it does
- Integration: how it's called (or not called) — imports, call sites, start() calls
- Runtime: process status, port status, DB contents (if applicable)

Gap/Issue: what's missing (for PARTIAL or FALSE)
```

**Summary Table:**
| # | Claim | Verdict | Key Evidence |
|---|-------|---------|-------------|
| 1 | ... | TRUE | ... |
| 2 | ... | PARTIAL | ... |

**Key Observation:** If there's a structural pattern (e.g., "code is complete but deployment is missing"), call it out explicitly.

### Tone
- Direct, specific, evidence-first
- Cite exact file paths, line numbers
- No fluff or hedging — every claim gets a clear verdict
- Distinguish "the code exists" from "the code runs" — these are different truths

## Pitfalls

- **"Code exists" ≠ "code is running."** Always check runtime state separately.
- **"Code is imported" ≠ "code is started."** Check that `.start()` / `.run()` / service instantiation is actually called in the main entry point, not just in `__init__`.
- **"Code is wired up" ≠ "workflow is complete."** A feature may have all the right modules but no trigger path that creates the input it expects.
- **Dead code annotations matter.** If the author marked something DEAD CODE, treat it as not existing for operational purposes.
- **Don't trust commit timestamps for runtime state.** A file last modified weeks ago may still be running via cron/systemd; a file just committed may not be deployed yet.
- **Empty databases.** A `.db` file can exist with just its schema (zero rows) — that means the feature is wired to write but has never actually produced a record.
- **Verify with the actual tools, don't infer.** `search_files` showing 33 matches means the codebase has references — it doesn't mean the workflow works. Trace the actual execution path.
- **Tool output redaction false positives.** Commands like `read_file` or `grep` may redact values they classify as secrets by replacing them with `***`. Before reporting a "broken syntax" or "missing value" error in config/DB files, verify it's not tool-side redaction. For Python files, use `python3 -c "import py_compile; py_compile.compile('path.py', doraise=True)"` to check syntax.
- **"Not found in named repo" ≠ "not found anywhere."** See Multi-Repo Audits above — search sibling repos before declaring a claim FALSE.

## Reference

See `references/medici-02-audit.md` for a worked example — a 5-claim audit of the Agent-Medici arbitration module.
