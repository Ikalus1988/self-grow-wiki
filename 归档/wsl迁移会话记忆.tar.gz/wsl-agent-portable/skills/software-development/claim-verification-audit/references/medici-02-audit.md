# MEDICI-02 Audit — Worked Example

This reference documents the actual MEDICI-02 claims audit performed against the Agent-Medici codebase on 2026-05-04. It serves as a concrete worked example for future claim-verification audits.

## Input Claims

Five claims about an arbitration module:
1. Multi-version parallel storage with 'pending arbitration' status exists
2. Confidence score calculation exists (node authority, time decay, cross-validation)
3. Feishu interactive card arbitration exists
4. Arbitration result write-back exists
5. The arbitration module is actually running

## Evidence Gathering

### Phase 1: Keyword Search

```
search_files(pattern="arbitrat|arbitrate|arbitration|pending_arb|pending-arb|FEISHU_ARBIT")
# → 33 matches across 7 files
```

Key files discovered:
- `orchestrator/arbitration_queue.py` — ArbitrationCase dataclass, SQLite storage
- `orchestrator/confidence.py` — ConfidenceModel with authority/time/cross factors
- `sync/feishu_notifier.py` — Interactive card builder with buttons
- `hermes_hub.py` — Main hub orchestrating all arbitration logic
- `sync/a2a_server.py` — HTTP endpoints for arbitration

### Phase 2: Read Core Files

**arbitration_queue.py** (220 lines):
- `ArbitrationCase` dataclass: id, skill_id, skill_name, `versions: list`, `status: str` (pending/resolved/expired)
- `ArbitrationQueue` with SQLite backend at `./storage/arbitration.db`
- Table schema: `CREATE TABLE IF NOT EXISTS arbitration_cases (id TEXT PRIMARY KEY, ..., status TEXT DEFAULT 'pending', ...)`
- Full CRUD: `create_case()` → store multiple versions as JSON; `get_pending_cases()` → WHERE status='pending'; `resolve_case()` → UPDATE status='resolved'

**confidence.py** (109 lines):
- `ConfidenceModel` with three-factor calculation: `authority × time_factor × cross_factor`
- `get_authority(node_id)` → default 0.5, range [0.1, 1.0]
- `calc_time_factor(indexed_at)` → `e^(-0.001 * days_since_indexed)`
- `calc_cross_factor(source_count)` → 1=0.8, 2=0.95, 3+=1.0
- `update_after_arbitration(winner_id, loser_ids)` → winner +0.1, loser -0.05

**feishu_notifier.py** (156 lines):
- `notify_arbitration_case(case, feishu_webhook)` → sends interactive card to Feishu webhook
- Card header: "⚖️ 仲裁请求: {skill_name}" (red template)
- Elements: version descriptions list + per-version button ("选择 v1", "选择 v2", etc.)
- Each button carries: `{"action": "arbitrate", "case_id": ..., "winner_id": ...}`

**hermes_hub.py** (331 lines):
- Constructor: initializes `arbitration_queue`, `confidence_model`, `feishu_notifier`, `feishu_ws_client`
- `_register_feishu_callbacks()`: wires `handle_card_action()` (button clicks → resolve_arbitration) and `handle_feishu_message()` (text parsing for "选择 v1" / "保留 xxx")
- `resolve_arbitration()`: fetches case → resolves in queue → recalculates confidence → register_skill(winner) → update_after_arbitration()
- `start()` method: note A2A server start is **commented out** with dead code annotation
- `get_status()` reports arbitration queue stats

### Phase 3: Runtime Verification

```
# Process check
ps aux | grep hermes_hub
# → NO results — module is NOT running

# Port check
ss -tlnp | grep -E "8080|8081"
# → NO ports listening

# Database check
ls -la storage/arbitration.db → exists, 12KB (Apr 30)
sqlite3 storage/arbitration.db ".tables" → NO tables (empty schema-only DB)
sqlite3 storage/arbitration.db "SELECT COUNT(*) FROM arbitration_cases" → 0 rows

# Cron check
crontab -l | grep medici → feedback_report, standby_poller, draft_reminder (no hub)
```

### Phase 4: Integration Check

Critical finding in `skill_indexer.py` (the actual conflict detection logic):
- `register_skill()` has three outcomes: ADD (new skill), MERGE (similarity > 0.92, merge sources), LINK (similarity > 0.75, add relationship edge)
- **There is NO code path that calls `arbitration_queue.create_case()`**
- When a conflict is detected (similarity in some range), it silently merges or links — never triggers arbitration

Also in `dedup_engine.py`:
- Marked as **DEAD CODE** at the top: "语义去重已在 SkillIndexer.register_skill() 内建实现"
- Has a `resolve_conflict()` method with strategies (latest/source_priority/highest_confidence), but it's unreachable

## Final Verdicts

| # | Claim | Verdict | Key Evidence |
|---|-------|---------|-------------|
| 1 | Multi-version parallel storage with 'pending' status | PARTIALLY TRUE | Data model + SQLite schema exist for storing parallel versions with pending status, but no code path triggers create_case() from conflict detection |
| 2 | Confidence score calculation | TRUE | Full implementation of authority × time_decay × cross_validation in confidence.py |
| 3 | Feishu interactive card arbitration | TRUE | Interactive card with per-version buttons + callback handling in feishu_notifier.py + hermes_hub.py |
| 4 | Arbitration result write-back | TRUE | Complete pipeline: resolve_case() → register_skill(winner) → update_after_arbitration() |
| 5 | Module is actually running | FALSE | No process, no ports, empty DB, commented-out start(), dead code annotation on A2A server |

## Key Structural Insight

The codebase has a **deployment gap**: all arbitration modules are fully coded and importable, but the hub service that wires them together (`hermes_hub.py`) is never started. The A2A server is explicitly marked as dead code. The arbitration database exists as an empty schema — no cases have ever been created because no code path triggers `create_case()`.

This is a specific flavor of "code exists but system is dead" — the architecture was designed to a higher level than the deployment reality.
