# Goal Alignment / Gap Analysis Methodology

A structured framework for comparing current state against a desired goal. Use when the user asks "what's next" or "how far are we from the target."

## Core Question

> "Where are we now vs where we need to be, and what's the highest-ROI next step?"

## The 4-Layer Assessment

Map progress across four layers of a system's lifecycle:

| Layer | Description | Typical questions |
|-------|-------------|-------------------|
| **L0: Foundation** | Core functionality works | Can users discover it? Can they sign up? Does the core loop run? |
| **L1: Growth/Discovery** | Users can find the project | SEO, social posts, forums, word of mouth, domain |
| **L2: Activation** | Users complete the onboarding | Registration → first value → activation rate |
| **L3: Retention** | Users come back | Notifications, feed, stats, personal dashboard |
| **L4: Flywheel** | Self-sustaining content loop | Auto-generated content, contributions from users, network effects |

For each layer, answer:
- **Completion %** (visual progress bar)
- **What's done** (specific features, data, metrics)
- **What's missing** (gap to target, e.g. "need 100 users, have 15")
- **Effort to close** (low/medium/high)

## Output Format

Present as a concise table with emoji status:

```
L0 基础:   ████████████████░░  80%  (核心功能就绪)
L1 增长:   ██░░░░░░░░░░░░░░░░  10%  (零推广)
L2 激活:   █████░░░░░░░░░░░░░  30%  (注册通了, 激活未)
L3 留存:   █░░░░░░░░░░░░░░░░░   5%  (无人回来)
L4 飞轮:   ██████░░░░░░░░░░░░  35%  (有个架子, 没内容)
```

Then a **gap detail** per layer listing specific metrics and blockers.

## Prioritization: Effort vs Impact

Order recommendations from easiest to hardest, showing both effort and expected impact:

| Priority | Action | Effort | Impact | Why now |
|----------|--------|--------|--------|---------|
| P0 | Fix onboarding | 1 hour | High | 15 users registered, 0 activated — biggest leak |
| P0 | Expand content | 2 hours | High | Need 60+ lessons for credibility |
| P1 | SEO + social | 30 min | Medium | No organic traffic at all |
| P2 | Domain setup | 15 min | Low | Trust signal, no growth impact |

## Decision Rule: YAGNI

For each gap, ask: "Is fixing this necessary to reach the next milestone, or is it premature optimization?"

**Skip if:**
- Requires infrastructure for N users when you have << N
- Solves a problem that hasn't happened yet
- Adds complexity without immediate user-facing value

**Do if:**
- Blocks the next growth experiment
- Fixes a user-facing frustration that's been reported
- Increases confidence in the core loop working at scale
