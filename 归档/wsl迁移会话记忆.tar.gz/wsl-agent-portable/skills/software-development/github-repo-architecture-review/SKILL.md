---
name: github-repo-architecture-review
description: "Clone a GitHub repo and produce a critical architectural review — security, design, code quality, structural issues. Severity-graded (P0-P3). When user says '评价/挑刺/review这个项目/repo' or shares a GitHub URL asking for assessment."
tags: [architecture, review, github, security, code-quality, audit]
triggers:
  - "评价这个项目"
  - "挑刺"
  - "架构评审"
  - "review this repo"
  - "architectural review"
  - "code audit"
  - "看看这个项目怎么样"
---

# GitHub Repository Architecture Review

Produce a severity-graded architectural critique of a GitHub repository.

## Procedure

1. **Clone & Survey**
   - `git clone` the repo to `/tmp/<repo-name>`
   - Read README.md for stated goals, architecture description
   - `find . -type f` to understand structure, count files
   - `git log --oneline -20` for project maturity/commit patterns
   - **Scan git history for leaked secrets** — old commits may still hold credentials even if HEAD uses placeholders:
     ```
     git log -p --all -- <sensitive-files> | grep -E 'app_secret|api_key|password|token'
     git log --oneline --diff-filter=A -- <config-file>  # find when it was first created
     git show <initial-commit>:<file>                     # check if secrets were ever committed
     ```
   - **Check `.gitignore` effectiveness** — files listed in `.gitignore` that were committed before `.gitignore` was added are still tracked:
     ```
     git ls-files | head -20  # quick sanity
     # If config files with secrets are tracked despite .gitignore, they need git rm --cached
     ```
   - **Audit for committed runtime data**: SQLite DBs (`*.db`), log files, stats snapshots — none of these belong in git and will cause merge conflicts:
     ```
     git ls-files '*.db' '.hook_stats/*' '*.log' '*.gpickle' '__pycache__/*'
     ```

2. **Read All Source Files**
   - Read every `.py`, `.js`, `.ts`, `.yaml`, `.toml`, `.sh` file (skip `__pycache__`, `node_modules`, `.git`)
   - Note dependencies (requirements.txt, package.json, go.mod)

3. **Evaluate Against This Checklist**

   **P0 — Critical (blocks production)**
   - Hardcoded secrets/credentials in source (API keys, app secrets, passwords in config.yaml that was committed)
   - Authentication missing on public-facing endpoints
   - Unsafe deserialization (pickle.load, eval, exec from untrusted input)
   - Core logic is a stub/placeholder (fake embeddings, no-op functions, broadcast that only prints)
   - Code that literally cannot run (syntax errors like broken f-strings, undefined variables, import errors)
   - Git-tracked build artifacts (__pycache__/*.pyc committed despite .gitignore)

   **P1 — Major Architecture Defects**
   - **Notification/alerting gap — data lands in storage but no one gets notified** — A common blind spot: tracing data flow stops at the database or filesystem. If the system produces meaningful output (lessons, alerts, reports) but the human has no way to know it happened, the pipeline is effectively silent. For every write path, ask: "does a notification, message, or dashboard update reach a human?" If not, flag as P1 — the data exists but the system's value depends on someone acting on it. This applies regardless of how polished the data pipeline is; a perfect write path with no reader is a one-way ticket to user abandonment.
   - Dead code / unreachable branches (copy-paste bugs)
**Components created but never started** — objects instantiated in `__init__` whose `.start()` is never called in the actual `start()`/`run()` method. Common pattern: constructor wires up all dependencies, then forgets to boot them. Check by tracing each construction call against every `.start()`/`.run()` call in the main service's `start()` method. Look for mismatches — constructed but never started means the entire feature is dead code.
   - **Parallel redundant subsystems** — two independent implementations of the same responsibility (e.g., two embedding models, two query parsers, two storage backends) with no coordination and no documented reason. Check if they share state or are completely disconnected code paths.
   - **Latent crashes in error/fallback paths** — code that works in the happy path but has `NameError`, `AttributeError`, or `KeyError` in the exception handler. The classic pattern: `handler → success → return` works, but `handler → error → crash` is a latent bug because the error path was never tested. Check error branches of every function.
   - **AST-based cross-reference verification** — use Python's `ast` module to verify that cross-module attribute references actually exist. A common pattern: `self.hub.vector_store.delete_skill(skill_id)` where `vector_store` is never created in `HermesHub.__init__`:
     ```python
     import ast
     tree = ast.parse(open('target.py').read())
     for node in ast.walk(tree):
         if isinstance(node, ast.Attribute) and 'vector_store' in node.attr:
             print(f"Reference at line {node.lineno}")
     ```
   - God objects (single class owns 10+ components, no DI)
   - Multiple storage backends with no transaction coordination
   - Thread safety issues in async/concurrent code
   - Instance inconsistency (creating new instances instead of sharing)
   - Stub implementations that break the stated design (e.g., A2A broadcast that only prints, embedding that is a hash)
   - **Claimed features that don't actually work** — check if the repo's stated capabilities (e.g., "Agent-to-Agent communication", "semantic dedup") have real implementations or are placeholders
   - Single-commit repo with no development history

   **P2 — Code Quality**
   - Bare `except:` swallowing all exceptions (not just `except Exception:` — check for plain `except:` too)
   - Missing input validation on external-facing APIs
   - No zero-division / null guards in math operations
   - **Git log quality** — check for noise commits (identical messages, auto-generated commits every flush): `git log --oneline | sort | uniq -c | sort -rn | head -5`. If most commits say the same thing, the auto-push pipeline is polluting the history.
   - **`os.chdir()` in concurrent or async contexts** — `os.chdir()` changes the global process CWD. If used before `git add/commit/push`, and multiple code paths could call it concurrently, one call will corrupt another's CWD. The fix: use `subprocess.run(cwd=...)` or `Path.cwd()` instead.
   - **Inconsistent hardcoded defaults across parallel scripts** — the same configuration value (NODE_ID, BASE_URL, MODEL_PATH) hardcoded differently in sibling scripts that should share defaults. Check: `grep -rn 'NODE_ID\s*=\|PORT\s*=\|BASE_URL\s*=' --include="*.py" | sort`. If two scripts in the same directory have different defaults for the same config key, it's a coordination defect.
   - Performance anti-patterns (N disk writes in a loop, no connection pooling)
   - Dependencies missing from requirements
   - `.pyc` / `__pycache__` committed, missing `.gitignore` (or .gitignore exists but files were tracked before it)
   - Concurrent models mixed in same process (threading + asyncio)
   - Repeated SQLite connections per-call instead of connection pooling

   **Frontend Web App — additional checklist (SPA / dashboard / HTML+JS)**

   **P0 — Security (client-side)**
   - **Tokens in client-side source code** — hex/base64 encoded tokens in HTML/JS that grant write access to backend APIs. Even trivial encoding (hex, base64, ROT13) is NOT security by obscurity — the decoding logic is in the same file. The attacker just reads the JS. Accept only as a conscious trade-off for zero-friction onboarding, and document the scope explicitly (e.g., "Issues:write on this single repo only"). Check: `grep -rn 'github_pat_\\|ghp_\\|ghs_\\|gho_' --include='*.html' --include='*.js'`. Flag as P0 even if hex-encoded.
   - **API key / secret in URL-accessible files** — secrets in publicly-served `.md`, `.txt`, `.json`, or any static asset that a browser can fetch. Same severity as P0 for code.

   **P1 — Architecture (frontend)**
   - **State change triggering unnecessary API calls** — e.g., a language toggle button that re-fetches ALL data from the backend instead of just re-applying translations. Check: does the UI framework re-render from scratch on every trivial event, or only when data actually changed?
   - **CI/CD race conditions on shared state files** — GitHub Actions workflows that run concurrently (same trigger) and both READ-MODIFY-WRITE the same file (counter.json, stats.json, any shared state). Fix: atomic read-increment-write-push with retry on push conflict. Without this, concurrent runs silently assign the same ID twice.
   - **Public form without server-side rate limiting** — client-side rate limits are cosmetic. If a web form uses a token that creates backend resources (issues, commits, DB rows), anyone can script it to flood the system. Accept only as a conscious trade-off, document the token scope, and add a client-side throttle as a courtesy.

   **P2 — Code Quality (web-specific)**
   - **Dynamic content not wired into I18N system** — badges, timestamps, tooltips, and status labels rendered via JS that bypass the translation layer. Check: search for `textContent =` or `innerHTML =` assignments that hardcode strings instead of calling `t('key')`.
   - **Keyboard inaccessibility** — clickable `div` elements with `onclick` handlers that lack `tabindex`, `role`, `aria-checked`, and keyboard event handlers (Enter/Space). Fix: add `tabindex="0"`, `role`, `aria-*`, and a keydown listener for Enter/Space that calls the same handler.
   - **CSS hover/focus inconsistency** — some interactive elements have `:hover` styles, others don't. Some have `:focus-visible`, most don't. Check: do all clickable elements have both hover and focus-visible states?

   **P3 — Design Suggestions**
   - Version inconsistency across README/code/banners
   - No health checks / graceful degradation
   - Sync blocking in async context
   - No rate limiting
   - No backup/restore mechanism

   > See `references/public-webapp-review-case-study.md` for a real-world example of all 10 issue categories found in a single-page web app review (MisakaNet dashboard, 2026-05-10).

4. **Write Report** (plain text, terminal-friendly)
   - Group by severity: P0 → P1 → P2 → P3
   - Each issue: one-line title + 2-4 line explanation with file/line references
   - End with a summary: "what is this project" + "what it needs to go to production"
   - Tone: direct, specific, cite exact lines. No fluff.

## Post-Review: Fix & Push (when user says "fix/修复/修 it and push/上传")

If the user asks to fix the found issues after the review, run this systematic workflow.

### Fix Priority Order
Always fix P0 first, then P1, then P2. Skip P3 unless user explicitly asks.
When the user says "从易到难" or "逐个修", go from simplest change to most complex within each severity level -- not by impact. A one-line env var fix trumps a multi-file refactor even if both are P1.

### P0 Fix Patterns

**Hardcoded secrets in config.yaml/source:**
- Replace with `${ENV_VAR}` placeholders in YAML
- Add env var resolution to config loader (e.g., using `os.environ.get()` in Python)
- Create `config.yaml.example` with placeholder values
- Add `config.yaml` to `.gitignore`
- **Warn the user**: old commits still expose secrets. Recommend rotating credentials and optionally purging history with bfg/git filter-branch.

**__pycache__ tracked by git (despite .gitignore):**
- `git rm -r --cached __pycache__/` and all subdirectories
- Verify `.gitignore` has `__pycache__/` and `*.py[cod]`

**Broken syntax (f-strings, unterminated literals):**
- Use `python3 -c "import py_compile; py_compile.compile(path, doraise=True)"` to verify each fix

### P1 Fix Patterns

**Hash-based fake embedding → real embedding:**
- Lazy-load `SentenceTransformer` as singleton, fall back to hash with loud warning
- Default model: `BAAI/bge-base-zh-v1.5` for Chinese projects

**A2A broadcast/communication that only prints:**
- Replace with actual `aiohttp` HTTP POST to agent URLs
- Add proper error handling and timeout

**Hardcoded secrets in token/auth managers:**
- Read from config.yaml or environment variable instead of inline string

### P2 Fix Patterns

**Bare `except:` → `except Exception:`**
- Find with: `grep -rn "except:" --include="*.py"`
- Replace with `except Exception:`

**Auto-flush scripts polluting git log — add commit-only-if-changed guard**
When cron/auto scripts run `git add && git commit && git push` on every flush, identical commits pollute the log even when data hasn't changed.
Fix: add `git diff --cached --quiet` check before committing:
```python
subprocess.run(["git", "add", str(filepath)], capture_output=True)
has_changes = subprocess.run(
    ["git", "diff", "--cached", "--quiet", "--", str(filepath)],
    capture_output=True
).returncode == 1  # 0=no change, 1=has change
if not has_changes:
    return  # skip commit
subprocess.run(["git", "commit", ...])
```
Apply to ALL auto-commit call sites in the project (flush scripts, template fillers, cron jobs).

**Hardcoded deployment config (NODE_ID, paths) across multiple scripts**
Not just secrets — any deployment-specific value written as a string literal across multiple files. Systematic fix:
1. `grep -rn 'NODE_ID\s*=\s*"..."' --include="*.py"` to find all hardcoded instances
2. Replace each with `os.environ.get("VAR_NAME", "default_value")`
3. Ensure import `os` at top of each file
4. Check all configuration-type values: `TOKEN=`, `NODE_ID=`, `ROOT=`, `LESSONS_DIR=`, port numbers

**Dependencies missing from requirements.txt**
Cross-reference `import` statements in Python files against `requirements.txt`:
```bash
for f in $(find . -name '*.py' -not -path './.git/*'); do
    grep -Po '^import \K\w+|^from \K\w+' "$f"
done | sort -u | while read pkg; do
    grep -q "^$pkg" requirements.txt 2>/dev/null || echo "MISSING: $pkg"
done
```
Then add any missing packages. Distinguish stdlib vs third-party.

### Commit Strategy

By default, commit once at the end with a structured message grouping all fixes by severity.

But when the user says `从易到难逐个修` or wants to see progress, use the **incremental → squash** pattern:

**Pattern: incremental commits per severity level + squash before push**
```
P0 commits:   1-3 small commits as you work through them
P1 commits:   next few commits
P2 commits:   etc.
```

Then offer to squash before pushing:
```bash
# Find the commit before your first fix commit
git log --oneline  # identify the base commit
git reset --soft <base-commit-hash>
git commit -m "fix: <summary> — P0~P<max>

P0:
- <item 1>
- <item 2>

P1:
- <item 3>
..."
```

When to squash:
- The user explicitly asks to clean history
- All commits are from the same review session (no shared history with other developers)
- The incremental commits were for transparency during the fix, not for traceability

When NOT to squash:
- Other people have already pulled/forked from the incremental commits
- The user specifically wants each fix traceable in history

**Squash + push when remote got new commits during your session:**
After squashing, `git push` may be rejected with "non-fast-forward" if the remote received new commits while you were fixing (common in projects with cron/auto pipelines that commit while you work).

Procedure:
```bash
# 1. Check what's on remote
git fetch origin
git log --oneline origin/main -5

# 2. Assess the remote commits
# If they're non-conflicting auto-commits (like hook_stats snapshots, CI artifacts):
git push --force-with-lease origin main

# If they're meaningful work from another developer:
git rebase origin/main   # rebase your squashed commit on top
git push origin main     # normal push, no force needed
```

Then push. On a shared branch, use `--force-with-lease` instead of `--force`.

### Dead Code Annotation Pattern

When the review finds dead code (defined classes/functions that are never called), do NOT delete it — the code may be design reference for future activation. Instead:

1. Add a ⚠️ DEAD CODE header comment to the function/class docstring
2. If the dead code has a listener/startup call site (e.g., `await server.start()`), comment out the call site with a clear explanation and a block comment showing the activation path
3. Keep the import/construction — removing them would hide the dead code from future readers who search for class references

Example annotation:
```python
"""
Class Description

⚠️  DEAD CODE — [why it's dead, what replaced it].
保留供 [future activation scenario] 参考。
当前 [main service].start() 中已跳过此组件的启动。
"""
```

This keeps the codebase honest about what's actually running vs. what's aspirational, without losing the design investment.

### Files Tracked Before .gitignore Was Added

A common finding: a file is listed in `.gitignore` but still tracked by git. This happens when the file was committed to the repository BEFORE `.gitignore` was created or updated.

Fix pattern:
```bash
# Identify files that are tracked despite .gitignore
git ls-files --cached | grep -Ff <(git ls-files --others --ignored --exclude-standard)

# Remove from tracking (local file stays on disk)
git rm --cached config.yaml storage/arbitration.db storage/subscriptions.db

# Update .gitignore with any additional runtime data discovered during review
# (SQLite DBs, hook_stats, logs — check: git ls-files '*.db' '.hook_stats/*')

# Commit the removals + .gitignore update together
git commit -m "fix: git rm cached files now in .gitignore"
```

After this, any subsequent `git add` on these files will be blocked by `.gitignore`. The files remain on disk and continue working locally.

## Cross-Repo Benefit Analysis

The standard review above evaluates one repo in isolation. For sessions where the user asks "what can repo A teach repo B?" (cross-repo pattern extraction), use this additional methodology.

### When to Use

- User shares a repo URL and asks "对这项目有什么益" / "评估下对X的有益内容"
- User asks to evaluate multiple repos and extract reusable patterns
- User provides an external reference implementation and asks to port its patterns

### Procedure: Cross-Repo Pattern Extraction

1. **Understand Target Context**
   - Before reading the source repo, understand the target project(s) well enough to know what's missing. Read their key code files.
   - Make a table of target capabilities vs. gaps. The gaps are your search criteria.

2. **Read Source Repo Code**
   - Don't stop at README — read the actual implementation files
   - Focus on design patterns, not features. A WeChat bot's feature set is irrelevant to a RAG system, but its **design patterns** (multi-source retrieval abstraction, query variant generation, post-retrieval quality gates) are universally useful.
   - Extract each pattern as: (1) what problem it solves, (2) how the source implements it, (3) code snippet of the core logic

3. **Evaluate Fit Per Target**
   - For each target project, run each pattern through: would it work here? What would need to change? How many lines of code?
   - Grade as P0/P1/P2 based on gap severity, not pattern cleverness
   - Document what to AVOID — source-specific logic that's not portable

4. **Output Format**
   - One row per pattern: | 方向 | 优先级 | 做法 | 价值 |
   - "避免做的事" section per target
   - Common/cross-cutting patterns table at the bottom
   - Action roadmap with time estimates
   - Write to a file under the target project's docs directory

### Pitfalls

- **Don't copy features, copy patterns.** The value of a WeChat bot to a RAG system is not "it can send messages" but "it has a clean multi-source retrieval abstraction"
- **The source repo's problem space is a distraction.** Filter everything through: "does this solve a known gap in the target?"
- **Don't evaluate on reputation.** DeepWiki's README says "architecture diagrams" — but what matters is the MCP protocol design (free, no-auth, 3 tools) as a pattern for external knowledge source integration
- **Include a cross-cutting summary.** Patterns that benefit ALL target projects are the highest value signal

## Pitfalls
- **Don't stop tracing at data stores — trace all the way to user-perceptible output.** It's easy to verify data reaches GitHub/Graph/S3 and call it done. But if the user never gets notified, the data might as well not exist (worse — it creates the illusion of a working system). For every producer path, ask: "how does the human know this happened?" If the answer is "they don't", that's a P1 defect, not a nice-to-have. See `references/notification-gap-case-study.md` for a real example.
- Don't just list issues — explain WHY they matter architecturally
- Distinguish "stub that will be implemented" from "broken logic pretending to work"
- **Tool output redaction — verify before diagnosing errors.** Tools like `read_file`, `cat`, `sed`, `grep`, and `cat -A` may redact/censor values they classify as secrets (tokens, IPs, numeric configs, environment variable values) by replacing them with `***`. This can make syntactically valid code look broken (e.g., `DEFAULT_AUTHORITY=***` where the actual value is `0.5`). Before reporting a "syntax error" or missing value, verify with Python's `py_compile.compile(path, doraise=True)` or a direct `import` of the module. If the file compiles/imports fine, the `***` is tool-side redaction, not a code defect.
- Look for `TODO`/`FIXME`/`For now` comments that reveal known gaps
- If the repo is private, ask user to make it public or provide local path
- After fixing secrets in config.yaml, OLD COMMITS still expose them — warn user to rotate credentials or purge history
