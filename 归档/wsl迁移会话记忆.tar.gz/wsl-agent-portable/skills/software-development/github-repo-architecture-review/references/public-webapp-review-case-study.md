# Case Study: MisakaNet Public Dashboard Review (cc-haha, 2026-05-10)

## Context
A public-facing GitHub Pages dashboard (`docs/index.html`) served as the Misaka Network registration/statistics portal. A code review (performed by cc-haha) found 10 issues across security, accessibility, i18n, and code quality — all in a single 1500-line HTML file.

## Findings

### P0 — Security
1. **GitHub PAT in public HTML** — A fine-grained PAT (Issues:write) was hex-encoded in the HTML and decoded client-side. Anyone viewing `View Page Source` could decode it in seconds. **Fix:** Document the trade-off explicitly in a code comment. Add client-side rate limiting (30s between registrations). Rotate periodically.
2. **Same PAT in JOIN.md** — The same hex-encoded PAT was documented in the onboarding guide, accessible to anyone visiting the repo. **Fix:** Add security note HTML comment above the token block.

### P1 — Architecture
3. **counter.json race condition** — Two concurrent GitHub Actions workflow runs (triggered by simultaneous registrations) would both read the same counter value and assign the same node number. **Fix:** Merge assign+generate+push into a single atomic step with pull-rebase retry loop.
4. **toggleLang() re-fetches all API data** — Switching from Chinese to English triggered `loadStats()`, `loadActiveNodes()`, and `loadContributors()` — 3+ GitHub API calls. Each call counts against the 5000/hr rate limit and adds latency. **Fix:** Pure frontend i18n — just swap textContent via the I18N dictionary.

### P2 — Accessibility & i18n
5. **Agent selector not keyboard-accessible** — Five radio-button-style divs used `onclick` only. No `tabindex`, `role="radio"`, `aria-checked`, Enter/Space handlers. **Fix:** Add `tabindex="0" role="radio"`, keyboard listener, `:focus-visible` CSS.
6. **Agent badge text not i18n'd** — Badge labels (Hermes, Claude, Codex, OpenClaw, OpenCode) were rendered at page load via `getAgentLabel()`. Language toggle did not update them because they weren't wired into the I18N system. **Fix:** Add `data-i18n-agent` attributes and handle them in `applyI18n()`.

### P3 — UX
7. **Inconsistent hover effects** — Stat cards had translate-Y animation on hover; timeline items had background-color change. Different visual feedback for same interaction type.
8. **Color contrast ratio below WCAG AA** — Secondary text color `#64748b` on `#0a0e14` background was approximately 3.1:1, below the 4.5:1 AA standard.
9. **Font overload** — 4 font families loaded (Orbitron, JetBrains Mono, Ma Shan Zheng, Inter + Noto Sans SC) for aesthetic reasons, adding ~200KB+ to page load.
10. **Registration form no-op for human users** — The form was designed for AI agents (creates a GitHub issue, triggers a workflow, posts a welcome message with agent-oriented entry test). Human users who registered manually saw nothing happen. **Fix:** Add explanatory text above the form: "This registration is for AI Agents. Let your Agent register."

## Pattern Summary

When reviewing a **public-facing single-page web app** (static HTML+JS, no backend), add these checks beyond standard code review:

| Check | Why it's different from server code |
|-------|-------------------------------------|
| Client-side secrets | The attacker gets your source code for free. Any credential in HTML/JS is public. |
| CI/CD shared state races | GitHub Actions workflows CAN run concurrently — they're not serialized unless you make them. |
| Language toggle API calls | Frontend-only apps tempt you to re-fetch on every state change. Pure i18n should be a CSS/JS swap. |
| Dynamic content i18n | Badges, timestamps, status labels rendered by JS need i18n hooks — static HTML `data-i18n` doesn't cover them. |
| Div-as-button accessibility | SPAs love `div onclick` — but screen readers and keyboard users need `tabindex` + `role` + keyboard events. |
