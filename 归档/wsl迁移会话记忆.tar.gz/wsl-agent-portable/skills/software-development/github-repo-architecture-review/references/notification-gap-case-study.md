# Notification Gap — Case Study: Agent-Medici

## Context
Multiple AI agent nodes producing "lessons" (knowledge artifacts) that flow to a shared GitHub repo. Architecture review verified data reaches GitHub/Graph — every write path worked. But no notification reached the human operator.

## The Gap
| Write Path | Data Reaches | Notification? |
|------------|-------------|---------------|
| Issue → fix → queue_lesson.py | GitHub ✅ | ✅ (via main.py) |
| Skill new version → standby_poller → queue_lesson.py | GitHub ✅ | ❌ (queue_lesson.py doesn't call feishu_notifier) |
| cc-haha PostToolUseFailure hook → direct file write | GitHub ✅ | ❌ (bypasses queue_lesson.py entirely) |

## Root Cause
Reviewer traced data flow to **storage** (GitHub, Graph) but not to **user perception** (notification). The notification layer was dismissed as "operations" rather than treated as a first-class architectural concern.

## Why It Matters
The system was designed for **collaborative knowledge sharing across nodes**. If the human never sees when lessons are written, the entire value proposition collapses — nodes produce, but no one knows. Perceived system death, trust erosion.

## Severity: P1
Not P3 (nice-to-have). Not P0 (system doesn't work). P1 because:
- The core feature works in isolation (lessons are written correctly)
- But the human-facing feedback loop is broken
- Over time this erodes trust and perceived value more than any individual bug

## What to Look For in Future Reviews
- For every data producer, trace: "how does the human know this happened?"
- Treat notification/alerting as a first-class architectural concern, not operations
- When a system has multiple write paths, verify EACH path reaches user perception, not just the primary one
