---
name: wxauto-bot-development
description: wxauto 微信机器人开发规范和踩坑记录 — wxauto API 行为、调试流程、常见陷阱
triggers:
  - wxauto
  - 微信机器人
  - wxauto_bot
  - WeChat bot
  - wechat-automation-local
  - DB 解密
  - 微信数据库
  - 微信本地库
  - 前台发送
  - wechat_sender
  - wechat_reader
  - wechat_decrypt
  - 前景发送
  - reply_engine
  - wechat_bot_monitor
---

# wxauto 微信机器人开发规范

## 三种 Bot 架构

目前有三种微信机器人架构，按消息获取方式分类：

| 特性 | wxauto UIA 注入 (wxauto_bot.py / bot.py) | wcferry DLL 注入 | DB 解密 + 前台发送 (wechat-automation-local) |
|------|-------------------------------------------|------------------|-----------------------------------------------|
| 消息获取 | wxauto `GetAllNewMessage()` / `GetListenMessage()` | wcferry TCP :10086 回调 | 解密微信本地 SQLite DB，轮询 `Msg_xxx` 表 |
| 消息发送 | `wx.SendMsg()` (UIA 控件) | wcferry `send_text()` | 前台 UIA / OCR / 剪贴板粘贴 (`SendKeys`) |
| 窗口要求 | 微信窗口在前台可见 | 无（DLL 注入不依赖窗口） | 微信窗口在前台可见 |
| 微信版本 | 不限 | **必须精确匹配** wcferry 版本 | 不限（读取本地文件，不依赖注入） |
| 知识库集成 | 通过 RAG API HTTP | 通过 RAG API HTTP | 本地 wiki + IMA/GetNote/Hook 多提供者 |
| 查询架构 | RAG API → ChromaDB → LLM 生成 | RAG API → ChromaDB → LLM 生成 | reply_engine.py 分层检索（core + scene KBs） |
| 权限 | 正常用户 | 需要管理员提权关闭 Windows Defender | 正常用户（读本地文件） |
| 可靠性 | `GetAllNewMessage` 窗口失焦后 COM 崩溃 | 受微信版本封锁影响 | 高（解码后有结构化的 DB SQLite） |
| 隐私 | 借助注入获取消息 | DLL 注入到微信进程 | 读取本地已有文件（解密可直接在 WSL 上做） |
| **推荐场景** | 快速原型，简单测试 | 需要稳定消息回调时 | 长期运行，多知识库，强边界安全 |

**结论**：
- **日常测试** → bot.py（wxauto，简单可靠）
- **需要高级功能** → wxauto_bot.py（DeepSeek 意图识别/自重启）
- **长期生产 + 多知识库 + 强安全边界** → DB 解密架构 (wechat-automation-local)

### wxauto 注入架构（本项目默认）

项目有两个 wxauto bot 脚本，用途不同：

| 特性 | wxauto_bot.py (702行) | wxauto_bot/bot.py (352行) |
|------|----------------------|---------------------------|
| 消息获取 | `GetAllNewMessage()` 轮询所有可见聊天 | `GetListenMessage()` 只接收 AddListenChat 的聊天 |
| 窗口保护 | 无 | `activate_window()` ctypes 激活窗口后发送 |
| 稳定性 | 窗口失焦后 COM 崩溃（事件无法调用任何订户） | 更稳定，发消息前主动激活窗口 |
| 群配置 | `MONITOR_GROUPS` 列表 | `GROUPS` 列表 |
| 高级用户 | 支持 DeepSeek 意图识别/改代码/自重启 | 聪明模式（RAG+DeepSeek推理）+ token统计 |
| 本地关键词 | ✓ 自我介绍/目录/反馈 | ✓ 自我介绍/目录/状态/帮助/smart_stats |
| **推荐场景** | 需要高级用户通道 + 复杂功能时 | **日常测试首选**，简单可靠 |

### DB 解密架构（wechat-automation-local 模式）

适用于长期运行、多知识库、强安全边界的生产环境。原理：解密微信本地 SQLite 数据库，直接读表 `Msg_xxx` 获取消息，不依赖任何注入或 API hook。

**查询链路（从消息到回复）：**

```
微信新消息（写入本地 DB）
  → wechat_bot_monitor.py 轮询 `message_N.db`（轮询间隔 ~3s）
    → 对比 `last_local_id` 发现新行
      → generate_reply(raw_message, target, config)
        → 1. strip_triggers()  — 去掉触发词/@提及，提取纯查询
        → 2. precheck()       — 高风险词/承诺词拦截（不让 LLM 看到）
        → 3. retrieve_knowledge_layers() — 分层知识检索
             ├── core/ 层：全局第一原则（边界规则），始终命中
             └── scene/ 层：目标绑定的知识库（0~N 个）
                  ├── local：本地 Markdown 文件分词匹配
                  ├── ima：腾讯 IMA OpenAPI 线上搜索
                  ├── getnote：外部 CLI 笔记检索
                  └── hook：通用适配器（env var 协议）
        → 4. _strong_scene_hits() — 语义无关过滤（防闲聊误触知识库）
        → 5. build_prompt() + call_llm_provider() — 构建上下文 + 调 LLM
             └── 支持 command provider（外部 agent CLI stdin/stdout 协议）
        → 6. postcheck() — 回复后过滤敏感内容 + 字数裁剪
  → UIA / foreground / OCR 发送回复
```

**多层知识库配置**（per-target）：

```json
{
  "targets": [{
    "name": "群组名称",
    "triggers": ["@机器人"],
    "knowledge_bases": [
      {"id": "product-docs", "type": "local", "path": "./docs/product", "scope": "scene"},
      {"id": "company-wiki", "type": "ima", "kb_id": "xxx", "scope": "online"}
    ]
  }],
  "knowledge_bases": {
    "product-docs": {"type": "local", "path": "./docs/product", "scope": "scene"},
    "company-wiki": {"type": "ima", "kb_id": "xxx", "scope": "online",
      "client_id_env": "IMA_CLIENT_ID", "api_key_env": "IMA_API_KEY"}
  }
}
```

**本地检索算法**（`_score_doc`，纯 Python 无依赖）：
- 拆词：按标点分割 + 2/3 字中文 ngram
- 文件名权重 x3，正文按词频计分
- 停用词过滤：什么、怎么、可以、一下、这个、那个
- 额外加分词：小助手、小助理、帮助、功能、边界

**查询变体生成**（`_ima_query_variants`，对 IMA/Hook 提供者有用）：
对一条群消息自动生成最多 8 种查询变体，包括去 @ 提及、去聊天前缀、去命令前缀（"帮我找找"），并提取紧凑短语（如"工作号"、"真实号"），提高线上 KB 命中率。

**安全边界闸门**：
| 层 | 作用 | 实现 |
|----|------|------|
| precheck | 高风险/承诺词直接拦截，不给 LLM 看到 | 正则匹配 + 固定回复 |
| _strong_scene_hits | 外部 KB 返回结果质量过滤 | 用本地 `_score_doc` 重新打分，防"哈哈"/"在吗"误触 |
| _looks_like_smalltalk | 短文本/纯闲聊跳过线上检索 | 长度 < 18 字且无业务关键词 |
| postcheck | 回复中过滤敏感内容 | 密钥、路径、数据库名称等黑名单 |
| fallback_reply | 所有路径都失败时的兜底 | 三种模式：smalltalk / wiki_qa / need_human |

**命令行测试**：
```bash
# 测试知识库检索结果（不影响微信）
python wiki_dry_run.py --target "群组名称" --query "xxx" [--llm]
# 只输出检索命中文档，不调 LLM
python wiki_dry_run.py --target "群组名称" --query "xxx"
```

## 项目路径
- wxauto_bot.py 源码: `/home/hp/self-grow-wiki/wxauto_bot.py` (主 bot)
- bot.py 源码: `/home/hp/self-grow-wiki/wxauto_bot/bot.py` (轻量 bot)
- Windows 部署: `C:\Users\hp\Desktop\自研\RAG助手测试记录\`
- 日志: 同目录 `wxauto_bot.log`
- 测试问题记录: 同目录 `test_issues.md`

## 部署陷阱

### 1. wxauto 必须在 Windows Python 下安装
wxauto 是 Windows-only 库（控制 Windows 微信桌面客户端 UI），**不能在 WSL 中安装**。

```pwsh
# Windows PowerShell / CMD（正确）
pip install wxauto requests

# ❌ WSL 中执行会失败或装错位置
```

如果 pypi 版本找不到：
```pwsh
pip install git+https://github.com/cluic/wxauto.git requests
```

### 2. wcferry 版本必须精确匹配微信版本
wcferry 通过 DLL 注入 hook 微信内存地址，**版本必须精确匹配**。

| wcferry 版本 | 微信版本 | 状态 |
|-------------|---------|------|
| 39.5.x (latest pip) | 3.9.12.51 | ✅ 可工作 |
| 39.5.x | 3.9.12.56+ | ❌ 不兼容 |
| 39.5.x | 3.9.12.51 但被腾讯封锁 | ❌ 无法登录 |

```pwsh
# 降级微信到 3.9.12.51
# 1. 卸载当前微信
# 2. 下载 3.9.12.51 安装包（从 GitHub wcferry releases 页找链接）
# 3. 关闭自动更新：设置 → 通用设置 → 取消勾选
```

**替代方案**: 如果微信版本被封锁或无法降级，直接切到 wxauto（UI 自动化方式，不限微信版本）。

### 3. 防火墙端口 10086 ≠ 内网穿透
wcferry 需要在 Windows 上开端口 10086 让 WSL2 连接。这**不是**内网穿透：

```pwsh
# 管理员 PowerShell
netsh advfirewall firewall add rule name="wcferry" dir=in action=allow protocol=TCP localport=10086
```

流量路径：`WSL2 (Linux) → 本机虚拟网卡 → Windows :10086`，全程本地，不暴露到外网。

### 4. 企业微信改用长连接后不需要 ngrok
如果企业微信配置了**长连接**模式，bot 主动连出到 WeCom 服务端，不需要 ngrok/frp 等公网隧道。架构简化为：
```
wecom_bot.py 主动连出 → WeCom 长连接服务 → 收到消息 → RAG → message/send 推送回复
```
不需要 HTTPS 证书、公网 IP、回调 URL 验证流程。防火墙友好（只有出站连接）。
```bash
# WSL: 改完代码后
cp /home/hp/self-grow-wiki/wxauto_bot.py /mnt/c/Users/hp/Desktop/自研/RAG助手测试记录/wxauto_bot.py
cp /home/hp/self-grow-wiki/wxauto_bot/bot.py /mnt/c/Users/hp/Desktop/自研/RAG助手测试记录/bot.py

# Windows PowerShell: 启动（二选一）
python "C:\\Users\\hp\\Desktop\\自研\\RAG助手测试记录\\bot.py"          # 推荐：轻量稳定
python "C:\\Users\\hp\\Desktop\\自研\\RAG助手测试记录\\wxauto_bot.py"   # 需要高级功能时用

# 从 WSL 启动（需要 cmd.exe 桥接，不能直接 python）
cmd.exe /c "cd /d C:\Users\hp\Desktop\自研\RAG助手测试记录 && python bot.py"
```

**注意**: bot.py 是 Windows-only 脚本（用了 wxauto + ctypes.windll.user32），必须用 Windows Python 运行，
不能在 WSL 中直接 `python bot.py`。WSL 中用 `cmd.exe /c` 桥接到 Windows 环境。

## wxauto API 踩坑（重要）

### 1. @消息格式
- wxauto 收到的群聊 @消息格式是 `内容@机器人名`（@在末尾），不是 `@机器人名 内容`
- 提取内容时取 `content.split(f"@{BOT_NAME}", 1)[0].strip()`（@前面的部分）
- 消息末尾可能有 `\u2005`（四分之一空格），需要 strip

### 2. 窗口名带未读数
- 群聊窗口名会动态变成 `群名 (7)` 带未读数
- `wx.SendMsg(msg, who=群名)` 找不到控件会抛 `LookupError: Find Control Timeout`
- **必须用 `_normalize_chat_name()` 去掉末尾 `\(\d+\)` 再发消息**

### 3. wxauto 初始化和 AddListenChat 都需要微信窗口在前台
- `WeChat()` 构造函数本身就需要微信窗口可见，否则报 `SetWindowPos` 错误：
  ```
  pywintypes.error: (1400, 'SetWindowPos', '无效的窗口句柄。')
  ```
- `AddListenChat()` 同样需要微信窗口在前台且聊天列表可见，否则报 `BoundingRectangle is (0,0,0,0)`
- **解决方法**: 启动前先打开微信窗口到前台，不要最小化
- AddListenChat 失败不阻塞启动，`GetAllNewMessage()` 兜底
- 首次使用需手动点开一次目标聊天窗口

### 4. Windows 编码
- Windows 默认 GBK，读含中文的 .py 文件必须 `open(..., encoding="utf-8")`
- 否则报 `'gbk' codec can't decode byte`

### 6. bot.py 必须本地处理关键词（不要全走 RAG）

bot.py 架构简单，消息处理只有一条路径 → `rag_query()`。**但自我介绍、帮助、状态等本地命令必须先拦截，不能发给 RAG API**，否则会返回不相关的知识库内容。

```python
# 在 log(f"处理: {question}") 之后、rag_query() 之前插入：
answer = None
_kw = question.replace(" ", "").replace("\u2005", "")

# 1. 自我介绍（模糊匹配）
_intro_kw = {"你是谁", "自我介绍", "介绍下自己", "你是啥", "你是什么", ...}
if any(k in _kw for k in _intro_kw):
    answer = SELF_INTRO_TEXT

# 2. 帮助/状态（精确匹配）
if question in ("/帮助", "帮助", "/状态", "状态"):
    answer = HELP_TEXT

# 3. 知识库目录（模糊匹配）
_cat_kw = {"知识库目录", "知识分类", "目录", ...}
if any(k in _kw for k in _cat_kw):
    answer = catalog_query()

# 4. 都没命中 → RAG
if answer is None:
    answer = rag_query(question)
```

注意 `answer = None` 作为哨兵，避免无谓的 RAG 调用。关键词集合从 wxauto_bot.py 复制保持同步。

## 聪明模式（bot.py 高级用户功能）

`bot.py` 内置聪明模式，仅对 ADMIN_PRIVATE 用户开放。触发词：`使出全力` / `整个活` / `机灵点`。

**原理（与纯 DeepSeek 直答的区别）：**
```
错误做法: 问题 → DeepSeek（绕过知识库，引入外部知识）
正确做法: 问题 → RAG检索wiki文档 → DeepSeek基于文档推理生成
           ↑100% wiki知识        ↑只做推理，不补充外部知识
```

**实现**：
- `deepseek_with_rag(question, history)` — 先调 RAG API 获取 wiki 答案 + 来源，再将 wiki 内容作为 system prompt context 发给 DeepSeek
- `rag_query(question)` 返回 `(answer, sources)` 元组
- `rag_answer(question)` 只返回 answer 文本（标准模式用）
- Token 统计：`_smart_tokens` / `_normal_tokens` 字典，每次查询累加 prompt/completion tokens
- 查看统计：发送 `/smart_stats` 命令

**配置**：
```python
_SMART_TRIGGERS = {"使出全力", "整个活", "机灵点"}
_SMART_USER = "海关约我去喝茶"
_smart_remaining = 0  # 每轮 10 次，用完后自动回落标准模式
DEEPSEEK_KEY = os.environ.get("DEEPSEEK_API_KEY", "sk-...")
```

**注意事项**：
- 聪明模式仍在知识库框架内：RAG 检索 → DeepSeek 推理，不绕开 wiki
- RAG API 返回的 sources 是文件名列表（字符串），不是 dict，需要用 `rag_answer()` 返回的文本作为 wiki context
- 聪明模式结束后自动提示 `🔋 聪明模式已耗尽，恢复标准 RAG 模式`
- DeepSeek key 硬编码在 bot.py 中作为 fallback，优先读取环境变量 `DEEPSEEK_API_KEY`

## 开发规范

### 改代码前
1. 先读懂相关代码段，理解 wxauto API 行为
2. 功能拆分，一次只改一个点
3. 改完先静态分析（见下方检查清单），再复制到 Windows

### 静态分析检查清单（每次改完必做）
```bash
cd /home/hp && python3 -c "
import ast, re
with open('wxauto_bot.py', 'r', encoding='utf-8') as f:
    code = f.read()
tree = ast.parse(code)  # 语法检查
# 检查: import 完整、_send_safe 无递归、RAG_API 硬编码、日志绝对路径、
#       open() 有 encoding、_normalize_chat_name 使用、AddListenChat 存在
"
```

### GitHub 推送
```bash
cd /home/hp/self-grow-wiki
cp /home/hp/wxauto_bot.py . && cp /home/hp/rag_api.py .
git add wxauto_bot.py rag_api.py wxauto_bot/bot.py
git commit -m "描述"
git push
```

### 发消息
- 统一用 `_send_safe(wx, msg, who)`，不要直接用 `wx.SendMsg`
- `_send_safe` 内部处理窗口名规范化 + 异常重试
- **注意：`_send_safe` 的 except 块不能调自身，会无限递归**

### 反馈匹配
- `_last_queries` 的 key 必须用 `_normalize_chat_name(chat_name)` 存储
- 查询时也要 normalized 后再查

### 高级用户通道
- `ADMIN_USERS` 中的私聊消息全部走 DeepSeek 意图识别
- action: query → RAG, modify_config → 改代码, restart → 重启, chat → 直接回复
- 代码修改后自动 `_restart_bot()`

### 日志
- logging 配置写绝对路径到 `C:\\Users\\hp\\Desktop\\自研\\RAG助手测试记录\\wxauto_bot.log`
- 测试问题记录到同目录 `test_issues.md`

## 调试循环标准化流程

当用户反馈 Windows 端运行出问题时，按此流程排查（避免反复猜测）：

### Step 1: 看日志
```bash
# 从 WSL 读取 Windows 日志
tail -30 /mnt/c/Users/hp/Desktop/自研/RAG助手测试记录/wxauto_bot.log
```
关注：
- `[ERROR]` 行：异常类型和 traceback
- `[WARNING]` 行：`发消息失败` 说明是 SendMsg 问题
- `[INFO] 收到消息` 行：有日志说明 wxauto 收到了，没日志说明没收到

### Step 2: 根据错误模式定位根因

| 错误模式 | 根因 | 修复 |
|----------|------|------|
| `Find Control Timeout` + 窗口名带 `(n)` | 窗口名未读数没有去掉 | 检查 `_normalize_chat_name` 是否在调用路径上 |
| `maximum recursion depth exceeded` | `_send_safe` 调自身 | 重写 except 块直接调 `wx.SendMsg` |
| `'gbk' codec can't decode byte` | Windows 打开 py 文件缺 encoding | 加 `encoding='utf-8'` |
| `name 'os' is not defined` | WSL 端有 os 但 Windows 没 | 在文件顶部加 `import os` |
| `can not move cursor, BoundingRectangle is (0,0,0,0)` | AddListenChat 时微信窗口不可见 | 先点开微信窗口再启动，或忽略此 warning |
| `事件无法调用任何订户`（连续每5秒报一次） | 微信窗口失焦后 COM 彻底崩溃 | **切到 bot.py**（用 GetListenMessage + activate_window），不要继续用 GetAllNewMessage |
| `事件无法调用任何订户`（偶发） | wxauto 控件状态异常 | 一般是窗口最小化/锁屏导致，重启或解锁 |
| `'gbk' codec can't encode character '\u2005'` | log() 中 print() 到 Windows cmd 时报 GBK 编码错误 | log 函数的 print() 加 try/except UnicodeEncodeError（见下方） |
| `(1400, 'SetWindowPos', '无效的窗口句柄')` | WeChat() 构造时微信窗口不在前台 | 先打开微信窗口到前台（不要最小化），再启动 bot |
| 私聊消息收不到（日志无记录） | GetAllNewMessage 只能读可见聊天 | 加 `AddListenChat` 或手动点开聊天窗口 |
| 群聊@消息走了 RAG 没走快捷回复 | `content` 在 @拆分后带隐藏字符 | 用 `any(kw in content for kw in _INTRO_KEYWORDS)` 模糊匹配 |
| 反馈"没用"走了查询 | `_last_queries` 的 key 和当前 chat_name 不一致 | 统一用 `_normalize_chat_name()` |

### Windows cmd GBK 编码崩溃（log 函数）
微信消息含 Unicode 空格 `\u2005` 等字符时，Windows cmd 的 `print()` 用 GBK 编码输出会崩溃，导致整个主循环异常退出。修复 log 函数：

```python
def log(msg):
    ts = datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    try:
        print(line, flush=True)
    except UnicodeEncodeError:
        print(line.encode('utf-8', errors='replace').decode('utf-8'), flush=True)
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(line + "\n")
```

### Step 3: 修复后
1. WSL 改代码
2. 运行静态分析检查清单
3. 复制到 Windows
4. 用户重启测试
5. 如果还有问题，贴日志回到 Step 1

**核心原则：一次只改一个点，改完问用户要日志，不要连续改多个点再一次性测试。**
