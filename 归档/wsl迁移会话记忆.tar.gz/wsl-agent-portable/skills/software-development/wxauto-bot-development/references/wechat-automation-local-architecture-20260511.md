# wechat-automation-local 架构分析 (2026-05-11)

仓库: https://github.com/lewis-liu-web/wechat-automation-local

## 架构概览

DB 解密 + UIA/前景发送 架构。不走注入/不走 API hook，直接读微信本地 SQLite 数据库。

## 目录结构

```
wechat-decrypt/            # 运行时目录（README 中的 <runtime-dir/>）
├── manage_targets.py      # CLI 工具：目标管理、提钥、解密、启动/停止
├── wechat_bot_monitor.py  # 主循环：轮询 DB → 发现新消息 → generate_reply → 发送
├── reply_engine.py        # 核心：检索 + LLM + 边界检查 (51244 行! 全在一个文件)
├── wiki_dry_run.py        # 知识库检索测试工具（不发送消息）
├── wechat_sender.py       # 消息发送（前景 UIA / OCR / 剪贴板）
├── wechat_reader.py       # 从解密 DB 读取消息/联系人
├── target_registry.py     # 目标注册表管理
├── fast_refresh_targets.py# 轻量刷新目标元数据
├── genericagent_command_bridge.py  # LLM 外部 agent 桥接
├── mcp_server.py          # MCP 服务器
├── monitor.py / monitor_web.py     # 监控面板
├── wiki/                  # 本地知识库 Markdown
│   ├── core/              # 全局第一原则（边界规则，始终命中）
│   └── scenes/            # 场景知识库（per-target 绑定）
├── config.py              # 微信 DB 自动发现
└── tests/                 # 测试
```

## 查询强度过滤 (reply_engine.py)

消息收到后，**LLM 调用前**做了多层安全过滤：

1. **precheck**: 高风险词（转账/密码/数据库/删除）+ 承诺词（你替群主/保证/授权）→ 直接拦截，固定回复
2. **_looks_like_smalltalk**: 短文本 (<18 字) 且不包含业务关键词 → 跳过线上检索
3. **_strong_scene_hits**: IMA/Hook 返回的结果用本地分词重新打分 → 防闲聊误触
4. **postcheck**: LLM 回复后的敏感内容过滤（密钥/路径/内部信息）

## 检索提供者

| type | 协议 | 依赖 | 安全 |
|------|------|------|------|
| local | 本地 Markdown 分词 `_score_doc` | 无 | ✅ 完全本地 |
| ima | IMA OpenAPI POST | IMA_CLIENT_ID + IMA_API_KEY env | ⚠️ 外部 API |
| getnote | CLI exec `getnote search` | getnote 二进制 | ⚠️ 外部 CLI |
| hook | env var KB_QUERY/KB_ID/KB_LIMIT → stdout JSON | 用户脚本 | ⚠️ 用户自定义 |

## 关键调用链

```
wechat_bot_monitor.py:
  fetch_new_for_db() → 轮询 DB，对比 last_local_id
  → generate_reply(msg, target, config)  ← reply_engine.py
    → strip_triggers() → precheck() → retrieve_knowledge_layers()
    → build_prompt() → call_llm_provider() → postcheck()
  → send_reply_detailed()  ← wechat_sender.py
```

## 与 wxauto 架构的关键差异

| | wxauto 架构 | DB 解密架构 |
|--|------------|------------|
| 消息读取 | COM UIA 控件 | SQLite 表 |
| 消息延迟 | 实时 | 3s 轮询（可配） |
| 消息历史 | 只有当前会话 | 全部历史可查 |
| Windows 依赖 | wxauto (UIA) | pywin32 + sqlcipher3 |
| LLM 配置 | RAG API 硬编码 | 可插拔 provider |
| 安全边界 | 无（由 LLM 自身控制） | 三层过滤（precheck + strong_hits + postcheck） |

## 新增知识库提供者流程

1. 在 `manage_targets.py` 注册：`python manage_targets.py kb-add <name> <type>`
2. 在 `wechat_bot_targets.json` 的 `knowledge_bases` 下配置提供者参数
3. 在目标上绑定：`python manage_targets.py kb "群组名称" <kb-id>`
4. 测试：`python wiki_dry_run.py --target "群组名称" --query "xxx"`
