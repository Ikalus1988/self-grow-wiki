# Feishu Interactive Card Feedback Channel

## When to Use

When RAG users access via Feishu group (through Hermes gateway), Gradio UI buttons and WeChat keyword detection don't apply. Use Feishu interactive cards with 👍👎 buttons instead.

## Architecture

```
User in Feishu group → @bot query → Hermes → RAG answer
                                          ↓
                              rag_feedback_card.py sends card
                              (interactive, with 👍👎 buttons)
                                          ↓
                              User clicks button
                                          ↓
                              Feishu SDK callback
                                          ↓
                              Hermes gateway _on_card_action_trigger()
                              (checks hermes_rag_feedback in action_value)
                                          ↓
                              urllib → POST http://localhost:8002/feedback
                                          ↓
                              Returns resolved card ("✅ 感谢反馈")
                                          ↓
                              SQLite feedback table (same as Web/WeChat)
```

## Files

| File | Purpose |
|------|---------|
| `rag_feedback_card.py` | Standalone script: build + send feedback card via Feishu API |
| `feishu.py` (Hermes) | `_handle_rag_feedback_card_action()` — intercepts button callback |
| `rag_api.py` | `POST /feedback` — writes to SQLite (shared with Web/WeChat) |

## Card JSON Template

```json
{
  "config": {"wide_screen_mode": true},
  "header": {"title": {"content": "📚 RAG 知识库回答", "tag": "plain_text"}, "template": "blue"},
  "elements": [
    {"tag": "markdown", "content": "**问题:** {query}"},
    {"tag": "hr"},
    {"tag": "action", "actions": [
      {"tag": "button", "text": {"tag": "plain_text", "content": "👍 有用"},
       "type": "primary",
       "value": {"hermes_rag_feedback": "good", "query_id": 151, "query": "truncated query"}},
      {"tag": "button", "text": {"tag": "plain_text", "content": "👎 没用"},
       "type": "danger",
       "value": {"hermes_rag_feedback": "bad", "query_id": 151, "query": "truncated query"}}
    ]},
    {"tag": "note", "elements": [{"tag": "plain_text", "content": "反馈将帮助改进知识库质量"}]}
  ]
}
```

## Integration Points

### After RAG Query (rag_api.py or rag_web.py)

After generating an answer, call the card sender:
```python
import subprocess
subprocess.Popen([
    "python3", "/home/hp/rag_feedback_card.py",
    "--query-id", str(query_id),
    "--query", query[:200],
    "--answer", answer[:500],
    "--chat-id", "oc_1bf03d465a785da56ae541a1ce5e77fa",
])
```

Use `Popen` (non-blocking) so the RAG response isn't delayed by card sending.

### Gateway Restart

After modifying `feishu.py`, restart Hermes gateway:
```bash
hermes gateway restart
```

## Pitfalls

- **Card + text duplication**: If Hermes also sends a text reply, the user sees both the text answer AND the card. Consider suppressing the text reply when the card is sent, or send the card as a reply to the text answer (`--reply-to` flag).
- **query_id must be real**: Feedback with `query_id=0` is rejected by the API (`"query_id is required"`). Always pass a real query_id from the query_log.
- **Credentials**: `rag_feedback_card.py` reads `FEISHU_APP_ID` and `FEISHU_APP_SECRET` from `~/.hermes/.env`.
