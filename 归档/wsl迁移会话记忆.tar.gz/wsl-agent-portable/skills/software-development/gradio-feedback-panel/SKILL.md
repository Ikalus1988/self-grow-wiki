---
name: gradio-feedback-panel
description: Add a user feedback management panel (satisfaction stats, bad query list, unified data source) to a Gradio-based RAG Web UI. Covers SQLite feedback schema, query functions, UI Tab, and unifying feedback from multiple entry points (Web + WeChat).
tags: [gradio, feedback, rag, admin-panel, sqlite, web-ui]
triggers:
  - "add feedback system to Gradio UI"
  - "user feedback panel for RAG web app"
  - "unify feedback data sources"
  - "satisfaction tracking in Gradio"
  - "extend rag_web.py with admin features"
  - "feedback consolidation JSON SQLite"
---

# Gradio Feedback Panel for RAG Web UI

Add a complete user feedback management system to a Gradio-based RAG web application. Collects thumbs-up/down, tracks category errors, displays statistics, and lists problematic queries — all from a single SQLite database.

## Architecture

```
rag_core.py                  rag_web.py
 ┌─────────────────┐         ┌─────────────────────┐
 │ log_feedback()   │◄───────│ submit_feedback_up()│
 │ get_feedback_stats()─────►│ submit_feedback_down│
 │ get_feedback_list()       │ show_feedback_panel │
 └─────────────────┘         └─────────────────────┘
        │                          │
        ▼                          ▼
  SQLite (feedback table)    Gradio Tab "反馈管理"
```

## Procedure

### 1. Add SQLite feedback queries in the core module

In `rag_core.py` (or equivalent core RAG module), add two functions:

**`get_feedback_stats(days=7)`** — returns dict with:
- `total`, `good`, `bad`, `wrong_category`, `satisfaction_rate`
- `by_type`: list of {feedback_type, count}
- `by_day`: daily trend {day, good, bad, wrong_cat, total}
- `bad_list`: recent bad/wrong_category feedback with comments

**`get_feedback_list(limit, offset, min_date, max_date, filter_type)`** — paginated feedback list with optional filters.

SQL queries pattern:
```python
# By feedback_type aggregation
conn.execute("SELECT feedback_type, COUNT(*) c FROM feedback WHERE ts >= ? GROUP BY feedback_type", (cutoff,))

# Bad queries detail (for review panel)
conn.execute("""SELECT fb.id, fb.ts, fb.query, fb.feedback_type, fb.feedback_text, fb.category, fb.sender
   FROM feedback fb WHERE fb.ts >= ? AND fb.feedback_type IN ('bad','wrong_category')
   ORDER BY fb.id DESC LIMIT 50""", (cutoff,))

# Daily trend
conn.execute("""SELECT substr(ts,1,10) AS day,
    SUM(CASE WHEN feedback_type IN ('good','up') THEN 1 ELSE 0 END) good,
    SUM(CASE WHEN feedback_type IN ('bad','down') THEN 1 ELSE 0 END) bad, ...
   FROM feedback WHERE ts >= ? GROUP BY day ORDER BY day""", (cutoff,))
```

Make sure the feedback table exists (created in `_init_log_db()`):
```sql
CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%S', 'now', 'localtime')),
    query_id INTEGER REFERENCES query_log(id),
    query TEXT NOT NULL,
    feedback_type TEXT NOT NULL,   -- 'good'|'bad'|'wrong_category'|'other' (also 'up'/'down' for legacy)
    feedback_text TEXT,
    category TEXT,
    sender TEXT
);
```

### 2. Add feedback UI handlers in web UI module

In `rag_web.py`:

**`submit_feedback_up(query_id)`** — 👍 handler. Calls `log_feedback(int(query_id), "good", "", "")` from the core module (not kb_learning.json).

**`submit_feedback_down(query_id, comment)`** — 👎 handler. Calls `log_feedback(int(query_id), "bad", comment or "")`.

**`show_feedback_panel(days)`** — generates Markdown for the feedback tab:
- If no data: show instruction message
- If data: stats table (total, good, bad, wrong_category, satisfaction_rate) + bad queries detail list

### 3. Add the Gradio Tab

```python
with gr.Tab("📋 反馈管理"):
    gr.Markdown("## 用户反馈管理")
    with gr.Row():
        days_slider = gr.Slider(minimum=1, maximum=90, value=7, step=1, label="统计天数")
        refresh_btn = gr.Button("刷新反馈统计", variant="primary")
    with gr.Row():
        fb_stats = gr.Markdown("点击刷新", elem_classes=["source-box"])
        fb_bad_list = gr.Markdown("", elem_classes=["source-box"])
    refresh_btn.click(fn=show_feedback_panel, inputs=[days_slider], outputs=[fb_stats, fb_bad_list])
```

### 4. (Optional) Unify feedback data sources

If feedback is also recorded in a separate JSON file (e.g., `kb_learning.json`), switch Web UI handlers to use the core module's SQLite `log_feedback()` instead. This ensures all feedback (Web, WeChat, API) lands in one place.

### 5. Add feedback to WeChat/chat bot clients (wxauto or similar)

When the bot calls a remote HTTP API (e.g., `rag_api.py`), add a `/feedback` endpoint and client-side keyword detection.

**API side** (`rag_api.py`):
```python
class FeedbackRequest(BaseModel):
    query_id: str
    query: str = ""      # needed to populate feedback table
    rating: str           # "up" or "down"
    comment: str = ""

@app.post("/feedback")
def submit_feedback(req: FeedbackRequest):
    qid = int(req.query_id) if req.query_id else 0
    fb_type = "good" if req.rating in ("up", "good") else "bad"
    log_feedback(qid, req.query, fb_type, req.comment)
    return {"status": "ok"}
```

**Bot side** (`wxauto_bot.py`):
```python
# Track last query per chat for feedback association
last_queries = {}  # chat_name → (query_id, query)
_fb_good = {"有用", "对", "正确", "谢谢", "感谢", "可以", "没问题", "好"}
_fb_bad = {"没用", "不对", "不准确", "答错了", "答非所问", "不相关", "错了", "不好"}

# After each query, store query_id:
if result and result.get("query_id"):
    last_queries[chat_name] = (result["query_id"], query)

# In message loop, detect feedback BEFORE command dispatch:
if content in _fb_good and chat_name in last_queries:
    qid, q = last_queries[chat_name]
    call_feedback(qid, q, "up")
    wx.SendMsg("收到，感谢反馈！", who=chat_name)
    continue
if content in _fb_bad and chat_name in last_queries:
    qid, q = last_queries[chat_name]
    call_feedback(qid, q, "down", content)
    wx.SendMsg("收到，已记录反馈。可换关键词再试。", who=chat_name)
    continue
```

Key points:
- Feedback detection must come BEFORE command dispatch and auto-query in the message loop
- Store `last_queries` per `chat_name` (not per sender) since wxauto tracks chats
- Also store query_id from auto-detected queries (not just `/查` commands)
- Bot sends a short confirmation reply so user knows feedback was recorded

### 6. Feishu interactive card feedback (飞书交互卡片反馈)

When users access RAG via a Feishu group (through Hermes gateway), the Gradio UI and WeChat keyword detection don't apply. Instead, use Feishu interactive cards with 👍👎 buttons.

**Flow:**
1. After RAG answer, send an interactive card with feedback buttons to the Feishu group
2. Button click → Feishu SDK callback → Hermes gateway intercepts → calls `/feedback` API
3. Card auto-updates to show "✅ 感谢反馈"

**Card sender script** (`rag_feedback_card.py`):
```python
def build_feedback_card(query_id, query, answer_summary=""):
    return {
        "config": {"wide_screen_mode": True},
        "header": {"title": {"content": "📚 RAG 知识库回答", "tag": "plain_text"}, "template": "blue"},
        "elements": [
            {"tag": "markdown", "content": f"**问题:** {query}"},
            {"tag": "hr"},
            {"tag": "action", "actions": [
                {"tag": "button", "text": {"tag": "plain_text", "content": "👍 有用"},
                 "type": "primary",
                 "value": {"hermes_rag_feedback": "good", "query_id": query_id, "query": query[:100]}},
                {"tag": "button", "text": {"tag": "plain_text", "content": "👎 没用"},
                 "type": "danger",
                 "value": {"hermes_rag_feedback": "bad", "query_id": query_id, "query": query[:100]}},
            ]},
            {"tag": "note", "elements": [{"tag": "plain_text", "content": "反馈将帮助改进知识库质量"}]},
        ],
    }
```

**Hermes gateway interception** — Add in `feishu.py` `_on_card_action_trigger()`, BEFORE the `hermes_action` check:
```python
rag_feedback = action_value.get("hermes_rag_feedback") if isinstance(action_value, dict) else None
if rag_feedback:
    return self._handle_rag_feedback_card_action(event=event, action_value=action_value, feedback_type=rag_feedback)
```

The handler calls `http://localhost:8002/feedback` synchronously (via `urllib.request`), then returns a resolved card via `P2CardActionTriggerResponse` + `CallBackCard`. See `references/feishu-card-feedback.md` for full implementation.

**Key difference from Web/WeChat feedback:**
- Web: Gradio button click → direct function call → SQLite
- WeChat: keyword detection in message loop → HTTP call to `/feedback` API
- Feishu: interactive card button → SDK callback → gateway handler → HTTP call to `/feedback` API

All three channels write to the same SQLite `feedback` table via `log_feedback()`.

## Pitfalls

- **query_id type mismatch**: `query_id` from Gradio comes as string (e.g., "20260428140000-abc123"). SQLite stores it as INTEGER autoincrement. The web UI gets a `query_id` from kb_learning's string format — convert to int when calling `log_feedback()`, or fix the query_id plumbing to use SQLite's autoincrement id.
- **Emoji in Python f-strings**: Gradio supports emoji in Markdown tab names but emoji inside Python string literals with `"..."` can cause SyntaxError. Use string variables or `'...'` instead.
- **CSS overflow**: Feedback bad list can be long. Add `elem_classes=["source-box"]` and CSS `.source-box {max-height: 400px; overflow-y: auto;}` for scrollable panels.
- **Zero state**: If no feedback exists, show a helpful message instead of a blank panel. Explain where feedback comes from (query + thumbs up/down).
- **kb_learning.py conflict**: If you have both `kb_learning.py` (JSON file) and `rag_core.py` (SQLite) recording feedback, they diverge. Pick one as the single source of truth. SQLite is better for querying and scale.
- **wxauto `_last_queries` scoping bug**: When adding feedback to `wxauto_bot.py`, `last_queries` dict must be defined at **module level** (not inside `main()`). The `handle_command()` function is called from `main()` but if `last_queries` is a local variable in `main()`, it will raise `NameError: name 'last_queries' is not defined`. Define it as `_last_queries = {}` at module level, and use the same `_last_queries` name everywhere.
- **WSL2 localhost not reachable from Windows**: When `wxauto_bot.py` runs on Windows and `rag_api.py` runs in WSL2, `http://localhost:8002` won't work. Must use the WSL IP address (from `hostname -I`). The IP changes on WSL restart — document the IP or make it configurable.
- **BOT_NAME must match exactly**: wxauto's `@BOT_NAME` detection in group chats requires the string to match the WeChat nickname exactly (e.g., "设备组知识库机器人" not "设备知识问答").
- **query_id from generate_answer**: If `generate_answer()` calls both SQLite `log_query()` and `kb_learning.log_query()`, the returned `query_id` might be kb_learning's string format (e.g., "20260428142630-cf8538") instead of SQLite's integer. Fix: capture `sqlite_query_id = log_query(...)` return value and return `str(sqlite_query_id)` as the query_id.
- **WSL file copy to Windows**: Windows `copy` cannot overwrite a running/in-use file. Must `del` first, then `copy`. See skill `wsl-windows-file-copy`.
- **Direct query without /查 prefix**: For better UX, single chat messages can be treated as queries directly (no `/查` prefix needed). Group chats can use @mention or a monitor list.
- **Concurrent support**: Use `ThreadPoolExecutor(max_workers=5)` to handle multiple queries in parallel. Define `_executor` at module level. Submit `_do_query()` and `_do_feedback()` to the pool instead of calling inline.
- **Group monitoring**: Add `MONITOR_GROUPS = ["群名"]` list. Messages in these groups auto-query without @mention. Other groups still require @BOT_NAME.
