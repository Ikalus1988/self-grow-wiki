---
name: open-source-pr-contribution
description: Workflow for proposing a feature PR to an external open-source repo (one you don't own). Covers pulling latest state, scouting issues via GitHub API to find maintainer-approved targets, implementing with tests, static analysis that filters pre-existing warnings, and preparing commit/PR for user approval without auto-pushing. Calibrated for the user's "20-line solutions, no over-engineering, no auto-commit" preferences.
triggers:
  - 提个 PR
  - 提个 feat PR
  - 提 PR
  - 贡献 PR
  - contribute to upstream
  - 提给 upstream
  - 提给 X 仓库
  - 给 X 提
  - feat PR
  - upstream PR
  - OSS contribution
  - external PR
  - public repo PR
---

# Open-Source PR Contribution

A repeatable pattern for proposing a feature PR to an external open-source project, calibrated for this user's preferences (Matt Pocock philosophy, 20-line solutions, YAGNI, no auto-commit, structured status reports).

## When to use

User says any of: "提个 PR", "提 feat PR", "contribute to X repo", "fix issue Y", "做 PR 给 upstream 仓库", or otherwise wants to land a code change in a project they don't own.

For **operating GitHub** (auth, review, manage your own repos), see the `github` umbrella. This skill is specifically for **being an external contributor proposing a feature change** to someone else's project.

For **MisakaNet-specific conventions** (DCO, profile.json, search quota, /claim system), see `references/misakanet-quirks.md`.

## Workflow (8 steps)

### 1. Pull latest state (don't trust your local checkout)

Local `main` can lag 100+ commits behind `origin/main`. If the project has been active, your checkout is probably stale.

```bash
cd /path/to/repo
git fetch origin main
git log main..origin/main --oneline | wc -l   # how far behind?
git checkout main
git merge --ff-only origin/main
```

**If `git fetch` fails** (GnuTLS recv error, proxy issues, China network):
- Fall back to GitHub API via `curl` + PAT from `~/.git-credentials`
- Use `git log origin/main --oneline -20` after the API call to see recent commits
- Don't fight the proxy; pick a different transport

### 2. Scout via GitHub API (avoid duplicate work)

Before committing to a target, see what maintainers are doing right now:

```bash
TOK=$(grep github.com ~/.git-credentials | head -1 | sed -E 's|.*://[^:]+:||; s|@.*||')

# Recent merged/closed PRs (avoid duplicating in-flight work)
curl -sS -H "Authorization: token $TOK" \
  "https://api.github.com/repos/OWNER/REPO/pulls?state=all&per_page=15&sort=updated&direction=desc"

# Open issues with maintainer-approved labels
curl -sS -H "Authorization: token $TOK" \
  "https://api.github.com/repos/OWNER/REPO/issues?state=open&per_page=20&labels=ready,enhancement"
```

What to look for:
- Issues with `ready` / `enhancement` / `good first issue` labels = maintainer pre-approved direction
- No open PR already addressing the same issue (`gh pr list --search ...`)
- AC (Acceptance Criteria) clearly written in the issue

### 3. Pick target matching user philosophy

User preferences to honor:
- **20-line solutions, no over-engineering** — reject issues requiring state machines, queues, or speculative infra
- **YAGNI** — solve a real, current pain, not future hypotheticals
- **No P0 redesigns** — leave `P0 roadmap` items for the maintainer
- **Prefer `good first issue` or `ready` labels** — bounded scope, clear AC

Pick **1 target** and present a 1-2 sentence rationale. Don't list 5 candidates unless asked.

### 4. Set up local branch

```bash
git checkout main
git pull --ff-only  # or skip if step 1 already pulled
git checkout -b feat/<issue-num>-<short-desc>
```

### 5. Implement + test (TDD-flavored)

For library/utility code:
1. Read the existing module to understand conventions (variable naming, helper style, `__all__` exports)
2. Write tests first (or at least the failing case)
3. Write the minimum implementation
4. Iterate until tests pass
5. Run **full test suite** to check regressions

**Test design pitfall (BM25 / ranking / any length-sensitive scoring):**
When testing a new scoring factor, control for content length. Adding a section header (e.g. `## Verify`) makes a doc longer, which affects BM25 length normalization independently of the factor under test. Use **equal-char-content** fixtures to isolate the factor.

### 6. Static analysis (filter pre-existing)

`py_compile` + `pyflakes` + `ruff` will surface pre-existing warnings from upstream code. Don't fix them — they bloat the diff and aren't your problem.

**Distinguish new vs pre-existing by line number:**

```bash
# Get all warning line numbers
ruff check path/to/file.py 2>&1 | grep "file.py:" | awk -F: '{print $2}' | sort -un

# Compare against your hunk's line ranges
git diff -U0 path/to/file.py
```

Only fix warnings on lines your diff introduced. Pre-existing warnings stay as-is; opening a sweeping lint-cleanup PR violates "don't solve problems that don't exist."

**Style: `line-length`** — read `pyproject.toml` first; pre-commit may pin a different ruff version than your local install. Don't chase exact parity — just avoid introducing obvious new violations in lines you wrote.

### 7. Don't auto-commit / push (CRITICAL)

User preference: `commit 不要自动执行`. After implementation is clean:

1. **Restore any runtime-state files** that the test runs modified (`profile.json`, cache DBs, etc.)
2. Stage only the files you changed: `git add <files>`
3. Write commit message to `/tmp/<branch>_commit.txt`
4. Write PR body to `/tmp/<branch>_body.md`
5. **Present diff stat, test count, and decision points** to user
6. Wait for explicit "提" / "push" / "commit" signal

Example status report:

```
✅ Implementation done, not committed.

| File | +/− |
|------|-----|
| module.py | +49 / -5 |
| test_x.py | +218 / 0 |

- ✅ py_compile, import, pytest all pass
- ✅ 19 new tests, 119 total no regressions
- ✅ 2 lint warnings I introduced (E501) — fixed
- ⚠ 19 pre-existing warnings — not touched

Two decision points:
1. additive vs multiplicative scoring (deviated from issue text)
2. one constant not yet active (YAGNI, no `include_drafts` mode yet)

OK to commit + push + open PR? Reply "提" or specify changes.
```

### 8. After user says "提"

**Pre-flight (do this BEFORE creating a PR):**

```bash
# 1. Confirm branch state on origin
git ls-remote origin <branch>
#   0 lines returned = never pushed (will need push)
#   >0 lines      = already there (push will be a no-op; "Everything up-to-date")

# 2. Check for an existing open PR on this branch
curl -sS -H "Authorization: token $TOK" \
  "https://api.github.com/repos/OWNER/REPO/pulls?state=all&head=OWNER:BRANCH"
```

If a PR already exists, **report it and stop** — don't re-create, don't re-push, don't ask "is this OK?". Just tell the user the PR URL, number, and current state. They likely have a workflow hook (or a prior session) that already created it; re-creating is a no-op or worse (breaks their session's reference, or in Opire setups, re-triggers `/claim` accounting).

`Mergeable: None` and `mergeable_state: None` on a freshly-opened PR are **transient** — GitHub is still computing CI/merge state. Don't panic; report and move on.

**Execution:**

```bash
# Stage only the intended files
git restore --staged <runtime_state_files> 2>/dev/null
git checkout -- <runtime_state_files> 2>/dev/null
git add <changed_files_only>
git commit -s -F /tmp/<branch>_commit.txt   # -s adds Signed-off-by for DCO
git push origin feat/<branch>
gh pr create --base main --title "..." --body /tmp/<branch>_body.md
# For Opire-enabled issues: post /claim comment too (per project convention)
```

## Pitfalls

| Pitfall | Symptom | Fix |
|---------|---------|-----|
| Local main 200+ commits stale | Pick duplicate-of-merged-PR work | `git fetch origin main` first; check `git log main..origin/main --oneline \| wc -l` |
| `git fetch` fails on proxy (GnuTLS recv error, China GFW) | Stale data | Fall back to `curl` + GitHub API; parse with `python3 -c` |
| External dep installed in system python, not venv | `pytest` in venv fails `ModuleNotFoundError` | Use `/usr/bin/python3 -m pytest` instead of venv python |
| `profile.json` or similar runtime state modified by running CLI | Accidental commit of search_count, last_active, etc. | `git restore` them after running CLI tests; check `.gitignore` for patterns to add |
| DCO requires `Signed-off-by:` trailer | CI fails check-dco | Always `git commit -s` (uses local git config user.email) |
| `/claim` 8-hour window on competitive issues | Someone else claims before you push | Don't sit on the implementation; prep, implement, push in one shot |
| Pre-existing ruff warnings look like your problem | Bloated PR with sweeping lint fixes | Filter warnings to lines inside your hunk; ignore the rest |
| Lint version mismatch (pre-commit pins v0.5.0, local has v0.15.10) | Different warnings locally vs in CI | Accept best-effort; don't fix pre-existing |
| Verified-vs-unverified test with longer content | BM25 length normalization wins, factor effect invisible | Pad unverified doc to equal char count |
| `execute_code` blocked by cron_mode (when running in scheduled context) | Can't use Python for ad-hoc helpers | Use `terminal` + separate commands; parse JSON with `python3 -c` |
| `self-bootstrap feedback` (`git push` blocked by security layer) | PR never opened | Test auth early via `curl` API before writing the PR |
| Issue text suggests "X × Y" but adding to sum is cleaner | Following the literal text makes the constants harder to tune | Deviate when the deviation is justified; explain in PR body |
| `BOOLEAN_DRAFT` constant implemented but no current caller | Dead code in PR | Either wire it up now, or document in PR body why it's reserved for future use (YAGNI) |
| `git push` says "Everything up-to-date" but you expected a push | Means branch was already pushed in a prior session or hook — local commit SHA matches `git ls-remote` output | Don't re-push; check `git ls-remote origin <branch>` and then `GET /repos/.../pulls?head=OWNER:BRANCH` to see if a PR is already open |
| `POST /pulls` returns 422 "A pull request already exists for OWNER:BRANCH" | Tried to create a duplicate PR | Don't re-create. `GET /repos/.../pulls?state=all&head=OWNER:BRANCH`, report the existing PR's URL/number, stop |
| PAT from `~/.git-credentials` returns 401 even though token exists in file | Parse bug: filtered by `USER:` prefix and skipped the line that actually has the `ghp_` token (e.g. `ikalus` lowercase vs `Ikalus1988` uppercase, or `gho_` OAuth token vs `ghp_` PAT) | Inspect raw file: `cat -A ~/.git-credentials`. Filter by token **prefix** (`grep ghp_`), not by user string. The PAT that works for `POST /repos/.../pulls` is a `ghp_` token, not a `gho_` OAuth token |

## Verification Checklist

Before telling user "ready to commit":

- [ ] `python3 -m py_compile <changed_files>` — no syntax error
- [ ] `python3 -c "from module import new_func, NEW_CONST"` — imports work
- [ ] `pytest tests/test_new_feature.py -v` — new tests all pass
- [ ] `pytest tests/ -q` — full suite, no regressions
- [ ] `ruff check <changed_files>` — no NEW warnings on lines in your diff
- [ ] Real CLI smoke test: run the binary and observe intended behavior
- [ ] `git status --short` — only intended files, no runtime state
- [ ] `git diff --stat HEAD` — clean diff
- [ ] Commit message and PR body written to `/tmp/`
- [ ] User has been shown diff stat, test count, decision points

## Output style for status reports

When presenting implementation status, use a **diff stat table + verification checklist + decision points**. User preference (from CLAUDE.md / memory): structured summaries, not free-form prose. The user reads the structure to make decisions.

## Reference docs

- `references/misakanet-quirks.md` — MisakaNet-specific conventions (DCO, profile.json, /claim, search quota, venv vs system python)
