# MisakaNet-specific quirks for external PR contribution

Domain notes for contributing to `Ikalus1988/MisakaNet`. Use this when the
parent skill says "check project conventions" — read the equivalent here
for MisakaNet. For other OSS repos, write an equivalent reference doc.

## Repository paths

| What | Where |
|------|-------|
| Local clone (this machine) | `/home/hp/MisakaNet/` |
| Public repo | https://github.com/Ikalus1988/MisakaNet |
| Mirror (admin bot) | https://github.com/sheldonisspark-lab/MisakaNet |
| Project wiki | https://ikalus1988.github.io/MisakaNet/ |

The project was renamed `Agent-Medici` → `MisakaNet` around v1.0.0
(2026-05-08). The old `agent-medici-project-state` skill still references
both names; treat them as the same project lineage.

## Python tooling

- `misakanet-core` package is installed in **system python**
  (`/usr/bin/python3`), NOT in `~/.hermes/hermes-agent/venv/`
- All pytest runs must use: `/usr/bin/python3 -m pytest tests/`
- venv python (`/home/hp/.hermes/hermes-agent/venv/bin/python3`) is for
  tooling (ruff, hermes, etc.), NOT for MisakaNet tests
- `misakanet-core` 2.7.0 is current; check `pyproject.toml` for
  `requires-python` (currently `>=3.10`)

## Runtime state files (NEVER commit)

- `misakanet/profile.json` — search quota counter, last_active timestamp,
  referral code. Modified every CLI run.
- `.cache/search_cache.db` — L2 search cache. Generated.
- `node_modules/`, `__pycache__/`, `*.pyc` — standard.
- `bench_results/` — may have local run artifacts.

Always `git restore misakanet/profile.json` after running CLI tests,
before staging. Or add a local `.gitignore` override.

## DCO + pre-commit hooks

- Every commit must have `Signed-off-by:` trailer — use `git commit -s`
- Pre-commit hooks (`.pre-commit-config.yaml`): ruff, ruff-format,
  check-dco, validate-lessons, check-lesson-quality
- Local ruff v0.15.10 vs pre-commit pins **v0.5.0** — minor warnings
  may differ; don't chase exact parity
- User identity (git config): `Hermes Agent <noreply@hermes-agent.local>`
  — matches DCO check

## Opire /claim system (competitive issues)

Some issues (those with the Opire bot enabled) have a `/claim` slash
command workflow:

```
/claim #NNN    # on the issue — locks 8h exclusive window
/try           # in issue comment — "I'm starting work on this"
/reward N      # in issue comment — anyone can add reward
/claim #NNN    # in PR body or comment — claims the reward when PR opens
/tip N @user   # tip a contributor
```

The PR body should end with `Refs #NNN` and `/claim #NNN` for
Opire-enabled issues.

## Search quota (v2.7+)

The CLI enforces a daily search quota: 5 searches/day, contribution
restores it. CLI output shows:

```
[MisakaNet] 搜索额度剩余 2/5。
```

When testing search behavior, plan the queries — don't burn the whole
quota on dry runs. Use `--titles` mode where possible (lighter).

## 8-hour claim window

Competitive issues have an 8h exclusive window from when you `/claim`.
Don't sit on a claim — prep, implement, push in one session, otherwise
someone else can take it.

## Code conventions

- BM25 search engine in `misakanet/search/engine.py` (~525 lines)
- CLI thin wrapper in `search_knowledge.py` (just imports + main)
- Test directory: `tests/test_<feature>.py`
  (e.g. `tests/test_boost_ranking.py`)
- Use `_is_X(doc)` and `_compute_X(doc)` helper style for per-doc
  derivations
- Module-level constants for tunables: `WEIGHT_*`, `BOOST_*`
- L2 cache uses SQLite, file mtime/size for invalidation
- Default composite: `0.65 * bm25_norm + 0.20 * metadata + 0.15 * baseline`
  (additive factors can stack on top)

## PR body template (Opire-compatible)

```markdown
## Summary

[1-2 sentences on the change]

## Changes

- file.py: bullet list of meaningful changes

## Verification

$ pytest tests/ -q
N passed, M skipped
```

Real `search_knowledge.py "foo"` run shows the expected behavior.

## Checklist

- [x] Code meets all AC items in #NNN
- [x] `pytest tests/` passes (no regressions)
- [x] No raw Python Traceback in output
- [x] Every commit has `Signed-off-by:` trailer
- [x] No unrelated files included (profile.json excluded)

## PAT in `~/.git-credentials`

The credentials file has **4 entries** (run `cat -A ~/.git-credentials` to see raw):

```
https://ikalus:ghp_Dq...glx3@github.com
https://Ikalus1988:gho_z9...ImYY@github.com       # gho_ = OAuth, NOT a PAT
https://Ikalus1988:ghp_Dq...WlPo@20.205.243.166   # ssh-over-https host, not api.github.com
https://sheldonisspark-lab:ghp_pn...ccII@github.com
```

**Trap:** The `Ikalus1988:gho_` line is the user's OAuth token — it works for `git push` over HTTPS but **returns 401 on `api.github.com` REST calls**. The working PAT for `api.github.com` is on the lowercase `ikalus:ghp_...@github.com` line.

**Parse recipe (the only one that works for API calls):**

```python
token = None
with open('/home/hp/.git-credentials') as f:
    for line in f:
        line = line.strip()
        if line.startswith('https://ikalus:') and 'github.com' in line:
            cred = line.split('://', 1)[1]   # 'ikalus:ghp_...@github.com'
            user_pass = cred.rsplit('@', 1)[0]  # 'ikalus:ghp_...'
            token = user_pass.split(':', 1)[1]   # 'ghp_...'
            break

req = urllib.request.Request(
    url,
    headers={'Authorization': f'token {token}',
             'Accept': 'application/vnd.github+json',
             'X-GitHub-Api-Version': '2022-11-28'}
)
```

**Filter by `ghp_` prefix, not by user string** — the `Ikalus1988` user has both a `gho_` OAuth token (no API access) and a `ghp_` PAT (only on the `20.205.243.166` line, which is the SSH-over-HTTPS host, not the REST API host). Filtering by `ikalus:ghp_` is the only way to land on the right token in one step.

## Node ID

`hermes_wsl` (Node 1, hp WSL)

Refs #NNN
/claim #NNN
```

## Quick command sheet

```bash
# 1. Check local-vs-remote lag
cd /home/hp/MisakaNet
git fetch origin main
git log main..origin/main --oneline | wc -l

# 2. Run all tests
/usr/bin/python3 -m pytest tests/ -q --ignore=tests/frontend.test.js

# 3. Static analysis
/usr/bin/python3 -m py_compile misakanet/search/engine.py
/home/hp/.hermes/hermes-agent/venv/bin/ruff check misakanet/search/engine.py

# 4. Restore accidentally-modified runtime state
git restore misakanet/profile.json
```

## Related skills

- `agent-medici-project-state` — historical project state (mostly still
  accurate, repo renamed)
- `github` umbrella — for general GitHub operations
- `open-source-pr-contribution` (this skill) — the workflow
