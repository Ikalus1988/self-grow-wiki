---
name: code-review
description: Systematic code review patterns covering security, performance, maintainability, correctness, and testing — with severity levels, structured feedback guidance, review process, and anti-patterns to avoid. Use when reviewing PRs, establishing review standards, or improving review quality.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [code-review, pr-review, security, quality, checklist]
    related_skills: [github-code-review, requesting-code-review]
---

# Code Review Checklist

Thorough, structured approach to reviewing code. Work through each dimension systematically rather than scanning randomly.

## When to Use

- Reviewing a PR or diff for quality, security, or correctness
- Setting up a review checklist or process
- Auditing code before merge or release
- **CI/CD workflow review** — see `references/github-actions-workflow-review.md` for GitHub Actions-specific pitfalls

## Linked References

- `references/github-actions-workflow-review.md` — GitHub Actions workflow audit patterns: gh CLI API quirks, idempotency, cron math, token handling, permission scoping.

## Review Dimensions

| Dimension | Focus | Priority |
|-----------|-------|----------|
| Security | Vulnerabilities, auth, data exposure | Critical |
| Performance | Speed, memory, scalability bottlenecks | High |
| Correctness | Logic errors, edge cases, data integrity | High |
| Maintainability | Readability, structure, future-proofing | Medium |
| Testing | Coverage, quality, reliability of tests | Medium |
| Accessibility | WCAG compliance, keyboard nav, screen readers | Medium |
| Documentation | Comments, API docs, changelog entries | Low |

---

## Security Checklist

Review every change for these vulnerabilities:

- [ ] **SQL Injection** — All queries use parameterized statements; no string concatenation
- [ ] **XSS** — User-provided content is escaped/sanitized before rendering
- [ ] **CSRF Protection** — State-changing requests require valid CSRF tokens
- [ ] **Authentication** — Every protected endpoint verifies the user is authenticated
- [ ] **Authorization** — Resource access is scoped; no IDOR vulnerabilities
- [ ] **Input Validation** — All external input validated on the server side
- [ ] **Secrets Management** — No API keys, passwords, or tokens in source code
- [ ] **Dependency Safety** — New dependencies are from trusted sources, no known CVEs
- [ ] **Sensitive Data** — PII/tokens/secrets never logged or returned in API responses
- [ ] **Rate Limiting** — Public endpoints have rate limits to prevent abuse
- [ ] **File Upload Safety** — Files validated for type/size, stored outside webroot
- [ ] **HTTP Security Headers** — CSP, X-Content-Type-Options, HSTS are set

---

## Performance Checklist

- [ ] **N+1 Queries** — Database access is batched; no loops issuing individual queries
- [ ] **Memory Leaks** — Event listeners, subscriptions, timers cleaned up on unmount
- [ ] **Bundle Size** — New dependencies are tree-shakeable; no full-library imports
- [ ] **Lazy Loading** — Heavy components/routes use code splitting
- [ ] **Caching Strategy** — Expensive computations use appropriate caching
- [ ] **Database Indexing** — Queries filter/sort on indexed columns; checked with EXPLAIN
- [ ] **Pagination** — List endpoints use pagination; no unbounded SELECT *
- [ ] **Async Operations** — Long-running tasks offloaded to background jobs
- [ ] **Image & Asset Optimization** — Images properly sized, use modern formats

---

## Correctness Checklist

- [ ] **Edge Cases** — Empty arrays, zero values, negative numbers handled
- [ ] **Null/Undefined Handling** — Optional chaining or guards prevent runtime errors
- [ ] **Off-by-One Errors** — Loop bounds, array slicing, pagination offsets verified
- [ ] **Race Conditions** — Concurrent access uses locks, transactions, or atomics
- [ ] **Timezone Handling** — Dates stored in UTC; display conversion at presentation layer
- [ ] **Unicode & Encoding** — String operations handle multi-byte characters
- [ ] **Integer Overflow / Precision** — Currency uses appropriate types (Decimal/BigInt)
- [ ] **Error Propagation** — Async errors are caught and handled; promises not swallowed
- [ ] **State Consistency** — Multi-step mutations are transactional

---

## Maintainability Checklist

- [ ] **Naming Clarity** — Variables, functions, classes have descriptive names
- [ ] **Single Responsibility** — Each function/class/module does one thing
- [ ] **DRY** — Duplicated logic extracted into shared utilities
- [ ] **Cyclomatic Complexity** — Low branching complexity; deep nesting refactored
- [ ] **Dead Code Removal** — Commented-out code, unused imports, feature flags removed
- [ ] **Magic Numbers & Strings** — Literal values extracted into named constants
- [ ] **Consistent Patterns** — New code follows existing codebase conventions
- [ ] **Dependency Direction** — Core logic does not import from UI or framework layers

---

## Testing Checklist

- [ ] **Test Coverage** — New logic paths have corresponding tests
- [ ] **Edge Case Tests** — Boundary values, empty inputs, nulls, error conditions
- [ ] **No Flaky Tests** — Deterministic; no reliance on timing or shared mutable state
- [ ] **Test Independence** — Each test sets up its own state and tears it down
- [ ] **Meaningful Assertions** — Assert on behavior and outcomes, not implementation
- [ ] **Test Readability** — Arrange-Act-Assert; test names describe the scenario
- [ ] **Regression Tests** — Bug fixes include a test reproducing the original bug

---

## Review Process

Work through the code in three passes:

| Pass | Focus | Time | What to Look For |
|------|-------|------|------------------|
| First | High-level structure | 2-5 min | Architecture fit, file organization, API design, approach |
| Second | Line-by-line detail | Bulk | Logic errors, security issues, performance, edge cases |
| Third | Edge cases & hardening | 5 min | Failure modes, concurrency, boundary values, missing tests |

### First Pass (2-5 minutes)
1. Read the PR description and linked issue
2. Scan the file list — does the scope make sense?
3. Check the overall approach — is this the right solution?
4. Verify no architectural drift

### Second Pass (bulk)
1. Read each file diff top to bottom
2. Check every function against the checklists above
3. Verify error handling at every I/O boundary
4. Flag anything that makes you pause

### Third Pass (5 min)
1. Think about what could go wrong in production
2. Check for missing tests on flagged code paths
3. Verify rollback safety — can it be reverted without data loss?
4. Confirm documentation and changelog are updated

---

## Severity Levels

| Level | Label | Meaning | Blocks Merge? |
|-------|-------|---------|---------------|
| Critical | `[CRITICAL]` | Security vulnerability, data loss, or production crash | Yes |
| Major | `[MAJOR]` | Bug, logic error, or significant performance regression | Yes |
| Minor | `[MINOR]` | Future maintenance cost reduction | No |
| Nitpick | `[NIT]` | Style preference, naming suggestion, trivial cleanup | No |

Always prefix review comments with the severity label.

---

## Giving Feedback

- **Be specific** — Point to exact line and explain the issue
- **Explain why** — State the risk or consequence
- **Suggest a fix** — Offer concrete alternative or code snippet
- **Ask, don't demand** — Use questions for subjective points
- **Acknowledge good work** — Call out clean solutions or thorough tests
- **Separate blocking from non-blocking** — Use severity labels

### Example Comments

**Bad:** "This is wrong. Fix it."

**Good:** `[MAJOR]` This query interpolates user input directly into SQL (line 42), which is vulnerable to SQL injection. Use parameterized queries:
```sql
SELECT * FROM users WHERE id = $1
```

**Good:** `[MINOR]` The new `calculateDiscount()` has branching paths — could we add tests for zero-quantity and negative-price edge cases?

---

## Review Anti-Patterns

| Anti-Pattern | Description |
|--------------|-------------|
| **Rubber-Stamping** | Approving without reading. Creates false confidence. |
| **Bikeshedding** | Spending 30min on a variable name while ignoring a race condition. |
| **Blocking on Style** | Refusing approval over formatting a linter should enforce. |
| **Gatekeeping** | Requiring your preferred approach when the submitted one is correct. |
| **Scope Creep** | Requesting unrelated refactors as separate PRs. |
| **Stale Reviews** | Letting PRs sit for days. Review within 24h. |
| **Emotional Language** | Critique the code, not the person. |

---

## NEVER Do

1. **NEVER approve without reading every changed line**
2. **NEVER block solely for style preferences** — use a linter
3. **NEVER leave feedback without a severity level**
4. **NEVER request changes without explaining why**
5. **NEVER review more than 400 lines in one sitting** — comprehension drops sharply
6. **NEVER skip the security checklist**
7. **NEVER make it personal** — assume good intent
