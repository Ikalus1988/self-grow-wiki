# GitHub Actions Workflow Review Patterns

Common pitfalls found when auditing `.github/workflows/*.yml` files. These are NOT caught by standard linters.

## gh CLI Pitfalls in Workflows

### `--json` field types vs jq expectations

| `gh` command | `--json` field | Returns | Expected |
|---|---|---|---|
| `gh issue list` | `comments` | Integer (count) | ❌ NOT array of comment objects |
| `gh pr list` | `reviews` | Array of review objects | ✅ |
| `gh issue list` | `labels` | Array of label objects | ✅ |

**Trap**: `jq '.comments[]'` on a count integer produces empty output with exit 0 — no error, just wrong data.

**Fix**: Fetch comments separately via API:
```bash
gh api "repos/{owner}/{repo}/issues/{number}/comments" \
  --jq '[.[] | select(.body | test("^/claim\\b"))] | .[-1].created_at // empty'
```

### Token handling in shell steps

**Bad** (token in process args, visible in `ps` and logs if debug enabled):
```bash
curl -s -X POST -H "Authorization: token $ZSXH_TOKEN" ...
```

**Good** (token scoped to subprocess only):
```bash
GH_TOKEN=$ZSXH_TOKEN gh api "repos/{owner}/{repo}/issues/{number}/comments" \
  --method POST --field body="$COMMENT"
```

## Idempotency Patterns

### Notification steps must check before posting

Every step that posts a comment, sends a notification, or modifies labels MUST check if it already did so. GitHub Actions cron runs repeatedly — without dedup, users get spammed.

```bash
# Before posting expiry notice
ALREADY_NOTIFIED=$(gh api "repos/{owner}/{repo}/issues/{number}/comments" \
  --jq '[.[] | select(.body | test("Claim Window Expired"))] | length')
[ "$ALREADY_NOTIFIED" -gt 0 ] && { echo "Already notified. Skipping."; exit 0; }
```

### Label removal idempotency

`gh issue edit --remove-label "X"` silently succeeds even if label not present. Safe to call without checking first.

## PR Reference Detection

### `--search` vs Timeline API

`gh pr list --search "\"#123\""` finds PRs that mention the issue number in title/body, but misses cross-reference events (GitHub automatically creates these when a PR references an issue).

More reliable alternative:
```bash
gh api "repos/{owner}/{repo}/issues/{number}/timeline" \
  --jq '[.[] | select(.event == "cross-referenced" and .source.issue.pull_request)] | length'
```

## Cron Schedule Math

| Cron expression | Runs/month (approx) | Free tier? |
|---|---|---|
| `*/2 * * * *` | 720 | ❌ Exceeds 2000 min/month if each run >40s |
| `0 */2 * * *` | 360 | ✅ Tight |
| `0 */4 * * *` | 180 | ✅ Comfortable |
| `0 */6 * * *` | 120 | ✅ Generous margin |

Always document the monthly run count in the workflow or PR description.

## Permission Scope Audit

Minimize permissions to what the workflow actually needs:

```yaml
permissions:
  contents: write    # Only if pushing commits (leaderboard, auto-fix)
  issues: write      # Only if commenting/closing/labeling issues
  pull-requests: write  # Only if commenting/pushing to PR branches
  checks: read       # Only if reading CI status
```

**Pitfall**: Declaring `contents: write` when only reading → unnecessary attack surface.

## Two-Round Deployment Strategy

When deploying a new automated workflow with write operations:

1. **Round 1**: Deploy read-only skeleton (echo/log only, no write ops). Run for 3-7 days to validate cron frequency, API consumption, and edge cases.
2. **Round 2**: Add write operations (post comments, push commits, modify labels) after observing real data.

Rationale: Write operations in cron jobs have no human-in-the-loop. A bug in Round 2 logic gets caught in Round 1 observation window, not in production spam.
